# 💳 Configuração de Pagamentos - Comfydance

## 🎯 **Como Funciona o Sistema de Pagamentos**

O sistema foi projetado para funcionar em **dois modos**:

### 🎭 **Modo Demonstração (Atual)**
- ✅ **Funciona imediatamente** sem configuração
- ✅ **PIX e Boleto simulados** com QR codes reais
- ✅ **Interface completa** para testes
- ⚠️ **Nenhuma transação real** é processada
- 💾 **Dados salvos localmente** para demonstração

### 🔄 **Modo Produção (Com Provedores Reais)**
- ✅ **Transações reais** processadas
- ✅ **Webhooks automáticos** para confirmação
- ✅ **Integração com bancos** e fintechs
- ✅ **Relatórios financeiros** completos

---

## 🚀 **Para Ativar Pagamentos Reais**

### **1. Configure o Supabase (Banco de Dados)**
```bash
# Crie uma conta em https://supabase.com
# Copie as credenciais para o arquivo .env:

VITE_SUPABASE_URL=sua_url_do_supabase
VITE_SUPABASE_ANON_KEY=sua_chave_anonima
```

### **2. Escolha um Provedor de Pagamento**

#### **🟢 Mercado Pago (Recomendado)**
```bash
# Adicione no .env:
VITE_MERCADOPAGO_ACCESS_TOKEN=seu_token_mercadopago
VITE_MERCADOPAGO_PUBLIC_KEY=sua_chave_publica
```

#### **🔵 Gerencianet**
```bash
# Adicione no .env:
VITE_GERENCIANET_CLIENT_ID=seu_client_id
VITE_GERENCIANET_CLIENT_SECRET=seu_client_secret
```

#### **🟡 Asaas**
```bash
# Adicione no .env:
VITE_ASAAS_ACCESS_TOKEN=seu_token_asaas
```

### **3. Configure os Webhooks**
```javascript
// O sistema automaticamente configurará os webhooks para:
// - Confirmação de pagamentos PIX
// - Confirmação de pagamentos de boleto
// - Atualizações de status em tempo real
```

---

## 📋 **Fluxo Completo de Pagamento**

### **🛒 1. Cliente Finaliza Compra**
```
Cliente escolhe produtos → Adiciona ao carrinho → Vai para checkout
```

### **💳 2. Seleção de Pagamento**
```
PIX (5% desconto) OU Boleto Bancário
```

### **🔄 3. Processamento**

#### **PIX:**
- ✅ QR Code gerado instantaneamente
- ✅ Cliente escaneia e paga
- ✅ Confirmação automática via webhook
- ✅ Pedido aprovado em segundos

#### **Boleto:**
- ✅ Boleto gerado com vencimento em 3 dias
- ✅ Cliente pode imprimir ou usar código de barras
- ✅ Confirmação automática após pagamento
- ✅ Pedido aprovado em até 3 dias úteis

### **📧 4. Confirmações**
```
Email para cliente → Notificação para admin → Atualização de estoque
```

---

## 🔧 **Configuração Técnica Detalhada**

### **Estrutura do Banco de Dados**
```sql
-- Tabela de pedidos
user_orders (
  id, user_id, order_number, items, total_amount, 
  status, payment_method, shipping_address
)

-- Tabela de transações de pagamento
payment_transactions (
  id, order_id, method, amount, status, 
  pix_code, pix_qr_code, boleto_url, expires_at
)

-- Auditoria de pagamentos
payment_audit (
  id, transaction_id, old_status, new_status, 
  changed_by, admin_email, notes
)
```

### **API de Pagamentos**
```typescript
// Criar pagamento PIX
paymentService.createPixPayment(orderId, amount, description)

// Criar boleto
paymentService.createBoletoPayment(orderId, amount, description, customerData)

// Verificar status
paymentService.checkPaymentStatus(transactionId)

// Atualizar status (admin)
paymentService.updatePaymentStatus(transactionId, newStatus)
```

---

## 🎯 **Vantagens do Sistema Atual**

### **✅ Para Demonstração:**
- Funciona imediatamente sem configuração
- Interface completa para apresentação
- Dados realistas para testes
- Nenhum risco de transações acidentais

### **✅ Para Produção:**
- Transição suave do demo para produção
- Múltiplos provedores de pagamento
- Webhooks automáticos
- Auditoria completa de transações
- Relatórios financeiros detalhados

---

## 🚨 **Importante**

### **Modo Atual (Demonstração):**
- ⚠️ **Nenhuma transação real** é processada
- ⚠️ **Dados são simulados** para demonstração
- ✅ **Seguro para apresentações** e testes
- ✅ **Interface idêntica** ao modo produção

### **Para Ativar Produção:**
1. Configure o Supabase (banco de dados)
2. Adicione credenciais de um provedor de pagamento
3. Configure webhooks para confirmações automáticas
4. Teste em ambiente sandbox antes de produção

---

## 📞 **Suporte**

Para configurar pagamentos reais:
1. **Supabase:** https://supabase.com/docs
2. **Mercado Pago:** https://www.mercadopago.com.br/developers
3. **Gerencianet:** https://dev.gerencianet.com.br
4. **Asaas:** https://docs.asaas.com

O sistema está **pronto para produção** - basta adicionar as credenciais!