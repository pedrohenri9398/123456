/*
  # Fix RLS Policies Setup

  1. Security
    - Enable RLS on all user tables if not already enabled
    - Create policies only if they don't exist
    - Ensure proper access control for users and admins

  2. Tables affected:
    - user_profiles: Users can manage their own profile
    - admin_users: Admins can read their own data, super admins can manage all
    - user_addresses: Users can manage their own addresses
    - user_orders: Users can manage their own orders, admins can read/update all
*/

-- Enable RLS on tables (safe to run multiple times)
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_orders ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist to avoid conflicts
DO $$ 
BEGIN
  -- User Profiles Policies
  DROP POLICY IF EXISTS "Users can read own profile" ON user_profiles;
  DROP POLICY IF EXISTS "Users can update own profile" ON user_profiles;
  DROP POLICY IF EXISTS "Users can insert own profile" ON user_profiles;
  
  -- Admin Users Policies
  DROP POLICY IF EXISTS "Admins can read own admin data" ON admin_users;
  DROP POLICY IF EXISTS "Super admins can manage admin users" ON admin_users;
  DROP POLICY IF EXISTS "Admins can read admin data" ON admin_users;
  
  -- User Addresses Policies
  DROP POLICY IF EXISTS "Users can manage own addresses" ON user_addresses;
  
  -- User Orders Policies
  DROP POLICY IF EXISTS "Users can read own orders" ON user_orders;
  DROP POLICY IF EXISTS "Users can create own orders" ON user_orders;
  DROP POLICY IF EXISTS "Admins can read all orders" ON user_orders;
  DROP POLICY IF EXISTS "Admins can update order status" ON user_orders;
END $$;

-- Create User Profiles Policies
CREATE POLICY "Users can read own profile" ON user_profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON user_profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON user_profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- Create Admin Users Policies
CREATE POLICY "Admins can read admin data" ON admin_users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Super admins can manage admin users" ON admin_users
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE id = auth.uid() AND is_super_admin = true
    )
  );

-- Create User Addresses Policies
CREATE POLICY "Users can manage own addresses" ON user_addresses
  FOR ALL USING (auth.uid() = user_id);

-- Create User Orders Policies
CREATE POLICY "Users can read own orders" ON user_orders
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create own orders" ON user_orders
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can read all orders" ON user_orders
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE id = auth.uid()
    )
  );

CREATE POLICY "Admins can update order status" ON user_orders
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE id = auth.uid()
    )
  );