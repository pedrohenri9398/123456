/*
  # Create payment and order management tables

  1. New Tables
    - `payment_transactions`
      - `id` (uuid, primary key)
      - `order_id` (uuid, references user_orders)
      - `payment_id` (text, external payment provider ID)
      - `method` (text, pix or boleto)
      - `amount` (numeric, payment amount)
      - `status` (text, pending/paid/cancelled/expired)
      - `pix_code` (text, PIX payment code)
      - `pix_qr_code` (text, PIX QR code data URL)
      - `boleto_url` (text, boleto PDF URL)
      - `boleto_barcode` (text, boleto barcode)
      - `expires_at` (timestamp, payment expiration)
      - `paid_at` (timestamp, payment confirmation)
      - `provider_data` (jsonb, raw provider response)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `payment_config`
      - `id` (uuid, primary key)
      - `provider_id` (text, payment provider identifier)
      - `provider_name` (text, human readable name)
      - `provider_type` (text, mercadopago/gerencianet/asaas/etc)
      - `enabled` (boolean, provider status)
      - `config` (jsonb, provider configuration)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for user and admin access
    - Add audit triggers for payment status changes

  3. Indexes
    - Add indexes for performance on common queries
*/

-- Create payment_transactions table
CREATE TABLE IF NOT EXISTS payment_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES user_orders(id) ON DELETE CASCADE,
  payment_id text,
  method text NOT NULL CHECK (method IN ('pix', 'boleto')),
  amount numeric(10,2) NOT NULL CHECK (amount > 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'cancelled', 'expired')),
  pix_code text,
  pix_qr_code text,
  boleto_url text,
  boleto_barcode text,
  expires_at timestamptz,
  paid_at timestamptz,
  provider_data jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create payment_config table
CREATE TABLE IF NOT EXISTS payment_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id text UNIQUE NOT NULL,
  provider_name text NOT NULL,
  provider_type text NOT NULL CHECK (provider_type IN ('mercadopago', 'gerencianet', 'asaas', 'pagseguro', 'pagarme')),
  enabled boolean DEFAULT false,
  config jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create payment_audit table for tracking status changes
CREATE TABLE IF NOT EXISTS payment_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id uuid NOT NULL REFERENCES payment_transactions(id) ON DELETE CASCADE,
  old_status text,
  new_status text NOT NULL,
  changed_by uuid REFERENCES auth.users(id),
  admin_email text,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_payment_transactions_order_id ON payment_transactions(order_id);
CREATE INDEX IF NOT EXISTS idx_payment_transactions_status ON payment_transactions(status);
CREATE INDEX IF NOT EXISTS idx_payment_transactions_method ON payment_transactions(method);
CREATE INDEX IF NOT EXISTS idx_payment_transactions_created_at ON payment_transactions(created_at);
CREATE INDEX IF NOT EXISTS idx_payment_audit_transaction_id ON payment_audit(transaction_id);
CREATE INDEX IF NOT EXISTS idx_payment_audit_created_at ON payment_audit(created_at);

-- Enable RLS
ALTER TABLE payment_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_audit ENABLE ROW LEVEL SECURITY;

-- RLS Policies for payment_transactions
CREATE POLICY "Users can read own payment transactions" ON payment_transactions
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM user_orders 
      WHERE user_orders.id = payment_transactions.order_id 
      AND user_orders.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create payment transactions for own orders" ON payment_transactions
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_orders 
      WHERE user_orders.id = payment_transactions.order_id 
      AND user_orders.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can read all payment transactions" ON payment_transactions
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE admin_users.id = auth.uid()
    )
  );

CREATE POLICY "Admins can update payment transactions" ON payment_transactions
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE admin_users.id = auth.uid()
    )
  );

-- RLS Policies for payment_config
CREATE POLICY "Admins can manage payment config" ON payment_config
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE admin_users.id = auth.uid()
    )
  );

-- RLS Policies for payment_audit
CREATE POLICY "Admins can read payment audit" ON payment_audit
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE admin_users.id = auth.uid()
    )
  );

CREATE POLICY "System can insert payment audit" ON payment_audit
  FOR INSERT WITH CHECK (true);

-- Create trigger for payment_transactions updated_at
CREATE TRIGGER update_payment_transactions_updated_at
  BEFORE UPDATE ON payment_transactions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Create trigger for payment_config updated_at
CREATE TRIGGER update_payment_config_updated_at
  BEFORE UPDATE ON payment_config
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Create trigger for payment status audit
CREATE OR REPLACE FUNCTION audit_payment_status_change()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    INSERT INTO payment_audit (
      transaction_id,
      old_status,
      new_status,
      changed_by,
      admin_email
    ) VALUES (
      NEW.id,
      OLD.status,
      NEW.status,
      auth.uid(),
      (SELECT email FROM auth.users WHERE id = auth.uid())
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER audit_payment_status_changes
  AFTER UPDATE ON payment_transactions
  FOR EACH ROW EXECUTE FUNCTION audit_payment_status_change();

-- Insert default payment configuration
INSERT INTO payment_config (provider_id, provider_name, provider_type, enabled, config) VALUES
  ('mercadopago', 'Mercado Pago', 'mercadopago', false, '{"environment": "sandbox"}'),
  ('gerencianet', 'Gerencianet', 'gerencianet', false, '{"environment": "sandbox"}'),
  ('asaas', 'Asaas', 'asaas', false, '{"environment": "sandbox"}'),
  ('pagseguro', 'PagSeguro', 'pagseguro', false, '{"environment": "sandbox"}'),
  ('pagarme', 'Pagar.me', 'pagarme', false, '{"environment": "sandbox"}')
ON CONFLICT (provider_id) DO NOTHING;