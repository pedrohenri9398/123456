/*
  # Fix Admin Users RLS Policies

  1. Problem
    - Infinite recursion in admin_users policies
    - Policies referencing themselves causing loops

  2. Solution
    - Remove problematic policies
    - Create simpler, non-recursive policies
    - Use service role for admin operations when needed

  3. Changes
    - Drop existing admin_users policies
    - Create new safe policies
    - Add proper admin access controls
*/

-- Drop existing problematic policies
DROP POLICY IF EXISTS "Admins can read admin data" ON admin_users;
DROP POLICY IF EXISTS "Super admins can manage admin users" ON admin_users;

-- Create new safe policies that don't cause recursion
CREATE POLICY "Enable read access for authenticated users on their own admin record"
  ON admin_users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Enable insert for service role"
  ON admin_users
  FOR INSERT
  TO service_role
  WITH CHECK (true);

CREATE POLICY "Enable update for service role"
  ON admin_users
  FOR UPDATE
  TO service_role
  USING (true);

-- Create a function to check if user is admin without recursion
CREATE OR REPLACE FUNCTION is_admin(user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = user_id
  );
$$;

-- Update other tables' policies to use the function instead of direct queries
-- Fix user_orders policies
DROP POLICY IF EXISTS "Admins can read all orders" ON user_orders;
DROP POLICY IF EXISTS "Admins can update order status" ON user_orders;

CREATE POLICY "Admins can read all orders"
  ON user_orders
  FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()) OR auth.uid() = user_id);

CREATE POLICY "Admins can update order status"
  ON user_orders
  FOR UPDATE
  TO authenticated
  USING (is_admin(auth.uid()));

-- Fix payment_transactions policies
DROP POLICY IF EXISTS "Admins can read all payment transactions" ON payment_transactions;
DROP POLICY IF EXISTS "Admins can update payment transactions" ON payment_transactions;

CREATE POLICY "Admins can read all payment transactions"
  ON payment_transactions
  FOR SELECT
  TO authenticated
  USING (
    is_admin(auth.uid()) OR 
    EXISTS (
      SELECT 1 FROM user_orders 
      WHERE user_orders.id = payment_transactions.order_id 
      AND user_orders.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can update payment transactions"
  ON payment_transactions
  FOR UPDATE
  TO authenticated
  USING (is_admin(auth.uid()));

-- Fix payment_audit policies
DROP POLICY IF EXISTS "Admins can read payment audit" ON payment_audit;

CREATE POLICY "Admins can read payment audit"
  ON payment_audit
  FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));

-- Fix payment_config policies
DROP POLICY IF EXISTS "Admins can manage payment config" ON payment_config;

CREATE POLICY "Admins can manage payment config"
  ON payment_config
  FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()));