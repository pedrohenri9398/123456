import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { User as SupabaseUser, Session } from '@supabase/supabase-js';
import { supabase, isDemoMode } from '../lib/supabase';
import { User, AdminUser } from '../types';

interface AuthContextType {
  user: User | null;
  adminUser: AdminUser | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isLoading: boolean;
  authError: string | null;
  login: (email: string, password: string) => Promise<boolean>;
  adminLogin: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  adminLogout: () => void;
  session: Session | null;
  clearAuthError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Credenciais do administrador padrão
const ADMIN_CREDENTIALS = {
  email: 'pedroh3019999@gmail.com',
  password: 'Ph94581152',
  userData: {
    id: 'admin-1',
    name: 'Pedro Henrique',
    email: 'pedroh3019999@gmail.com',
    full_name: 'Pedro Henrique',
    permissions: ['manage_products', 'manage_orders', 'manage_users', 'manage_settings'],
    is_super_admin: true
  }
};

// Demo users for testing
const DEMO_USERS = [
  {
    email: 'usuario@teste.com',
    password: '123456',
    userData: {
      id: 'demo-user-1',
      name: 'Usuário Teste',
      email: 'usuario@teste.com',
      role: 'customer' as const
    }
  },
  {
    email: 'cliente@demo.com',
    password: 'demo123',
    userData: {
      id: 'demo-user-2',
      name: 'Cliente Demo',
      email: 'cliente@demo.com',
      role: 'customer' as const
    }
  }
];

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [initialized, setInitialized] = useState(false);

  const clearAuthError = () => {
    setAuthError(null);
  };

  // Demo mode authentication
  const authenticateDemo = async (email: string, password: string): Promise<{ success: boolean; userData?: any; isAdmin?: boolean }> => {
    // Check admin credentials
    if (email === ADMIN_CREDENTIALS.email && password === ADMIN_CREDENTIALS.password) {
      return {
        success: true,
        userData: ADMIN_CREDENTIALS.userData,
        isAdmin: true
      };
    }

    // Check demo users
    const demoUser = DEMO_USERS.find(u => u.email === email && u.password === password);
    if (demoUser) {
      return {
        success: true,
        userData: demoUser.userData,
        isAdmin: false
      };
    }

    return { success: false };
  };

  // Setup demo user
  const setupDemoUser = (userData: any, isAdmin: boolean = false) => {
    const user: User = {
      id: userData.id,
      name: userData.name,
      email: userData.email,
      addresses: [],
      orders: [],
      role: isAdmin ? 'admin' : 'customer'
    };

    setUser(user);

    if (isAdmin) {
      const adminData: AdminUser = {
        id: userData.id,
        name: userData.name,
        email: userData.email,
        role: 'admin',
        permissions: userData.permissions || []
      };
      setAdminUser(adminData);
    }

    // Store in localStorage for persistence
    localStorage.setItem('demo_user', JSON.stringify({ user, adminUser: isAdmin ? adminData : null }));
  };

  // Função para criar perfil do usuário no banco
  const createUserProfile = async (supabaseUser: SupabaseUser, fullName?: string) => {
    if (isDemoMode) {
      console.warn('Demo mode: skipping user profile creation');
      return null;
    }

    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .insert({
          id: supabaseUser.id,
          email: supabaseUser.email!,
          full_name: fullName || supabaseUser.user_metadata?.full_name || null,
          phone: supabaseUser.user_metadata?.phone || null,
        })
        .select()
        .single();

      if (error) {
        console.error('Erro ao criar perfil do usuário:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Erro ao criar perfil do usuário:', error);
      return null;
    }
  };

  // Função para buscar perfil do usuário
  const fetchUserProfile = async (userId: string) => {
    if (isDemoMode) {
      console.warn('Demo mode: skipping user profile fetch');
      return null;
    }

    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        console.error('Erro ao buscar perfil do usuário:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Erro ao buscar perfil do usuário:', error);
      return null;
    }
  };

  // Função para verificar se é administrador
  const checkAdminStatus = async (userId: string, email: string) => {
    try {
      // Primeiro verificar se é o admin padrão
      if (email === ADMIN_CREDENTIALS.email) {
        if (!isDemoMode) {
          // Verificar se existe na tabela admin_users, se não, criar
          try {
            const { data: existingAdmin } = await supabase
              .from('admin_users')
              .select('*')
              .eq('id', userId)
              .single();

            if (!existingAdmin) {
              // Criar registro de admin
              await supabase
                .from('admin_users')
                .insert({
                  id: userId,
                  email: email,
                  full_name: ADMIN_CREDENTIALS.userData.full_name,
                  permissions: ADMIN_CREDENTIALS.userData.permissions,
                  is_super_admin: true
                });
            }
          } catch (dbError) {
            console.warn('Could not create admin user in database, continuing with demo mode');
          }
        }

        return {
          id: userId,
          name: ADMIN_CREDENTIALS.userData.full_name,
          email: email,
          role: 'admin' as const,
          permissions: ADMIN_CREDENTIALS.userData.permissions
        };
      }

      if (isDemoMode) {
        return null;
      }

      // Verificar na tabela admin_users
      const { data: adminData, error } = await supabase
        .from('admin_users')
        .select('*')
        .eq('id', userId)
        .single();

      if (error || !adminData) {
        return null;
      }

      return {
        id: adminData.id,
        name: adminData.full_name,
        email: adminData.email,
        role: 'admin' as const,
        permissions: adminData.permissions || []
      };
    } catch (error) {
      console.error('Erro ao verificar status de admin:', error);
      return null;
    }
  };

  // Função para configurar usuário após autenticação
  const setupUser = async (supabaseUser: SupabaseUser) => {
    try {
      // Buscar perfil do usuário
      let userProfile = await fetchUserProfile(supabaseUser.id);
      
      // Se não existe, criar
      if (!userProfile && !isDemoMode) {
        userProfile = await createUserProfile(supabaseUser);
      }

      const userData: User = {
        id: supabaseUser.id,
        name: userProfile?.full_name || supabaseUser.user_metadata?.full_name || 'Usuário',
        email: supabaseUser.email!,
        addresses: [], // Será carregado quando necessário
        orders: [], // Será carregado quando necessário
        role: 'customer'
      };

      setUser(userData);

      // Verificar se é administrador
      const adminData = await checkAdminStatus(supabaseUser.id, supabaseUser.email!);
      if (adminData) {
        setAdminUser(adminData);
        // Atualizar role do usuário
        userData.role = 'admin';
        setUser(userData);
      }
    } catch (error) {
      console.error('Erro ao configurar usuário:', error);
      setAuthError('Erro ao configurar perfil do usuário');
    }
  };

  // Initialize authentication
  useEffect(() => {
    let mounted = true;
    let timeoutId: NodeJS.Timeout;

    const initializeAuth = async () => {
      try {
        setAuthError(null);

        if (isDemoMode) {
          console.log('🎭 Initializing in demo mode');
          // Demo mode - check localStorage for persisted session
          const storedUser = localStorage.getItem('demo_user');
          if (storedUser && mounted) {
            try {
              const { user: demoUser, adminUser: demoAdmin } = JSON.parse(storedUser);
              setUser(demoUser);
              if (demoAdmin) {
                setAdminUser(demoAdmin);
              }
              console.log('✅ Demo user restored from localStorage');
            } catch (parseError) {
              console.warn('Failed to parse stored demo user, clearing localStorage');
              localStorage.removeItem('demo_user');
            }
          }
          
          if (mounted) {
            setIsLoading(false);
            setInitialized(true);
          }
          return;
        }
        
        console.log('🔄 Initializing with Supabase');
        
        // Set a timeout to prevent infinite loading
        timeoutId = setTimeout(() => {
          if (mounted && !initialized) {
            console.warn('⚠️ Auth initialization timeout, falling back to demo mode');
            setIsLoading(false);
            setInitialized(true);
            setAuthError('Timeout na autenticação. Usando modo demonstração.');
          }
        }, 10000); // 10 second timeout
        
        // Real mode - check Supabase session
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (timeoutId) {
          clearTimeout(timeoutId);
        }
        
        if (error) {
          console.error('Erro ao obter sessão:', error);
          if (mounted) {
            setAuthError('Erro de autenticação: ' + error.message);
            setIsLoading(false);
            setInitialized(true);
          }
        } else if (session?.user && mounted) {
          console.log('✅ Session found, setting up user');
          setSession(session);
          await setupUser(session.user);
          if (mounted) {
            setIsLoading(false);
            setInitialized(true);
          }
        } else {
          console.log('ℹ️ No session found');
          if (mounted) {
            setIsLoading(false);
            setInitialized(true);
          }
        }
      } catch (error: any) {
        console.error('Erro ao inicializar autenticação:', error);
        if (timeoutId) {
          clearTimeout(timeoutId);
        }
        if (mounted) {
          setAuthError('Erro ao inicializar autenticação: ' + error.message);
          setIsLoading(false);
          setInitialized(true);
        }
      }
    };

    initializeAuth();

    // Only set up auth listener if not in demo mode
    let subscription: any = null;
    if (!isDemoMode) {
      try {
        const { data: { subscription: authSubscription } } = supabase.auth.onAuthStateChange(
          async (event, session) => {
            if (!mounted || !initialized) return;

            console.log('🔄 Auth state changed:', event, session?.user?.email);
            
            setSession(session);
            
            if (event === 'SIGNED_IN' && session?.user) {
              await setupUser(session.user);
            } else if (event === 'SIGNED_OUT') {
              setUser(null);
              setAdminUser(null);
            }
          }
        );
        subscription = authSubscription;
      } catch (error) {
        console.error('Failed to set up auth listener:', error);
      }
    }

    return () => {
      mounted = false;
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      if (subscription) {
        subscription.unsubscribe();
      }
    };
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      setIsLoading(true);
      setAuthError(null);

      if (isDemoMode) {
        console.log('🎭 Demo mode login attempt');
        // Demo mode authentication
        const result = await authenticateDemo(email, password);
        if (result.success) {
          setupDemoUser(result.userData, result.isAdmin);
          return true;
        } else {
          setAuthError('Email ou senha incorretos');
          return false;
        }
      }

      console.log('🔄 Real mode login attempt');
      // Real Supabase authentication
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        console.error('Erro no login:', error.message);
        
        if (error.message?.includes('Invalid login credentials')) {
          setAuthError('Email ou senha incorretos');
        } else if (error.message?.includes('Email not confirmed')) {
          setAuthError('Email não confirmado. Verifique sua caixa de entrada.');
        } else if (error.message?.includes('Too many requests')) {
          setAuthError('Muitas tentativas. Tente novamente em alguns minutos.');
        } else {
          setAuthError('Erro no login: ' + error.message);
        }
        return false;
      }

      if (data.user) {
        await setupUser(data.user);
        return true;
      }

      return false;
    } catch (error: any) {
      console.error('Erro no login:', error);
      setAuthError('Erro interno no login');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const adminLogin = async (email: string, password: string): Promise<boolean> => {
    // For admin, use the same login but verify admin credentials
    const result = await login(email, password);
    if (result && !adminUser && email !== ADMIN_CREDENTIALS.email) {
      setAuthError('Credenciais de administrador inválidas');
      return false;
    }
    return result;
  };

  const register = async (name: string, email: string, password: string): Promise<boolean> => {
    try {
      setIsLoading(true);
      setAuthError(null);
      
      // Validar inputs
      if (!name.trim()) {
        setAuthError('Nome é obrigatório');
        return false;
      }
      
      if (!email.trim()) {
        setAuthError('Email é obrigatório');
        return false;
      }
      
      if (!password || password.length < 6) {
        setAuthError('Senha deve ter pelo menos 6 caracteres');
        return false;
      }

      if (isDemoMode) {
        console.log('🎭 Demo mode registration');
        // Demo mode - create demo user
        const newDemoUser = {
          id: 'demo-user-' + Date.now(),
          name: name.trim(),
          email: email.trim(),
          role: 'customer' as const
        };
        
        setupDemoUser(newDemoUser, false);
        return true;
      }

      console.log('🔄 Real mode registration');
      // Real Supabase registration
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: name
          }
        }
      });

      if (error) {
        console.error('Erro no registro:', error.message);
        
        if (error.message?.includes('User already registered')) {
          setAuthError('Este email já está cadastrado');
        } else if (error.message?.includes('Password should be at least')) {
          setAuthError('A senha deve ter pelo menos 6 caracteres');
        } else {
          setAuthError('Erro no registro: ' + error.message);
        }
        return false;
      }

      if (data.user) {
        // O perfil será criado automaticamente pelo trigger ou pelo setupUser
        await setupUser(data.user);
        return true;
      }

      return false;
    } catch (error: any) {
      console.error('Erro no registro:', error);
      setAuthError('Erro interno no registro');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    try {
      setAuthError(null);

      if (isDemoMode) {
        console.log('🎭 Demo mode logout');
        // Demo mode logout
        localStorage.removeItem('demo_user');
        setUser(null);
        setAdminUser(null);
        return;
      }
      
      console.log('🔄 Real mode logout');
      const { error } = await supabase.auth.signOut();
      if (error) {
        console.error('Erro no logout:', error);
        setAuthError('Erro no logout: ' + error.message);
      }
      
      // Limpar estados locais
      setUser(null);
      setAdminUser(null);
      setSession(null);
      
      // Limpar localStorage
      localStorage.removeItem('comfydance_admin_session');
      localStorage.removeItem('demo_user');
    } catch (error: any) {
      console.error('Erro no logout:', error);
      setAuthError('Erro no logout');
    }
  };

  const adminLogout = () => {
    setAdminUser(null);
    localStorage.removeItem('comfydance_admin_session');
    
    if (isDemoMode) {
      // In demo mode, also clear the demo user
      localStorage.removeItem('demo_user');
      setUser(null);
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      adminUser,
      isAuthenticated: !!user,
      isAdmin: !!adminUser,
      isLoading,
      authError,
      login,
      adminLogin,
      register,
      logout,
      adminLogout,
      session,
      clearAuthError
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};