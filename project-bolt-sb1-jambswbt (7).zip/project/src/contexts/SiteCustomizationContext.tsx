import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';

interface SiteColors {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  text: string;
  headerBg: string;
  buttonBg: string;
  buttonText: string;
}

interface SiteImages {
  logo: string;
  heroBanner: string;
  categoryImages: {
    saltos: string;
    sapatilhas: string;
    masculinos: string;
  };
  footerBg: string;
}

interface SiteCustomizationContextType {
  colors: SiteColors;
  images: SiteImages;
  updateColors: (newColors: Partial<SiteColors>) => void;
  updateImages: (newImages: Partial<SiteImages>) => void;
  resetToDefaults: () => void;
}

const defaultColors: SiteColors = {
  primary: '#facc15', // yellow-400
  secondary: '#000000', // black
  accent: '#f59e0b', // amber-500
  background: '#ffffff', // white
  text: '#1f2937', // gray-800
  headerBg: '#000000', // black
  buttonBg: '#facc15', // yellow-400
  buttonText: '#000000' // black
};

const defaultImages: SiteImages = {
  logo: '',
  heroBanner: 'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=1920',
  categoryImages: {
    saltos: 'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=800',
    sapatilhas: 'https://images.pexels.com/photos/8923522/pexels-photo-8923522.jpeg?auto=compress&cs=tinysrgb&w=800',
    masculinos: 'https://images.pexels.com/photos/1598663/pexels-photo-1598663.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  footerBg: ''
};

const SiteCustomizationContext = createContext<SiteCustomizationContextType | undefined>(undefined);

export const SiteCustomizationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [colors, setColors] = useState<SiteColors>(defaultColors);
  const [images, setImages] = useState<SiteImages>(defaultImages);

  // Carregar configurações salvas
  useEffect(() => {
    const savedColors = localStorage.getItem('comfydance_colors');
    const savedImages = localStorage.getItem('comfydance_images');
    
    if (savedColors) {
      try {
        const parsedColors = JSON.parse(savedColors);
        setColors(parsedColors);
      } catch (error) {
        console.error('Erro ao carregar cores salvas:', error);
      }
    }
    
    if (savedImages) {
      try {
        const parsedImages = JSON.parse(savedImages);
        setImages(parsedImages);
      } catch (error) {
        console.error('Erro ao carregar imagens salvas:', error);
      }
    }
  }, []);

  // Aplicar cores CSS customizadas sempre que as cores mudarem
  useEffect(() => {
    const root = document.documentElement;
    
    // Aplicar variáveis CSS customizadas
    root.style.setProperty('--color-primary', colors.primary);
    root.style.setProperty('--color-secondary', colors.secondary);
    root.style.setProperty('--color-accent', colors.accent);
    root.style.setProperty('--color-background', colors.background);
    root.style.setProperty('--color-text', colors.text);
    root.style.setProperty('--color-header-bg', colors.headerBg);
    root.style.setProperty('--color-button-bg', colors.buttonBg);
    root.style.setProperty('--color-button-text', colors.buttonText);

    // Aplicar cores específicas do Tailwind dinamicamente
    const style = document.getElementById('dynamic-colors') || document.createElement('style');
    style.id = 'dynamic-colors';
    
    style.textContent = `
      .bg-primary { background-color: ${colors.primary} !important; }
      .bg-secondary { background-color: ${colors.secondary} !important; }
      .bg-accent { background-color: ${colors.accent} !important; }
      .text-primary { color: ${colors.primary} !important; }
      .text-secondary { color: ${colors.secondary} !important; }
      .text-accent { color: ${colors.accent} !important; }
      .border-primary { border-color: ${colors.primary} !important; }
      .border-secondary { border-color: ${colors.secondary} !important; }
      
      .btn-primary {
        background-color: ${colors.buttonBg} !important;
        color: ${colors.buttonText} !important;
      }
      
      .btn-primary:hover {
        background-color: ${colors.buttonBg} !important;
        filter: brightness(0.9);
      }
      
      .header-bg {
        background-color: ${colors.headerBg} !important;
      }
      
      /* Aplicar cores específicas aos elementos do site */
      .bg-yellow-400 { background-color: ${colors.primary} !important; }
      .text-yellow-400 { color: ${colors.primary} !important; }
      .text-yellow-600 { color: ${colors.accent} !important; }
      .bg-black { background-color: ${colors.secondary} !important; }
      .text-black { color: ${colors.secondary} !important; }
      
      /* Botões específicos */
      .bg-yellow-400:hover { 
        background-color: ${colors.primary} !important; 
        filter: brightness(0.9);
      }
      
      /* Header específico */
      header.bg-black { background-color: ${colors.headerBg} !important; }
      
      /* Focus states */
      .focus\\:ring-yellow-400:focus {
        --tw-ring-color: ${colors.primary} !important;
      }
      
      .focus\\:border-yellow-400:focus {
        border-color: ${colors.primary} !important;
      }
    `;
    
    if (!document.head.contains(style)) {
      document.head.appendChild(style);
    }
  }, [colors]);

  const updateColors = (newColors: Partial<SiteColors>) => {
    const updatedColors = { ...colors, ...newColors };
    setColors(updatedColors);
    localStorage.setItem('comfydance_colors', JSON.stringify(updatedColors));
  };

  const updateImages = (newImages: Partial<SiteImages>) => {
    const updatedImages = { ...images, ...newImages };
    setImages(updatedImages);
    localStorage.setItem('comfydance_images', JSON.stringify(updatedImages));
  };

  const resetToDefaults = () => {
    setColors(defaultColors);
    setImages(defaultImages);
    localStorage.removeItem('comfydance_colors');
    localStorage.removeItem('comfydance_images');
    
    // Remover estilos dinâmicos
    const dynamicStyle = document.getElementById('dynamic-colors');
    if (dynamicStyle) {
      dynamicStyle.remove();
    }
  };

  return (
    <SiteCustomizationContext.Provider value={{
      colors,
      images,
      updateColors,
      updateImages,
      resetToDefaults
    }}>
      {children}
    </SiteCustomizationContext.Provider>
  );
};

export const useSiteCustomization = () => {
  const context = useContext(SiteCustomizationContext);
  if (context === undefined) {
    throw new Error('useSiteCustomization must be used within a SiteCustomizationProvider');
  }
  return context;
};