import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Sapato de Salto Alto Clássico',
    description: 'Elegante sapato de salto alto em couro premium, perfeito para apresentações e eventos especiais. Solado antiderrapante e palmilha almofadada para máximo conforto.',
    price: 299.90,
    originalPrice: 399.90,
    images: [
      'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1598508/pexels-photo-1598508.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    colorImages: {
      'Preto': [
        'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/1598508/pexels-photo-1598508.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      'Nude': [
        'https://images.pexels.com/photos/1598507/pexels-photo-1598507.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      'Vermelho': [
        'https://images.pexels.com/photos/1598663/pexels-photo-1598663.jpeg?auto=compress&cs=tinysrgb&w=800'
      ]
    },
    category: 'saltos',
    sizes: ['34', '35', '36', '37', '38', '39', '40'],
    colors: ['Preto', 'Nude', 'Vermelho'],
    inStock: true,
    featured: true,
    rating: 4.8,
    reviews: 124
  },
  {
    id: '2',
    name: 'Sapatilha de Ballet Profissional',
    description: 'Sapatilha de ponta para ballet profissional com caixa reforçada e fitas de cetim. Fabricada com materiais de alta qualidade para durabilidade superior.',
    price: 189.90,
    images: [
      'https://images.pexels.com/photos/8923522/pexels-photo-8923522.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/8923523/pexels-photo-8923523.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    colorImages: {
      'Rosa': [
        'https://images.pexels.com/photos/8923522/pexels-photo-8923522.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/8923523/pexels-photo-8923523.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      'Branco': [
        'https://images.pexels.com/photos/8923520/pexels-photo-8923520.jpeg?auto=compress&cs=tinysrgb&w=800'
      ]
    },
    category: 'sapatilhas',
    sizes: ['34', '35', '36', '37', '38', '39'],
    colors: ['Rosa', 'Branco'],
    inStock: true,
    featured: true,
    rating: 4.9,
    reviews: 89
  },
  {
    id: '3',
    name: 'Sapato Social Masculino para Dança',
    description: 'Sapato social masculino especialmente desenvolvido para dança de salão. Solado flexível e cabedal em couro legitimo com acabamento refinado.',
    price: 249.90,
    images: [
      'https://images.pexels.com/photos/1598663/pexels-photo-1598663.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1598664/pexels-photo-1598664.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    colorImages: {
      'Preto': [
        'https://images.pexels.com/photos/1598663/pexels-photo-1598663.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/1598664/pexels-photo-1598664.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      'Marrom': [
        'https://images.pexels.com/photos/1598657/pexels-photo-1598657.jpeg?auto=compress&cs=tinysrgb&w=800'
      ]
    },
    category: 'masculinos',
    sizes: ['38', '39', '40', '41', '42', '43', '44'],
    colors: ['Preto', 'Marrom'],
    inStock: true,
    featured: true,
    rating: 4.7,
    reviews: 156
  },
  {
    id: '4',
    name: 'Sandália de Salto para Dança Latina',
    description: 'Sandália feminina com salto ideal para dança latina. Tiras ajustáveis e solado profissional para melhor aderência e movimento.',
    price: 219.90,
    originalPrice: 279.90,
    images: [
      'https://images.pexels.com/photos/1598507/pexels-photo-1598507.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    colorImages: {
      'Nude': [
        'https://images.pexels.com/photos/1598507/pexels-photo-1598507.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      'Dourado': [
        'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      'Prata': [
        'https://images.pexels.com/photos/1598508/pexels-photo-1598508.jpeg?auto=compress&cs=tinysrgb&w=800'
      ]
    },
    category: 'saltos',
    sizes: ['34', '35', '36', '37', '38', '39'],
    colors: ['Nude', 'Dourado', 'Prata'],
    inStock: true,
    rating: 4.6,
    reviews: 73
  },
  {
    id: '5',
    name: 'Sapatilha de Jazz Moderna',
    description: 'Sapatilha flexível para jazz e dança moderna. Material respirável e solado dividido para máxima flexibilidade e conforto.',
    price: 159.90,
    images: [
      'https://images.pexels.com/photos/8923520/pexels-photo-8923520.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    colorImages: {
      'Preto': [
        'https://images.pexels.com/photos/8923520/pexels-photo-8923520.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      'Bege': [
        'https://images.pexels.com/photos/8923522/pexels-photo-8923522.jpeg?auto=compress&cs=tinysrgb&w=800'
      ]
    },
    category: 'sapatilhas',
    sizes: ['34', '35', '36', '37', '38', '39', '40'],
    colors: ['Preto', 'Bege'],
    inStock: true,
    rating: 4.5,
    reviews: 92
  },
  {
    id: '6',
    name: 'Bota Masculina para Dança Country',
    description: 'Bota masculina estilo country para dança. Couro genuíno com solado antiderrapante e design tradicional americano.',
    price: 329.90,
    images: [
      'https://images.pexels.com/photos/1598657/pexels-photo-1598657.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    colorImages: {
      'Marrom': [
        'https://images.pexels.com/photos/1598657/pexels-photo-1598657.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      'Preto': [
        'https://images.pexels.com/photos/1598663/pexels-photo-1598663.jpeg?auto=compress&cs=tinysrgb&w=800'
      ]
    },
    category: 'masculinos',
    sizes: ['38', '39', '40', '41', '42', '43', '44', '45'],
    colors: ['Marrom', 'Preto'],
    inStock: true,
    rating: 4.8,
    reviews: 67
  }
];