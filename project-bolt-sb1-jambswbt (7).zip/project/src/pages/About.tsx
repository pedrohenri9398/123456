import React from 'react';
import { Award, Heart, Users, Star, ShoppingBag, Truck, Code, Instagram } from 'lucide-react';

interface AboutProps {
  onNavigate: (page: string) => void;
}

const About: React.FC<AboutProps> = ({ onNavigate }) => {
  const stats = [
    { icon: Users, label: 'Clientes Satisfeitos', value: '10.000+' },
    { icon: ShoppingBag, label: 'Produtos Vendidos', value: '25.000+' },
    { icon: Award, label: 'Anos de Experiência', value: '15+' },
    { icon: Star, label: 'Avaliação Média', value: '4.9/5' }
  ];

  const values = [
    {
      icon: Heart,
      title: 'Paixão pela Dança',
      description: 'Vivemos e respiramos dança. Cada produto é desenvolvido com amor e dedicação para os dançarinos.'
    },
    {
      icon: Award,
      title: 'Qualidade Premium',
      description: 'Utilizamos apenas materiais de primeira qualidade e técnicas artesanais para garantir durabilidade.'
    },
    {
      icon: Users,
      title: 'Atendimento Personalizado',
      description: 'Nossa equipe especializada está sempre pronta para ajudar você a encontrar o calçado perfeito.'
    },
    {
      icon: Truck,
      title: 'Entrega Confiável',
      description: 'Garantimos que seus produtos chegem rapidamente e em perfeitas condições.'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-black to-gray-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Nossa <span className="text-yellow-400">História</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Há mais de 15 anos, a Comfydance nasceu do sonho de dois dançarinos apaixonados 
            que buscavam calçados que combinassem conforto, qualidade e elegância.
          </p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="bg-yellow-400 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-8 h-8 text-black" />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                A Jornada da <span className="text-yellow-600">Comfydance</span>
              </h2>
              
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  Tudo começou em 2009, quando Marina e Carlos, dois profissionais da dança, 
                  perceberam a dificuldade de encontrar calçados que oferecessem o equilíbrio 
                  perfeito entre conforto, durabilidade e estilo.
                </p>
                
                <p>
                  Após anos dançando com sapatos desconfortáveis e de baixa qualidade, 
                  eles decidiram criar sua própria marca. O objetivo era claro: desenvolver 
                  calçados especificamente pensados para dançarinos, feitos por quem 
                  realmente entende as necessidades dessa arte.
                </p>
                
                <p>
                  Hoje, com sede em <strong>Brasília, DF</strong>, a Comfydance é referência nacional 
                  em calçados para dança, atendendo desde iniciantes até profissionais renomados. 
                  Nossa missão continua a mesma: permitir que cada dançarino expresse sua arte 
                  com total conforto e elegância.
                </p>

                <div className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-400">
                  <p className="text-sm text-gray-700">
                    <strong>💡 Curiosidade:</strong> Este site foi desenvolvido com carinho em 
                    <strong> Luziânia, GO</strong>, demonstrando que a tecnologia e a inovação 
                    podem florescer em qualquer lugar do Brasil!
                  </p>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/8923522/pexels-photo-8923522.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="História da Comfydance"
                className="rounded-2xl shadow-xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Nossos <span className="text-yellow-400">Valores</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Os princípios que guiam cada decisão e cada produto que criamos
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <div key={index} className="text-center space-y-4">
                  <div className="bg-yellow-400 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                    <Icon className="w-8 h-8 text-black" />
                  </div>
                  <h3 className="text-xl font-semibold">{value.title}</h3>
                  <p className="text-gray-300 leading-relaxed">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 bg-yellow-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8">
            Nossa <span className="text-yellow-600">Missão</span>
          </h2>
          
          <div className="bg-white p-8 rounded-2xl shadow-lg">
            <blockquote className="text-xl text-gray-700 italic leading-relaxed mb-6">
              "Capacitar dançarinos de todos os níveis com calçados excepcionais que 
              combinam conforto, qualidade e estilo, permitindo que cada pessoa expresse 
              sua paixão pela dança com total confiança e elegância."
            </blockquote>
            
            <div className="flex items-center justify-center space-x-4 text-gray-600">
              <div className="w-12 h-0.5 bg-yellow-400"></div>
              <span className="font-medium">Comfydance Team - Brasília, DF</span>
              <div className="w-12 h-0.5 bg-yellow-400"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Location Section */}
      <section className="py-16 bg-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Nossa <span className="text-yellow-600">Localização</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Atendemos todo o Brasil a partir do coração do país
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Loja */}
            <div className="bg-white p-8 rounded-xl shadow-md text-center">
              <div className="bg-yellow-400 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShoppingBag className="w-8 h-8 text-black" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Nossa Loja</h3>
              <p className="text-lg font-medium text-yellow-600 mb-2">Brasília, DF</p>
              <p className="text-gray-600 text-sm">
                Centro de operações e atendimento ao cliente
              </p>
              <p className="text-gray-500 text-xs mt-2">
                Entregamos para todo o Brasil com frete grátis acima de R$ 200,00
              </p>
            </div>

            {/* Desenvolvimento */}
            <div className="bg-white p-8 rounded-xl shadow-md text-center">
              <div className="bg-green-400 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Desenvolvimento</h3>
              <p className="text-lg font-medium text-green-600 mb-2">Luziânia, GO</p>
              <p className="text-gray-600 text-sm">
                Onde a tecnologia e inovação se encontram
              </p>
              <p className="text-gray-500 text-xs mt-2">
                Site desenvolvido com tecnologia de ponta e muito carinho
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Developer Section */}
      <section className="py-16 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8">
            <div className="flex flex-col items-center space-y-6">
              <div className="bg-white/20 w-20 h-20 rounded-full flex items-center justify-center">
                <Code className="w-10 h-10 text-white" />
              </div>
              
              <div>
                <h2 className="text-3xl font-bold mb-2">Desenvolvido por Henrique</h2>
                <p className="text-purple-100 text-lg mb-4">
                  Full Stack Developer • Luziânia, GO
                </p>
                <p className="text-purple-100 max-w-2xl mx-auto leading-relaxed">
                  Especialista em desenvolvimento web moderno, criando soluções digitais 
                  inovadoras que conectam negócios aos seus clientes com tecnologia de ponta.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
                <a
                  href="https://instagram.com/henrique_9397"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-3 bg-white text-purple-600 px-6 py-3 rounded-full hover:bg-purple-50 transition-all duration-300 transform hover:scale-105 font-semibold"
                >
                  <Instagram className="w-5 h-5" />
                  <span>@henrique_9397</span>
                </a>
                
                <div className="flex items-center space-x-4 text-purple-100">
                  <div className="text-center">
                    <p className="text-sm font-medium">💻 Tecnologias</p>
                    <p className="text-xs">React • Node.js • TypeScript</p>
                  </div>
                  <div className="w-px h-8 bg-purple-300"></div>
                  <div className="text-center">
                    <p className="text-sm font-medium">🚀 Especialidade</p>
                    <p className="text-xs">E-commerce • SaaS • Apps</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-black text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Faça Parte da Nossa <span className="text-yellow-400">Família</span>
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Junte-se a milhares de dançarinos que já descobriram a diferença 
            de calçar Comfydance. Sua jornada de dança merece o melhor.
          </p>
          
          <div className="space-y-4 md:space-y-0 md:space-x-4 md:flex justify-center">
            <button
              onClick={() => onNavigate('shop')}
              className="w-full md:w-auto bg-yellow-400 text-black px-8 py-4 rounded-lg font-semibold hover:bg-yellow-500 transition-colors"
            >
              Explore Nossa Coleção
            </button>
            <button
              onClick={() => onNavigate('contact')}
              className="w-full md:w-auto border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-black transition-colors"
            >
              Entre em Contato
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;