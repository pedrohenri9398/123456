import React, { useState, useEffect } from 'react';
import { 
  Package, 
  Eye, 
  Calendar, 
  CreditCard, 
  MapPin, 
  AlertCircle, 
  Search, 
  Filter, 
  RefreshCw, 
  ShoppingBag,
  Clock,
  CheckCircle,
  XCircle,
  Truck,
  DollarSign,
  FileText,
  Star,
  MessageCircle
} from 'lucide-react';
import { Order } from '../types';
import { isDemoMode } from '../lib/supabase';

interface MyOrdersProps {
  onNavigate: (page: string) => void;
}

const MyOrders: React.FC<MyOrdersProps> = ({ onNavigate }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [paymentFilter, setPaymentFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('all');
  const [activeTab, setActiveTab] = useState('all');

  // Mock orders with different statuses for demonstration
  const mockOrders: Order[] = [
    {
      id: 'demo-order-1',
      orderNumber: 'CD001',
      items: [
        {
          product: {
            id: '1',
            name: 'Sapato de Salto Alto Clássico',
            description: 'Elegante sapato de salto alto',
            price: 299.90,
            images: ['https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=800'],
            category: 'saltos',
            sizes: ['37'],
            colors: ['Preto'],
            inStock: true,
            rating: 4.8,
            reviews: 124
          },
          size: '37',
          color: 'Preto',
          quantity: 1
        }
      ],
      total: 314.90,
      status: 'delivered',
      paymentStatus: 'paid',
      createdAt: new Date('2024-01-15T10:30:00'),
      shippingAddress: {
        id: '1',
        street: 'Rua das Flores',
        number: '123',
        neighborhood: 'Centro',
        city: 'São Paulo',
        state: 'SP',
        zipCode: '01234-567',
        isDefault: true
      },
      paymentMethod: 'pix',
      customerName: 'Ana Silva',
      customerEmail: 'ana@email.com',
      trackingCode: 'BR123456789CD'
    },
    {
      id: 'demo-order-2',
      orderNumber: 'CD002',
      items: [
        {
          product: {
            id: '2',
            name: 'Sapatilha de Ballet Profissional',
            description: 'Sapatilha de ponta para ballet',
            price: 189.90,
            images: ['https://images.pexels.com/photos/8923522/pexels-photo-8923522.jpeg?auto=compress&cs=tinysrgb&w=800'],
            category: 'sapatilhas',
            sizes: ['39'],
            colors: ['Rosa'],
            inStock: true,
            rating: 4.9,
            reviews: 89
          },
          size: '39',
          color: 'Rosa',
          quantity: 1
        }
      ],
      total: 205.80,
      status: 'shipped',
      paymentStatus: 'paid',
      createdAt: new Date('2024-01-14T14:20:00'),
      shippingAddress: {
        id: '1',
        street: 'Rua das Flores',
        number: '123',
        neighborhood: 'Centro',
        city: 'São Paulo',
        state: 'SP',
        zipCode: '01234-567',
        isDefault: true
      },
      paymentMethod: 'boleto',
      customerName: 'Ana Silva',
      customerEmail: 'ana@email.com',
      trackingCode: 'BR987654321CD'
    },
    {
      id: 'demo-order-3',
      orderNumber: 'CD003',
      items: [
        {
          product: {
            id: '3',
            name: 'Sapato Social Masculino para Dança',
            description: 'Sapato social masculino especialmente desenvolvido',
            price: 249.90,
            images: ['https://images.pexels.com/photos/1598663/pexels-photo-1598663.jpeg?auto=compress&cs=tinysrgb&w=800'],
            category: 'masculinos',
            sizes: ['42'],
            colors: ['Preto'],
            inStock: true,
            rating: 4.7,
            reviews: 156
          },
          size: '42',
          color: 'Preto',
          quantity: 1
        }
      ],
      total: 265.80,
      status: 'processing',
      paymentStatus: 'paid',
      createdAt: new Date('2024-01-13T09:15:00'),
      shippingAddress: {
        id: '1',
        street: 'Rua das Flores',
        number: '123',
        neighborhood: 'Centro',
        city: 'São Paulo',
        state: 'SP',
        zipCode: '01234-567',
        isDefault: true
      },
      paymentMethod: 'pix',
      customerName: 'Ana Silva',
      customerEmail: 'ana@email.com'
    },
    {
      id: 'demo-order-4',
      orderNumber: 'CD004',
      items: [
        {
          product: {
            id: '4',
            name: 'Sandália de Salto para Dança Latina',
            description: 'Sandália feminina com salto ideal',
            price: 219.90,
            images: ['https://images.pexels.com/photos/1598507/pexels-photo-1598507.jpeg?auto=compress&cs=tinysrgb&w=800'],
            category: 'saltos',
            sizes: ['36'],
            colors: ['Dourado'],
            inStock: true,
            rating: 4.6,
            reviews: 73
          },
          size: '36',
          color: 'Dourado',
          quantity: 1
        }
      ],
      total: 235.80,
      status: 'pending',
      paymentStatus: 'pending',
      createdAt: new Date('2024-01-12T16:45:00'),
      shippingAddress: {
        id: '1',
        street: 'Rua das Flores',
        number: '123',
        neighborhood: 'Centro',
        city: 'São Paulo',
        state: 'SP',
        zipCode: '01234-567',
        isDefault: true
      },
      paymentMethod: 'boleto',
      customerName: 'Ana Silva',
      customerEmail: 'ana@email.com'
    },
    {
      id: 'demo-order-5',
      orderNumber: 'CD005',
      items: [
        {
          product: {
            id: '5',
            name: 'Sapatilha de Jazz Moderna',
            description: 'Sapatilha flexível para jazz',
            price: 159.90,
            images: ['https://images.pexels.com/photos/8923520/pexels-photo-8923520.jpeg?auto=compress&cs=tinysrgb&w=800'],
            category: 'sapatilhas',
            sizes: ['38'],
            colors: ['Preto'],
            inStock: true,
            rating: 4.5,
            reviews: 92
          },
          size: '38',
          color: 'Preto',
          quantity: 2
        }
      ],
      total: 335.70,
      status: 'cancelled',
      paymentStatus: 'cancelled',
      createdAt: new Date('2024-01-10T11:20:00'),
      shippingAddress: {
        id: '1',
        street: 'Rua das Flores',
        number: '123',
        neighborhood: 'Centro',
        city: 'São Paulo',
        state: 'SP',
        zipCode: '01234-567',
        isDefault: true
      },
      paymentMethod: 'pix',
      customerName: 'Ana Silva',
      customerEmail: 'ana@email.com'
    }
  ];

  // Status tabs configuration
  const statusTabs = [
    { 
      id: 'all', 
      name: 'Todos', 
      icon: Package, 
      count: mockOrders.length,
      color: 'text-gray-600'
    },
    { 
      id: 'pending', 
      name: 'Aguardando Pagamento', 
      icon: Clock, 
      count: mockOrders.filter(o => o.paymentStatus === 'pending').length,
      color: 'text-yellow-600'
    },
    { 
      id: 'processing', 
      name: 'Confirmado pelo Vendedor', 
      icon: CheckCircle, 
      count: mockOrders.filter(o => o.status === 'processing').length,
      color: 'text-blue-600'
    },
    { 
      id: 'shipped', 
      name: 'Em Rastreio', 
      icon: Truck, 
      count: mockOrders.filter(o => o.status === 'shipped').length,
      color: 'text-purple-600'
    },
    { 
      id: 'delivered', 
      name: 'Entregue', 
      icon: CheckCircle, 
      count: mockOrders.filter(o => o.status === 'delivered').length,
      color: 'text-green-600'
    },
    { 
      id: 'cancelled', 
      name: 'Cancelado', 
      icon: XCircle, 
      count: mockOrders.filter(o => o.status === 'cancelled').length,
      color: 'text-red-600'
    }
  ];

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    setLoading(true);

    try {
      // Simulate loading
      await new Promise(resolve => setTimeout(resolve, 1000));

      if (isDemoMode) {
        // Demo mode - use mock orders
        setOrders(mockOrders);
      } else {
        // In production, load from database or localStorage
        const storedOrders = localStorage.getItem('user_orders');
        if (storedOrders) {
          const parsedOrders = JSON.parse(storedOrders);
          setOrders(parsedOrders);
        } else {
          // No orders found
          setOrders([]);
        }
      }
    } catch (error) {
      console.error('Error loading orders:', error);
      // Fallback to demo orders
      setOrders(mockOrders);
    } finally {
      setLoading(false);
    }
  };

  const filteredOrders = orders.filter(order => {
    const matchesSearch = 
      order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.items.some(item => 
        item.product.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    const matchesPayment = paymentFilter === 'all' || order.paymentStatus === paymentFilter;
    
    // Tab filtering
    let matchesTab = true;
    if (activeTab === 'pending') {
      matchesTab = order.paymentStatus === 'pending';
    } else if (activeTab === 'processing') {
      matchesTab = order.status === 'processing';
    } else if (activeTab === 'shipped') {
      matchesTab = order.status === 'shipped';
    } else if (activeTab === 'delivered') {
      matchesTab = order.status === 'delivered';
    } else if (activeTab === 'cancelled') {
      matchesTab = order.status === 'cancelled';
    }

    // Date filtering
    let matchesDate = true;
    if (dateFilter !== 'all') {
      const orderDate = new Date(order.createdAt);
      const now = new Date();
      
      switch (dateFilter) {
        case 'week':
          matchesDate = (now.getTime() - orderDate.getTime()) <= 7 * 24 * 60 * 60 * 1000;
          break;
        case 'month':
          matchesDate = (now.getTime() - orderDate.getTime()) <= 30 * 24 * 60 * 60 * 1000;
          break;
        case 'quarter':
          matchesDate = (now.getTime() - orderDate.getTime()) <= 90 * 24 * 60 * 60 * 1000;
          break;
      }
    }
    
    return matchesSearch && matchesStatus && matchesPayment && matchesTab && matchesDate;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'processing':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'shipped':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'delivered':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      case 'expired':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'pending':
        return 'Pendente';
      case 'processing':
        return 'Processando';
      case 'shipped':
        return 'Enviado';
      case 'delivered':
        return 'Entregue';
      case 'cancelled':
        return 'Cancelado';
      default:
        return status;
    }
  };

  const getPaymentStatusLabel = (status: string) => {
    switch (status) {
      case 'paid':
        return 'Pago';
      case 'pending':
        return 'Pendente';
      case 'cancelled':
        return 'Cancelado';
      case 'expired':
        return 'Expirado';
      default:
        return status;
    }
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const getOrderActions = (order: Order) => {
    const actions = [];

    // Always show view details
    actions.push({
      label: 'Ver Detalhes',
      icon: Eye,
      action: () => onNavigate(`order-view-${order.orderNumber}`),
      color: 'bg-blue-600 hover:bg-blue-700 text-white'
    });

    // Status-specific actions
    if (order.status === 'delivered') {
      actions.push({
        label: 'Avaliar',
        icon: Star,
        action: () => onNavigate(`product-${order.items[0].product.id}`),
        color: 'bg-yellow-500 hover:bg-yellow-600 text-white'
      });
    }

    if (order.status === 'shipped' && order.trackingCode) {
      actions.push({
        label: 'Rastrear',
        icon: Truck,
        action: () => onNavigate('order-tracking'),
        color: 'bg-purple-600 hover:bg-purple-700 text-white'
      });
    }

    if (order.paymentStatus === 'pending') {
      actions.push({
        label: 'Pagar',
        icon: DollarSign,
        action: () => onNavigate('checkout'),
        color: 'bg-green-600 hover:bg-green-700 text-white'
      });
    }

    if (order.status === 'pending' || order.status === 'processing') {
      actions.push({
        label: 'Cancelar',
        icon: XCircle,
        action: () => {
          if (confirm('Tem certeza que deseja cancelar este pedido?')) {
            alert('Pedido cancelado com sucesso!');
          }
        },
        color: 'bg-red-600 hover:bg-red-700 text-white'
      });
    }

    return actions;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-gray-600" />
          <p className="text-gray-600">Carregando seus pedidos...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4">
            Meus Pedidos
            {isDemoMode && <span className="text-sm text-blue-600 ml-2">(Demo)</span>}
          </h1>
          <p className="text-gray-600">
            Acompanhe todos os seus pedidos e o status de entrega
          </p>
        </div>

        {/* Demo Notice */}
        {isDemoMode && (
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-blue-600 mr-2" />
              <div className="flex-1">
                <p className="text-blue-700 text-sm">
                  <strong>Modo Demonstração:</strong> Estes são pedidos fictícios para demonstração.
                </p>
                <p className="text-blue-600 text-xs mt-1">
                  Explore as diferentes funcionalidades usando as abas e filtros abaixo.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Status Tabs */}
        <div className="mb-6">
          <div className="bg-white rounded-lg shadow-md p-4">
            <div className="flex flex-wrap gap-2">
              {statusTabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeTab === tab.id
                        ? 'bg-gray-100 shadow-sm ' + tab.color
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{tab.name}</span>
                    {tab.count > 0 && (
                      <span className={`px-1.5 py-0.5 rounded-full text-xs ${
                        activeTab === tab.id ? 'bg-white' : 'bg-gray-100'
                      }`}>
                        {tab.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Advanced Filters */}
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-gray-900 flex items-center">
              <Filter className="w-4 h-4 mr-2" />
              Filtros Avançados
            </h3>
            <button
              onClick={loadOrders}
              className="flex items-center space-x-2 px-3 py-1.5 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-sm"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Atualizar</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Search */}
            <div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Buscar por número ou produto..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
                />
              </div>
            </div>
            
            {/* Status Filter */}
            <div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              >
                <option value="all">Todos os Status</option>
                <option value="pending">Pendente</option>
                <option value="processing">Processando</option>
                <option value="shipped">Enviado</option>
                <option value="delivered">Entregue</option>
                <option value="cancelled">Cancelado</option>
              </select>
            </div>

            {/* Date Filter */}
            <div>
              <select
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              >
                <option value="all">Qualquer Data</option>
                <option value="week">Últimos 7 dias</option>
                <option value="month">Últimos 30 dias</option>
                <option value="quarter">Últimos 3 meses</option>
              </select>
            </div>
          </div>
        </div>

        {/* Order Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-4 rounded-lg shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total de Pedidos</p>
                <p className="text-xl font-bold text-gray-900">{orders.length}</p>
              </div>
              <Package className="w-8 h-8 text-gray-400" />
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Aguardando Pagamento</p>
                <p className="text-xl font-bold text-yellow-600">
                  {orders.filter(o => o.paymentStatus === 'pending').length}
                </p>
              </div>
              <Clock className="w-8 h-8 text-yellow-400" />
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Em Trânsito</p>
                <p className="text-xl font-bold text-purple-600">
                  {orders.filter(o => o.status === 'shipped').length}
                </p>
              </div>
              <Truck className="w-8 h-8 text-purple-400" />
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Entregues</p>
                <p className="text-xl font-bold text-green-600">
                  {orders.filter(o => o.status === 'delivered').length}
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
          </div>
        </div>

        {/* Orders List */}
        {filteredOrders.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-8 sm:p-12 text-center">
            <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              {orders.length === 0 ? 'Nenhum pedido encontrado' : 'Nenhum pedido corresponde aos filtros'}
            </h3>
            <p className="text-gray-600 mb-6">
              {orders.length === 0 
                ? 'Você ainda não fez nenhum pedido. Que tal começar agora?'
                : 'Tente ajustar os filtros de busca para encontrar seus pedidos.'
              }
            </p>
            <button
              onClick={() => onNavigate('shop')}
              className="bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors font-medium"
            >
              Ir às Compras
            </button>
          </div>
        ) : (
          <div className="space-y-4 sm:space-y-6">
            {filteredOrders.map((order) => (
              <div key={order.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                {/* Order Header */}
                <div className="p-4 sm:p-6 border-b border-gray-200">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center space-x-4">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">
                          Pedido {order.orderNumber}
                        </h3>
                        <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                          <div className="flex items-center space-x-1">
                            <Calendar className="w-4 h-4" />
                            <span>{formatDate(order.createdAt)}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <CreditCard className="w-4 h-4" />
                            <span>{order.paymentMethod.toUpperCase()}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="flex flex-col items-end">
                        <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(order.status)}`}>
                          {getStatusLabel(order.status)}
                        </span>
                        <span className={`mt-1 px-2 py-0.5 rounded-full text-xs font-medium ${getPaymentStatusColor(order.paymentStatus)}`}>
                          {getPaymentStatusLabel(order.paymentStatus)}
                        </span>
                      </div>
                      <span className="text-lg font-bold text-gray-900">
                        R$ {order.total.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Order Items */}
                <div className="p-4 sm:p-6">
                  <div className="space-y-3">
                    {order.items.slice(0, 2).map((item, index) => (
                      <div key={index} className="flex items-center space-x-3 sm:space-x-4">
                        <img
                          src={item.product.images[0]}
                          alt={item.product.name}
                          className="w-12 h-12 sm:w-16 sm:h-16 object-cover rounded-lg flex-shrink-0"
                        />
                        
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-gray-900 text-sm sm:text-base line-clamp-1">
                            {item.product.name}
                          </h4>
                          <div className="text-xs sm:text-sm text-gray-600 mt-1">
                            <span>Tamanho: {item.size}</span>
                            <span className="mx-2">•</span>
                            <span>Cor: {item.color}</span>
                            <span className="mx-2">•</span>
                            <span>Qtd: {item.quantity}</span>
                          </div>
                        </div>
                        
                        <div className="text-right flex-shrink-0">
                          <p className="font-semibold text-gray-900 text-sm sm:text-base">
                            R$ {(item.product.price * item.quantity).toFixed(2)}
                          </p>
                        </div>
                      </div>
                    ))}
                    
                    {order.items.length > 2 && (
                      <div className="text-sm text-gray-600 text-center py-2">
                        + {order.items.length - 2} item(s) adicional(is)
                      </div>
                    )}
                  </div>
                </div>

                {/* Order Status Timeline */}
                <div className="px-4 sm:px-6 py-3 bg-gray-50 border-t border-b border-gray-200">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-medium text-gray-700">Status do Pedido</h4>
                    <span className="text-xs text-gray-500">Atualizado em {formatDate(order.createdAt)}</span>
                  </div>
                  
                  <div className="mt-3 relative">
                    <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-full h-1 bg-gray-200 rounded"></div>
                    <div className="relative flex justify-between">
                      <div className={`flex flex-col items-center ${
                        ['processing', 'shipped', 'delivered'].includes(order.status) ? 'text-green-600' : 'text-gray-400'
                      }`}>
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center z-10 ${
                          ['processing', 'shipped', 'delivered'].includes(order.status) ? 'bg-green-100 border-2 border-green-500' : 'bg-gray-100 border-2 border-gray-300'
                        }`}>
                          <CheckCircle className="w-3 h-3" />
                        </div>
                        <span className="text-xs mt-1">Confirmado</span>
                      </div>
                      
                      <div className={`flex flex-col items-center ${
                        ['shipped', 'delivered'].includes(order.status) ? 'text-green-600' : 'text-gray-400'
                      }`}>
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center z-10 ${
                          ['shipped', 'delivered'].includes(order.status) ? 'bg-green-100 border-2 border-green-500' : 'bg-gray-100 border-2 border-gray-300'
                        }`}>
                          <Package className="w-3 h-3" />
                        </div>
                        <span className="text-xs mt-1">Enviado</span>
                      </div>
                      
                      <div className={`flex flex-col items-center ${
                        order.status === 'delivered' ? 'text-green-600' : 'text-gray-400'
                      }`}>
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center z-10 ${
                          order.status === 'delivered' ? 'bg-green-100 border-2 border-green-500' : 'bg-gray-100 border-2 border-gray-300'
                        }`}>
                          <Truck className="w-3 h-3" />
                        </div>
                        <span className="text-xs mt-1">Em Trânsito</span>
                      </div>
                      
                      <div className={`flex flex-col items-center ${
                        order.status === 'delivered' ? 'text-green-600' : 'text-gray-400'
                      }`}>
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center z-10 ${
                          order.status === 'delivered' ? 'bg-green-100 border-2 border-green-500' : 'bg-gray-100 border-2 border-gray-300'
                        }`}>
                          <CheckCircle className="w-3 h-3" />
                        </div>
                        <span className="text-xs mt-1">Entregue</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Order Actions */}
                <div className="px-4 sm:px-6 py-4 bg-white border-t border-gray-200">
                  <div className="flex flex-col sm:flex-row gap-3 sm:justify-between sm:items-center">
                    {/* Shipping Address */}
                    <div className="flex items-center text-sm text-gray-600">
                      <MapPin className="w-4 h-4 mr-1 flex-shrink-0" />
                      <span className="truncate">
                        {order.shippingAddress.city}, {order.shippingAddress.state}
                      </span>
                    </div>
                    
                    {/* Action Buttons */}
                    <div className="flex flex-wrap gap-2">
                      {getOrderActions(order).map((action, index) => (
                        <button
                          key={index}
                          onClick={action.action}
                          className={`flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-medium ${action.color}`}
                        >
                          <action.icon className="w-3 h-3" />
                          <span>{action.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Payment Pending Notice */}
                {order.paymentStatus === 'pending' && (
                  <div className="px-4 sm:px-6 py-3 bg-yellow-50 border-t border-yellow-200">
                    <div className="flex items-start">
                      <AlertCircle className="w-5 h-5 text-yellow-600 mr-2 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-yellow-800">Pagamento Pendente</p>
                        <p className="text-xs text-yellow-700 mt-1">
                          Seu pedido está aguardando confirmação de pagamento. Clique em "Pagar" para finalizar.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Tracking Info */}
                {order.status === 'shipped' && order.trackingCode && (
                  <div className="px-4 sm:px-6 py-3 bg-purple-50 border-t border-purple-200">
                    <div className="flex items-start">
                      <Truck className="w-5 h-5 text-purple-600 mr-2 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-purple-800">Pedido em Trânsito</p>
                        <p className="text-xs text-purple-700 mt-1">
                          Código de rastreio: <span className="font-mono">{order.trackingCode}</span>
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Delivered Notice */}
                {order.status === 'delivered' && (
                  <div className="px-4 sm:px-6 py-3 bg-green-50 border-t border-green-200">
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-600 mr-2 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-green-800">Pedido Entregue</p>
                        <p className="text-xs text-green-700 mt-1">
                          Seu pedido foi entregue com sucesso. Aproveite seus produtos!
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Cancelled Notice */}
                {order.status === 'cancelled' && (
                  <div className="px-4 sm:px-6 py-3 bg-red-50 border-t border-red-200">
                    <div className="flex items-start">
                      <XCircle className="w-5 h-5 text-red-600 mr-2 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-red-800">Pedido Cancelado</p>
                        <p className="text-xs text-red-700 mt-1">
                          Este pedido foi cancelado. Entre em contato conosco para mais informações.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Quick Actions */}
        <div className="mt-8 bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Ações Rápidas</h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <button
              onClick={() => onNavigate('order-tracking')}
              className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <Truck className="w-6 h-6 text-purple-600" />
              <div className="text-left">
                <p className="font-medium text-gray-900">Rastrear Pedido</p>
                <p className="text-sm text-gray-600">Digite o código de rastreamento</p>
              </div>
            </button>
            
            <button
              onClick={() => onNavigate('shop')}
              className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <ShoppingBag className="w-6 h-6 text-green-600" />
              <div className="text-left">
                <p className="font-medium text-gray-900">Continuar Comprando</p>
                <p className="text-sm text-gray-600">Explore nossa coleção</p>
              </div>
            </button>
            
            <button
              onClick={() => onNavigate('contact')}
              className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <MessageCircle className="w-6 h-6 text-blue-600" />
              <div className="text-left">
                <p className="font-medium text-gray-900">Suporte</p>
                <p className="text-sm text-gray-600">Dúvidas sobre pedidos</p>
              </div>
            </button>
          </div>
        </div>

        {/* Order Help */}
        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start">
            <FileText className="w-5 h-5 text-blue-600 mr-2 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium text-blue-800 mb-1">Precisa de ajuda com seu pedido?</h4>
              <p className="text-sm text-blue-700">
                Entre em contato com nosso suporte pelo WhatsApp (61) 99611-1535 ou email sapatos.comfydance@gmail.com
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MyOrders;