import React, { useState } from 'react';
import { ArrowLeft, CreditCard, Smartphone, FileText, Truck, Shield, Check, AlertCircle, Loader, Eye } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { paymentService } from '../lib/payment';
import { supabase, isDemoMode } from '../lib/supabase';
import { locationService, Address } from '../lib/location';
import PaymentMethods from '../components/Payment/PaymentMethods';
import CreditCardForm from '../components/Payment/CreditCardForm';
import PixPayment from '../components/Payment/PixPayment';
import BoletoPayment from '../components/Payment/BoletoPayment';
import AddressForm from '../components/Location/AddressForm';
import { CreditCardData } from '../types/payment';
import MercadoPagoPayment from '../components/Payment/MercadoPagoPayment';
import { PaymentItem, CustomerData } from '../lib/mercadopago';

interface CheckoutProps {
  onBack: () => void;
  onNavigate: (page: string) => void;
}

const Checkout: React.FC<CheckoutProps> = ({ onBack, onNavigate }) => {
  const { items, total, clearCart } = useCart();
  const { user, isAuthenticated } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');
  
  const [shippingData, setShippingData] = useState({
    fullName: user?.name || '',
    email: user?.email || '',
    phone: '',
    address: {} as Address & { coordinates?: { lat: number; lng: number } }
  });
  
  const [paymentMethod, setPaymentMethod] = useState('');
  const [paymentData, setPaymentData] = useState<any>(null);
  const [orderId, setOrderId] = useState<string | null>(null);
  const [orderNumber, setOrderNumber] = useState<string | null>(null);
  const [shippingCost, setShippingCost] = useState(15.90);
  const [shippingDays, setShippingDays] = useState(7);

  const finalTotal = total + shippingCost;

  // Brasília coordinates (our store)
  const BRASILIA_COORDS = { lat: -15.7942, lng: -47.8822 };

  const handleAddressChange = (address: Address & { coordinates?: { lat: number; lng: number } }) => {
    setShippingData(prev => ({ ...prev, address }));

    // Calculate shipping based on location
    if (address.coordinates) {
      const distance = locationService.calculateDistance(
        BRASILIA_COORDS.lat,
        BRASILIA_COORDS.lng,
        address.coordinates.lat,
        address.coordinates.lng
      );

      const shipping = locationService.calculateShipping(distance);
      
      // Free shipping for orders over R$ 200
      if (total >= 200) {
        setShippingCost(0);
        setShippingDays(shipping.estimatedDays);
      } else {
        setShippingCost(shipping.cost);
        setShippingDays(shipping.estimatedDays);
      }
    }
  };

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    const requiredFields = ['fullName', 'email', 'phone'];
    const missingFields = requiredFields.filter(field => !shippingData[field as keyof typeof shippingData]);
    
    if (missingFields.length > 0) {
      setError('Please fill in all required fields');
      return;
    }

    // Validate address
    if (!shippingData.address.cep || !shippingData.address.logradouro || !shippingData.address.bairro || !shippingData.address.localidade || !shippingData.address.uf) {
      setError('Please provide a complete address');
      return;
    }
    
    setError('');
    setCurrentStep(2);
  };

  const createOrder = async () => {
    const orderNum = `CD${Date.now()}`;
    const orderData = {
      user_id: user?.id || 'guest',
      order_number: orderNum,
      items: items.map(item => ({
        product_id: item.product.id,
        product_name: item.product.name,
        product_image: item.product.images[0],
        size: item.size,
        color: item.color,
        quantity: item.quantity,
        unit_price: item.product.price,
        total_price: item.product.price * item.quantity
      })),
      total_amount: finalTotal,
      shipping_cost: shippingCost,
      status: 'pending',
      payment_method: paymentMethod,
      shipping_address: {
        ...shippingData.address,
        fullName: shippingData.fullName,
        phone: shippingData.phone
      },
      customer_name: shippingData.fullName,
      customer_email: shippingData.email
    };

    let orderId: string;

    if (isDemoMode) {
      // Demo mode - create simulated order
      orderId = 'demo-order-' + Date.now();
      console.warn('Demo mode: creating simulated order', orderId);
      
      // Store order in localStorage for demo
      localStorage.setItem(`demo_order_${orderNum}`, JSON.stringify({
        ...orderData,
        id: orderId,
        createdAt: new Date().toISOString()
      }));
    } else {
      // Real mode - create order in database
      const { data: order, error: orderError } = await supabase
        .from('user_orders')
        .insert(orderData)
        .select()
        .single();

      if (orderError) {
        throw new Error('Error creating order: ' + orderError.message);
      }

      orderId = order.id;
    }

    setOrderId(orderId);
    setOrderNumber(orderNum);
    return { orderId, orderNumber: orderNum };
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!paymentMethod) {
      setError('Please select a payment method');
      return;
    }

    setIsProcessing(true);
    setError('');

    try {
      // Create order first
      const { orderId, orderNumber } = await createOrder();

      // Calculate final amount with discount
      let paymentAmount = finalTotal;
      if (paymentMethod === 'pix') {
        paymentAmount = finalTotal * 0.95; // 5% discount for PIX
      }

      // Create payment
      let paymentResponse;
      if (paymentMethod === 'pix') {
        paymentResponse = await paymentService.createPixPayment(
          orderId,
          paymentAmount,
          `Order ${orderNumber} - Comfydance`
        );
      } else if (paymentMethod === 'boleto') {
        paymentResponse = await paymentService.createBoletoPayment(
          orderId,
          paymentAmount,
          `Order ${orderNumber} - Comfydance`,
          shippingData
        );
      }

      if (!paymentResponse?.success) {
        throw new Error(paymentResponse?.error || 'Error processing payment');
      }

      setPaymentData({
        ...paymentResponse,
        amount: paymentAmount,
        orderNumber,
        orderId
      });

      setCurrentStep(3);
      clearCart();

    } catch (error: any) {
      console.error('Payment error:', error);
      setError(error.message || 'Error processing payment. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCreditCardSubmit = async (cardData: CreditCardData) => {
    setIsProcessing(true);
    setError('');

    try {
      // Create order first
      const { orderId, orderNumber } = await createOrder();

      // Create credit card payment
      const paymentResponse = await paymentService.createCreditCardPayment(
        orderId,
        finalTotal,
        `Order ${orderNumber} - Comfydance`,
        cardData,
        shippingData
      );

      if (!paymentResponse?.success) {
        throw new Error(paymentResponse?.error || 'Error processing credit card');
      }

      setPaymentData({
        ...paymentResponse,
        amount: finalTotal,
        orderNumber,
        orderId,
        creditCard: true
      });

      setCurrentStep(3);
      clearCart();

    } catch (error: any) {
      console.error('Credit card payment error:', error);
      setError(error.message || 'Error processing credit card. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleMercadoPagoSuccess = (paymentData: any) => {
    setPaymentData({
      ...paymentData,
      orderNumber,
      orderId
    });
    setCurrentStep(3);
    clearCart();
  };

  const handleMercadoPagoError = (errorMessage: string) => {
    setError(errorMessage);
  };

  const handleViewOrder = () => {
    if (paymentData?.orderId && paymentData?.orderNumber) {
      // Navigate to order view with order ID
      onNavigate(`order-view-${paymentData.orderNumber}`);
    }
  };

  // Convert cart items to Mercado Pago format
  const getMercadoPagoItems = (): PaymentItem[] => {
    return items.map(item => ({
      id: item.product.id,
      name: `${item.product.name} (${item.size}, ${item.color})`,
      price: item.product.price,
      quantity: item.quantity
    }));
  };

  // Get customer data for Mercado Pago
  const getCustomerData = (): CustomerData => {
    return {
      name: shippingData.fullName,
      email: shippingData.email,
      phone: shippingData.phone
    };
  };

  if (items.length === 0 && currentStep !== 3) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="text-center">
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4">Empty Cart</h2>
          <p className="text-gray-600 mb-6">Add products to your cart to continue</p>
          <button
            onClick={() => onNavigate('shop')}
            className="bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors"
          >
            Go Shopping
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Header */}
        <div className="flex items-center mb-6 sm:mb-8">
          <button
            onClick={onBack}
            className="flex items-center text-gray-600 hover:text-gray-900 transition-colors mr-4 sm:mr-6"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            <span className="hidden sm:inline">Back</span>
          </button>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">Checkout</h1>
        </div>

        {/* Demo Mode Notice */}
        {isDemoMode && (
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-blue-600 mr-2" />
              <p className="text-blue-700 text-sm">
                <strong>Demo Mode:</strong> This is a test environment. No real transactions will be processed.
              </p>
            </div>
          </div>
        )}

        {/* Progress Steps */}
        <div className="mb-6 sm:mb-8">
          <div className="flex items-center justify-center space-x-4 sm:space-x-8">
            {[
              { step: 1, title: 'Shipping', icon: Truck },
              { step: 2, title: 'Payment', icon: CreditCard },
              { step: 3, title: 'Confirmation', icon: Check }
            ].map(({ step, title, icon: Icon }) => (
              <div key={step} className="flex items-center">
                <div className={`flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10 rounded-full ${
                  currentStep >= step ? 'bg-black text-white' : 'bg-gray-200 text-gray-600'
                }`}>
                  <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <span className={`ml-2 font-medium text-sm sm:text-base ${
                  currentStep >= step ? 'text-black' : 'text-gray-600'
                }`}>
                  <span className="hidden sm:inline">{title}</span>
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
              <p className="text-red-700">{error}</p>
            </div>
          </div>
        )}

        {/* Step 1: Shipping Information */}
        {currentStep === 1 && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
            <div className="lg:col-span-2">
              <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md">
                <h2 className="text-lg sm:text-xl font-semibold text-gray-900 mb-4 sm:mb-6">Shipping Information</h2>
                
                <form onSubmit={handleShippingSubmit} className="space-y-4 sm:space-y-6">
                  {/* Personal Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        value={shippingData.fullName}
                        onChange={(e) => setShippingData({...shippingData, fullName: e.target.value})}
                        required
                        className="w-full px-3 sm:px-4 py-2 sm:py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 text-sm sm:text-base"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Email *
                      </label>
                      <input
                        type="email"
                        value={shippingData.email}
                        onChange={(e) => setShippingData({...shippingData, email: e.target.value})}
                        required
                        className="w-full px-3 sm:px-4 py-2 sm:py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 text-sm sm:text-base"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Phone *
                    </label>
                    <input
                      type="tel"
                      value={shippingData.phone}
                      onChange={(e) => setShippingData({...shippingData, phone: e.target.value})}
                      required
                      placeholder="(11) 99999-9999"
                      className="w-full px-3 sm:px-4 py-2 sm:py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 text-sm sm:text-base"
                    />
                  </div>

                  {/* Address Form */}
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Shipping Address</h3>
                    <AddressForm
                      onAddressChange={handleAddressChange}
                      initialAddress={shippingData.address}
                      showShipping={true}
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-black text-white py-3 rounded-lg hover:bg-gray-800 transition-colors font-medium"
                  >
                    Continue to Payment
                  </button>
                </form>
              </div>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md sticky top-8">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Order Summary</h3>
                
                <div className="space-y-4 mb-6">
                  {items.map((item) => {
                    const itemId = `${item.product.id}-${item.size}-${item.color}`;
                    return (
                      <div key={itemId} className="flex space-x-3">
                        <img
                          src={item.product.images[0]}
                          alt={item.product.name}
                          className="w-12 h-12 object-cover rounded flex-shrink-0"
                        />
                        
                        <div className="flex-1 text-sm min-w-0">
                          <p className="font-medium text-gray-900 line-clamp-2">{item.product.name}</p>
                          <p className="text-gray-500">Size: {item.size} • {item.color}</p>
                          <p className="text-gray-500">Qty: {item.quantity}</p>
                        </div>
                        <p className="text-sm font-medium">
                          R$ {(item.product.price * item.quantity).toFixed(2)}
                        </p>
                      </div>
                    );
                  })}
                </div>
                
                <div className="border-t pt-4 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>R$ {total.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping:</span>
                    <span>
                      {shippingCost === 0 ? 'Free' : `R$ ${shippingCost.toFixed(2)}`}
                      {shippingDays && (
                        <span className="text-xs text-gray-500 block">
                          {shippingDays} business days
                        </span>
                      )}
                    </span>
                  </div>
                  <div className="flex justify-between font-semibold text-lg pt-2 border-t">
                    <span>Total:</span>
                    <span>R$ {finalTotal.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Payment */}
        {currentStep === 2 && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
            <div className="lg:col-span-2">
              <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md">
                {/* Mercado Pago Payment */}
                <MercadoPagoPayment
                  items={getMercadoPagoItems()}
                  customerData={getCustomerData()}
                  orderNumber={`CD${Date.now()}`}
                  onPaymentSuccess={handleMercadoPagoSuccess}
                  onPaymentError={handleMercadoPagoError}
                />
              </div>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md sticky top-8">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Final Summary</h3>
                
                <div className="space-y-2 text-sm mb-4">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>R$ {total.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping:</span>
                    <span>
                      {shippingCost === 0 ? 'Free' : `R$ ${shippingCost.toFixed(2)}`}
                      {shippingDays && (
                        <span className="text-xs text-gray-500 block">
                          {shippingDays} business days
                        </span>
                      )}
                    </span>
                  </div>
                  <div className="flex justify-between font-semibold text-lg pt-2 border-t">
                    <span>Total:</span>
                    <span>R$ {finalTotal.toFixed(2)}</span>
                  </div>
                </div>

                {/* Shipping Address Summary */}
                {shippingData.address.logradouro && (
                  <div className="border-t pt-4">
                    <h4 className="font-medium text-gray-900 mb-2">Shipping to:</h4>
                    <div className="text-sm text-gray-600">
                      <p>{shippingData.address.logradouro}</p>
                      <p>{shippingData.address.bairro}</p>
                      <p>{shippingData.address.localidade} - {shippingData.address.uf}</p>
                      <p>CEP: {shippingData.address.cep}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Step 3: Payment Confirmation */}
        {currentStep === 3 && paymentData && (
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6 text-center border-b">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Check className="w-8 h-8 text-green-600" />
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2">
                  Order Created Successfully!
                </h2>
                <p className="text-gray-600 mb-4">
                  Order #{paymentData.orderNumber}
                </p>
                {isDemoMode && (
                  <p className="text-sm text-blue-600 bg-blue-50 px-3 py-1 rounded-full inline-block">
                    Demo Mode - Simulated Transaction
                  </p>
                )}
              </div>

              {/* Payment Instructions */}
              <div className="p-6">
                {paymentMethod === 'pix' && paymentData.pixCode && (
                  <PixPayment
                    pixCode={paymentData.pixCode}
                    pixQrCode={paymentData.pixQrCode}
                    amount={paymentData.amount}
                    expiresAt={paymentData.expiresAt}
                  />
                )}

                {paymentMethod === 'boleto' && paymentData.boletoUrl && (
                  <BoletoPayment
                    boletoUrl={paymentData.boletoUrl}
                    boletoBarcode={paymentData.boletoBarcode}
                    amount={paymentData.amount}
                    expiresAt={paymentData.expiresAt}
                    customerName={shippingData.fullName}
                  />
                )}

                {paymentMethod === 'credit_card' && paymentData.creditCard && (
                  <div className="text-center">
                    <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                      <CreditCard className="w-12 h-12 text-green-600 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-green-800 mb-2">
                        Payment Approved!
                      </h3>
                      <p className="text-green-700 mb-4">
                        Your credit card has been processed successfully.
                      </p>
                      <div className="text-sm text-green-600">
                        <p>Amount: R$ {paymentData.amount.toFixed(2)}</p>
                        {paymentData.creditCardData && (
                          <p>Installments: {paymentData.creditCardData.installments}x</p>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Mercado Pago Payment Success */}
                {paymentData.pix && paymentData.payment_id && (
                  <div className="text-center">
                    <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                      <Check className="w-12 h-12 text-green-600 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-green-800 mb-2">
                        Payment Received!
                      </h3>
                      <p className="text-green-700 mb-4">
                        Your payment has been processed successfully.
                      </p>
                      <div className="text-sm text-green-600">
                        <p>Amount: R$ {paymentData.amount?.toFixed(2)}</p>
                        <p>Payment ID: {paymentData.payment_id}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="p-6 border-t space-y-3">
                {/* View Order Button */}
                <button
                  onClick={handleViewOrder}
                  className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center justify-center space-x-2"
                >
                  <Eye className="w-5 h-5" />
                  <span>View My Order</span>
                </button>

                <button
                  onClick={() => onNavigate('shop')}
                  className="w-full bg-black text-white py-3 rounded-lg hover:bg-gray-800 transition-colors font-medium"
                >
                  Continue Shopping
                </button>
                
                <button
                  onClick={() => onNavigate('account')}
                  className="w-full border border-gray-300 text-gray-700 py-3 rounded-lg hover:bg-gray-50 transition-colors font-medium"
                >
                  Track Order
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Checkout;