import React from 'react';
import { ArrowLeft, Shield, RotateCcw, FileText, Users, Phone } from 'lucide-react';

interface InstitutionalPagesProps {
  page: 'privacy' | 'terms' | 'returns' | 'about-us' | 'contact-info';
  onBack: () => void;
}

const InstitutionalPages: React.FC<InstitutionalPagesProps> = ({ page, onBack }) => {
  const getPageContent = () => {
    switch (page) {
      case 'privacy':
        return {
          title: 'Política de Privacidade',
          icon: <Shield className="w-8 h-8 text-blue-600" />,
          content: (
            <div className="space-y-6">
              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">1. Informações que Coletamos</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Coletamos informações que você nos fornece diretamente, como quando você cria uma conta, 
                  faz uma compra, ou entra em contato conosco. Isso inclui:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>Nome, e-mail e telefone</li>
                  <li>Endereço de entrega e cobrança</li>
                  <li>Informações de pagamento (processadas de forma segura)</li>
                  <li>Histórico de compras e preferências</li>
                </ul>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">2. Como Usamos suas Informações</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Utilizamos suas informações para:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>Processar e entregar seus pedidos</li>
                  <li>Fornecer atendimento ao cliente</li>
                  <li>Enviar atualizações sobre pedidos</li>
                  <li>Melhorar nossos produtos e serviços</li>
                  <li>Enviar ofertas promocionais (com seu consentimento)</li>
                </ul>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">3. Proteção de Dados</h2>
                <p className="text-gray-700 leading-relaxed">
                  Implementamos medidas de segurança técnicas e organizacionais para proteger suas 
                  informações pessoais contra acesso não autorizado, alteração, divulgação ou destruição. 
                  Utilizamos criptografia SSL e seguimos as melhores práticas de segurança da indústria.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">4. Seus Direitos</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  De acordo com a LGPD, você tem o direito de:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>Acessar seus dados pessoais</li>
                  <li>Corrigir dados incompletos ou incorretos</li>
                  <li>Solicitar a exclusão de seus dados</li>
                  <li>Revogar seu consentimento</li>
                  <li>Solicitar a portabilidade de seus dados</li>
                </ul>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">5. Contato</h2>
                <p className="text-gray-700 leading-relaxed">
                  Para exercer seus direitos ou esclarecer dúvidas sobre esta política, 
                  entre em contato conosco através do e-mail: privacidade@comfydance.com
                </p>
              </section>
            </div>
          )
        };

      case 'terms':
        return {
          title: 'Termos de Uso',
          icon: <FileText className="w-8 h-8 text-green-600" />,
          content: (
            <div className="space-y-6">
              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">1. Aceitação dos Termos</h2>
                <p className="text-gray-700 leading-relaxed">
                  Ao acessar e usar o site da Comfydance, você concorda em cumprir e estar vinculado 
                  a estes Termos de Uso. Se você não concordar com qualquer parte destes termos, 
                  não deve usar nosso site.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">2. Uso do Site</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Você pode usar nosso site para:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>Navegar e visualizar produtos</li>
                  <li>Fazer compras de produtos disponíveis</li>
                  <li>Criar e gerenciar sua conta</li>
                  <li>Entrar em contato conosco</li>
                </ul>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">3. Conta do Usuário</h2>
                <p className="text-gray-700 leading-relaxed">
                  Para fazer compras, você deve criar uma conta fornecendo informações precisas e 
                  atualizadas. Você é responsável por manter a confidencialidade de sua senha e 
                  por todas as atividades que ocorrem em sua conta.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">4. Preços e Pagamentos</h2>
                <p className="text-gray-700 leading-relaxed">
                  Todos os preços estão em Reais (BRL) e incluem impostos aplicáveis. Reservamo-nos 
                  o direito de alterar preços a qualquer momento. O pagamento deve ser feito no 
                  momento da compra através dos métodos disponíveis.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">5. Propriedade Intelectual</h2>
                <p className="text-gray-700 leading-relaxed">
                  Todo o conteúdo do site, incluindo textos, imagens, logos e design, é propriedade 
                  da Comfydance e está protegido por leis de direitos autorais. É proibida a 
                  reprodução sem autorização prévia.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">6. Limitação de Responsabilidade</h2>
                <p className="text-gray-700 leading-relaxed">
                  A Comfydance não será responsável por danos indiretos, incidentais ou consequenciais 
                  decorrentes do uso do site ou da compra de produtos, exceto conforme exigido por lei.
                </p>
              </section>
            </div>
          )
        };

      case 'returns':
        return {
          title: 'Política de Trocas e Devoluções',
          icon: <RotateCcw className="w-8 h-8 text-purple-600" />,
          content: (
            <div className="space-y-6">
              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">1. Prazo para Trocas e Devoluções</h2>
                <p className="text-gray-700 leading-relaxed">
                  Você tem até <strong>30 dias</strong> a partir da data de recebimento do produto 
                  para solicitar troca ou devolução, conforme o Código de Defesa do Consumidor.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">2. Condições para Troca/Devolução</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Para que a troca ou devolução seja aceita, o produto deve estar:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>Em perfeito estado, sem sinais de uso</li>
                  <li>Com todas as etiquetas originais</li>
                  <li>Na embalagem original</li>
                  <li>Acompanhado da nota fiscal</li>
                </ul>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">3. Como Solicitar</h2>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                  <h3 className="font-semibold text-blue-900 mb-2">Passo a Passo:</h3>
                  <ol className="list-decimal list-inside text-blue-800 space-y-2">
                    <li>Entre em contato conosco via WhatsApp ou e-mail</li>
                    <li>Informe o número do pedido e motivo da troca/devolução</li>
                    <li>Aguarde as instruções de envio</li>
                    <li>Embale o produto conforme orientações</li>
                    <li>Envie pelos Correios (frete por nossa conta)</li>
                  </ol>
                </div>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">4. Processamento</h2>
                
                <p className="text-gray-700 leading-relaxed mb-4">
                  Após recebermos o produto:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li><strong>Troca:</strong> Novo produto enviado em até 5 dias úteis</li>
                  <li><strong>Devolução:</strong> Estorno processado em até 7 dias úteis</li>
                  <li>Você receberá atualizações por e-mail sobre o status</li>
                </ul>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">5. Produtos com Defeito</h2>
                <p className="text-gray-700 leading-relaxed">
                  Produtos com defeito de fabricação têm garantia de <strong>90 dias</strong>. 
                  Entre em contato imediatamente para que possamos resolver a situação da melhor forma.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">6. Frete</h2>
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <p className="text-green-800">
                    <strong>Frete Grátis:</strong> O frete para troca ou devolução é por nossa conta. 
                    Enviaremos uma etiqueta de postagem pré-paga.
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">7. Contato</h2>
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <p className="text-gray-700 mb-2">
                    <strong>WhatsApp:</strong> (61) 99611-1535
                  </p>
                  <p className="text-gray-700">
                    <strong>E-mail:</strong> trocas@comfydance.com
                  </p>
                </div>
              </section>
            </div>
          )
        };

      case 'about-us':
        return {
          title: 'Quem Somos',
          icon: <Users className="w-8 h-8 text-yellow-600" />,
          content: (
            <div className="space-y-6">
              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Nossa História</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  A Comfydance nasceu em 2009 do sonho de dois dançarinos apaixonados, Marina e Carlos, 
                  que buscavam calçados que combinassem conforto, qualidade e elegância. Após anos 
                  dançando com sapatos desconfortáveis, eles decidiram criar sua própria marca.
                </p>
                <p className="text-gray-700 leading-relaxed">
                  Hoje, com sede em <strong>Brasília, DF</strong>, somos referência nacional em calçados 
                  para dança, atendendo desde iniciantes até profissionais renomados em todo o Brasil.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Nossa Missão</h2>
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                  <p className="text-yellow-800 text-lg italic text-center">
                    "Capacitar dançarinos de todos os níveis com calçados excepcionais que combinam 
                    conforto, qualidade e estilo, permitindo que cada pessoa expresse sua paixão 
                    pela dança com total confiança e elegância."
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Nossos Valores</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white border border-gray-200 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-2">🎭 Paixão pela Dança</h3>
                    <p className="text-gray-700 text-sm">
                      Vivemos e respiramos dança. Cada produto é desenvolvido com amor e dedicação.
                    </p>
                  </div>
                  <div className="bg-white border border-gray-200 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-2">🏆 Qualidade Premium</h3>
                    <p className="text-gray-700 text-sm">
                      Utilizamos apenas materiais de primeira qualidade e técnicas artesanais.
                    </p>
                  </div>
                  <div className="bg-white border border-gray-200 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-2">👥 Atendimento Personalizado</h3>
                    <p className="text-gray-700 text-sm">
                      Nossa equipe especializada está sempre pronta para ajudar você.
                    </p>
                  </div>
                  <div className="bg-white border border-gray-200 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-2">🚚 Entrega Confiável</h3>
                    <p className="text-gray-700 text-sm">
                      Garantimos que seus produtos chegem rapidamente e em perfeitas condições.
                    </p>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Localização</h2>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="font-semibold text-blue-900 mb-2">🏪 Nossa Loja</h3>
                      <p className="text-blue-800">
                        <strong>Brasília, DF</strong><br />
                        Centro de operações e atendimento<br />
                        Entregamos para todo o Brasil
                      </p>
                    </div>
                    <div>
                      <h3 className="font-semibold text-blue-900 mb-2">💻 Desenvolvimento</h3>
                      <p className="text-blue-800">
                        <strong>Luziânia, GO</strong><br />
                        Onde a inovação acontece<br />
                        Site desenvolvido com tecnologia de ponta
                      </p>
                    </div>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Números que nos Orgulham</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-600">15+</div>
                    <div className="text-sm text-gray-600">Anos de Experiência</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-600">10.000+</div>
                    <div className="text-sm text-gray-600">Clientes Satisfeitos</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-600">25.000+</div>
                    <div className="text-sm text-gray-600">Produtos Vendidos</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-600">4.9/5</div>
                    <div className="text-sm text-gray-600">Avaliação Média</div>
                  </div>
                </div>
              </section>
            </div>
          )
        };

      case 'contact-info':
        return {
          title: 'Informações de Contato',
          icon: <Phone className="w-8 h-8 text-green-600" />,
          content: (
            <div className="space-y-6">
              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Fale Conosco</h2>
                <p className="text-gray-700 leading-relaxed mb-6">
                  Estamos aqui para ajudar você! Entre em contato conosco através dos canais abaixo.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                    <h3 className="font-semibold text-green-900 mb-3 flex items-center">
                      <Phone className="w-5 h-5 mr-2" />
                      WhatsApp
                    </h3>
                    <p className="text-green-800 mb-2">
                      <strong>(61) 99611-1535</strong>
                    </p>
                    <p className="text-green-700 text-sm mb-3">
                      Atendimento de segunda a sexta, das 8h às 19h
                    </p>
                    <a
                      href="https://wa.me/5561996111535"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-block bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm"
                    >
                      Iniciar Conversa
                    </a>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                    <h3 className="font-semibold text-blue-900 mb-3 flex items-center">
                      <Phone className="w-5 h-5 mr-2" />
                      E-mail
                    </h3>
                    <p className="text-blue-800 mb-2">
                      <strong>sapatos.comfydance@gmail.com</strong>
                    </p>
                    <p className="text-blue-700 text-sm mb-3">
                      Respondemos em até 24 horas
                    </p>
                    <a
                      href="mailto:sapatos.comfydance@gmail.com"
                      className="inline-block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm"
                    >
                      Enviar E-mail
                    </a>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Horários de Atendimento</h2>
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">📞 Atendimento por Telefone/WhatsApp</h3>
                      <ul className="text-gray-700 space-y-1">
                        <li>Segunda a Sexta: 8h às 19h</li>
                        <li>Sábado: 8h às 19h</li>
                        <li>Domingo: Fechado</li>
                      </ul>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">📧 Atendimento por E-mail</h3>
                      <ul className="text-gray-700 space-y-1">
                        <li>24 horas por dia</li>
                        <li>7 dias por semana</li>
                        <li>Resposta em até 24h</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Endereço</h2>
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                  <h3 className="font-semibold text-yellow-900 mb-2">🏪 Sede da Empresa</h3>
                  <p className="text-yellow-800">
                    Brasília, DF<br />
                    Centro de operações e atendimento<br />
                    <em>Loja 100% online - Entregamos em todo o Brasil</em>
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Dúvidas Frequentes</h2>
                <div className="space-y-4">
                  <div className="bg-white border border-gray-200 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-2">Como rastrear meu pedido?</h3>
                    <p className="text-gray-700 text-sm">
                      Você receberá um código de rastreamento por e-mail após o envio. 
                      Também pode consultar o status na área "Meus Pedidos".
                    </p>
                  </div>
                  <div className="bg-white border border-gray-200 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-2">Qual o prazo de entrega?</h3>
                    <p className="text-gray-700 text-sm">
                      O prazo varia de 3 a 10 dias úteis dependendo da sua região. 
                      Frete grátis para compras acima de R$ 200,00.
                    </p>
                  </div>
                  <div className="bg-white border border-gray-200 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-2">Como escolher o tamanho correto?</h3>
                    <p className="text-gray-700 text-sm">
                      Consulte nossa tabela de medidas ou entre em contato conosco. 
                      Nossa equipe pode ajudar a escolher o tamanho ideal.
                    </p>
                  </div>
                </div>
              </section>
            </div>
          )
        };

      default:
        return {
          title: 'Página não encontrada',
          icon: <FileText className="w-8 h-8 text-gray-600" />,
          content: <p>Conteúdo não encontrado.</p>
        };
    }
  };

  const { title, icon, content } = getPageContent();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="flex items-center text-gray-600 hover:text-gray-900 transition-colors mr-6"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            <span>Voltar</span>
          </button>
          
          <div className="flex items-center">
            {icon}
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 ml-3">
              {title}
            </h1>
          </div>
        </div>

        {/* Content */}
        <div className="bg-white rounded-lg shadow-md p-6 sm:p-8">
          <div className="prose prose-gray max-w-none">
            {content}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-gray-600 text-sm">
            Última atualização: {new Date().toLocaleDateString('pt-BR')}
          </p>
          <p className="text-gray-500 text-xs mt-2">
            © 2024 Comfydance. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </div>
  );
};

export default InstitutionalPages;