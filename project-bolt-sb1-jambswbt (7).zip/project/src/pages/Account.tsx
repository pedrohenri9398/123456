import React, { useState, useEffect } from 'react';
import { User, Package, MapPin, Heart, LogOut, Eye, EyeOff, Loader, AlertCircle, Info, RefreshCw } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, isDemoMode } from '../lib/supabase';

interface AccountProps {
  onNavigate: (page: string) => void;
}

const Account: React.FC<AccountProps> = ({ onNavigate }) => {
  const { user, isAuthenticated, login, register, logout, isLoading, authError, clearAuthError } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [localError, setLocalError] = useState('');
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [resetSent, setResetSent] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [activeTab, setActiveTab] = useState('profile');
  const [userProfile, setUserProfile] = useState<any>(null);
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);

  // Limpar erros ao alternar entre login/cadastro
  useEffect(() => {
    setLocalError('');
    clearAuthError();
  }, [isLogin, clearAuthError]);

  // Carregar perfil do usuário quando autenticado
  useEffect(() => {
    if (isAuthenticated && user) {
      loadUserProfile();
    }
  }, [isAuthenticated, user]);

  const loadUserProfile = async () => {
    if (!user) return;

    try {
      if (isDemoMode) {
        // Modo demonstração - usar dados do usuário diretamente
        const demoProfile = {
          id: user.id,
          email: user.email,
          full_name: user.name,
          phone: '',
          birth_date: null
        };
        setUserProfile(demoProfile);
        return;
      }

      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) {
        console.error('Erro ao carregar perfil:', error);
        // Fallback para dados do usuário
        const fallbackProfile = {
          id: user.id,
          email: user.email,
          full_name: user.name,
          phone: '',
          birth_date: null
        };
        setUserProfile(fallbackProfile);
      } else {
        setUserProfile(data);
      }
    } catch (error) {
      console.error('Erro ao carregar perfil:', error);
      // Fallback para dados do usuário
      const fallbackProfile = {
        id: user.id,
        email: user.email,
        full_name: user.name,
        phone: '',
        birth_date: null
      };
      setUserProfile(fallbackProfile);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError('');
    clearAuthError();
    setIsSubmitting(true);
    
    try {
      if (isLogin) {
        const success = await login(formData.email, formData.password);
        if (success) {
          setActiveTab('profile');
          // Limpar formulário
          setFormData({ name: '', email: '', password: '', confirmPassword: '' });
        }
        // Tratamento de erro é feito no contexto de autenticação
      } else {
        if (formData.password !== formData.confirmPassword) {
          setLocalError('As senhas não coincidem.');
          return;
        }
        
        if (formData.password.length < 6) {
          setLocalError('A senha deve ter pelo menos 6 caracteres.');
          return;
        }
        
        if (!formData.name.trim()) {
          setLocalError('Nome é obrigatório.');
          return;
        }
        
        const success = await register(formData.name, formData.email, formData.password);
        if (success) {
          setActiveTab('profile');
          // Limpar formulário
          setFormData({ name: '', email: '', password: '', confirmPassword: '' });
        }
        // Tratamento de erro é feito no contexto de autenticação
      }
    } catch (error) {
      setLocalError('Erro interno. Tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    setLocalError(''); // Limpar erro quando o usuário digita
    clearAuthError();
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetEmail) {
      setLocalError('Por favor, informe seu endereço de e-mail');
      return;
    }
    
    setIsResetting(true);
    setLocalError('');
    
    try {
      if (isDemoMode) {
        // Simular redefinição de senha no modo demonstração
        await new Promise(resolve => setTimeout(resolve, 1500));
        setResetSent(true);
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(resetEmail, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        
        if (error) {
          throw error;
        }
        
        setResetSent(true);
      }
    } catch (error: any) {
      setLocalError(error.message || 'Falha ao enviar e-mail de redefinição. Tente novamente.');
    } finally {
      setIsResetting(false);
    }
  };

  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !userProfile) return;

    setIsUpdatingProfile(true);
    
    try {
      if (isDemoMode) {
        // Modo demonstração - simular atualização
        const formDataElement = new FormData(e.target as HTMLFormElement);
        const updatedProfile = {
          ...userProfile,
          full_name: formDataElement.get('fullName') as string,
          phone: formDataElement.get('phone') as string,
          birth_date: formDataElement.get('birthDate') as string || null,
        };
        setUserProfile(updatedProfile);
        alert('Perfil atualizado com sucesso! (Modo demonstração)');
        return;
      }

      const formDataElement = new FormData(e.target as HTMLFormElement);
      
      const { error } = await supabase
        .from('user_profiles')
        .update({
          full_name: formDataElement.get('fullName') as string,
          phone: formDataElement.get('phone') as string,
          birth_date: formDataElement.get('birthDate') as string || null,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id);

      if (error) {
        console.error('Erro ao atualizar perfil:', error);
        alert('Erro ao atualizar perfil. Tente novamente.');
      } else {
        alert('Perfil atualizado com sucesso!');
        await loadUserProfile(); // Recarregar dados
      }
    } catch (error) {
      console.error('Erro ao atualizar perfil:', error);
      alert('Erro ao atualizar perfil. Tente novamente.');
    } finally {
      setIsUpdatingProfile(false);
    }
  };

  const mockOrders = [
    {
      id: '#CD123456',
      date: '15/01/2024',
      status: 'Entregue',
      total: 299.90,
      items: 2
    },
    {
      id: '#CD123457',
      date: '10/01/2024',
      status: 'Em trânsito',
      total: 189.90,
      items: 1
    },
    {
      id: '#CD123458',
      date: '05/01/2024',
      status: 'Processando',
      total: 449.80,
      items: 3
    }
  ];

  // Mostrar carregamento durante verificação inicial
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader className="w-8 h-8 animate-spin mx-auto mb-4 text-yellow-600" />
          <p className="text-gray-600">Carregando...</p>
          <p className="text-sm text-gray-500 mt-2">
            Se o carregamento demorar muito, recarregue a página
          </p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    const displayError = localError || authError;

    // Formulário de redefinição de senha
    if (showResetPassword) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-md w-full space-y-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-900">
                Redefinir Senha
              </h2>
              <p className="mt-2 text-gray-600">
                Digite seu e-mail e enviaremos um link para redefinir sua senha
              </p>
            </div>

            {resetSent ? (
              <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
                <Check className="w-12 h-12 text-green-500 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-green-800 mb-2">Link Enviado!</h3>
                <p className="text-green-700 mb-4">
                  Enviamos um link de redefinição de senha para seu e-mail. Por favor, verifique sua caixa de entrada.
                </p>
                <button
                  onClick={() => {
                    setShowResetPassword(false);
                    setResetSent(false);
                    setResetEmail('');
                  }}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  Voltar para Login
                </button>
              </div>
            ) : (
              <>
                {displayError && (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <div className="flex items-start">
                      <AlertCircle className="w-5 h-5 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="text-red-700 text-sm">{displayError}</p>
                      </div>
                    </div>
                  </div>
                )}

                <form onSubmit={handleResetPassword} className="mt-8 space-y-6">
                  <div>
                    <label htmlFor="resetEmail" className="block text-sm font-medium text-gray-700 mb-1">
                      Endereço de E-mail
                    </label>
                    <input
                      id="resetEmail"
                      name="resetEmail"
                      type="email"
                      required
                      value={resetEmail}
                      onChange={(e) => setResetEmail(e.target.value)}
                      disabled={isResetting}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent disabled:bg-gray-100"
                      placeholder="seu@email.com"
                    />
                  </div>

                  <div className="flex flex-col space-y-3">
                    <button
                      type="submit"
                      disabled={isResetting}
                      className="w-full bg-black text-white py-3 px-4 rounded-lg hover:bg-gray-800 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                    >
                      {isResetting ? (
                        <>
                          <Loader className="w-4 h-4 animate-spin mr-2" />
                          Enviando...
                        </>
                      ) : (
                        'Enviar Link de Redefinição'
                      )}
                    </button>
                    
                    <button
                      type="button"
                      onClick={() => setShowResetPassword(false)}
                      disabled={isResetting}
                      className="w-full border border-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Voltar para Login
                    </button>
                  </div>
                </form>
              </>
            )}
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900">
              {isLogin ? 'Entre na sua conta' : 'Crie sua conta'}
            </h2>
            <p className="mt-2 text-gray-600">
              {isLogin 
                ? 'Acesse sua conta para ver pedidos e favoritos' 
                : 'Junte-se à família Comfydance'
              }
            </p>
          </div>

          {displayError && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-start">
                <AlertCircle className="w-5 h-5 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-red-700 text-sm">{displayError}</p>
                </div>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-8 space-y-6">
            <div className="space-y-4">
              {!isLogin && (
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Nome Completo *
                  </label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    required={!isLogin}
                    value={formData.name}
                    onChange={handleChange}
                    disabled={isSubmitting}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent disabled:bg-gray-100"
                    placeholder="Seu nome completo"
                  />
                </div>
              )}

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  E-mail *
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  disabled={isSubmitting}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent disabled:bg-gray-100"
                  placeholder="seu@email.com"
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  Senha *
                </label>
                <div className="relative">
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={formData.password}
                    onChange={handleChange}
                    disabled={isSubmitting}
                    className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent disabled:bg-gray-100"
                    placeholder="Sua senha"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={isSubmitting}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-gray-400" />
                    ) : (
                      <Eye className="h-4 w-4 text-gray-400" />
                    )}
                  </button>
                </div>
                {!isLogin && (
                  <p className="text-xs text-gray-500 mt-1">Mínimo de 6 caracteres</p>
                )}
              </div>

              {!isLogin && (
                <div>
                  <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                    Confirmar Senha *
                  </label>
                  <input
                    id="confirmPassword"
                    name="confirmPassword"
                    type="password"
                    required={!isLogin}
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    disabled={isSubmitting}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent disabled:bg-gray-100"
                    placeholder="Confirme sua senha"
                  />
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-black text-white py-3 px-4 rounded-lg hover:bg-gray-800 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {isSubmitting ? (
                <>
                  <Loader className="w-4 h-4 animate-spin mr-2" />
                  {isLogin ? 'Entrando...' : 'Criando conta...'}
                </>
              ) : (
                isLogin ? 'Entrar' : 'Criar Conta'
              )}
            </button>

            <div className="text-center space-y-3">
              {isLogin && (
                <button
                  type="button"
                  onClick={() => setShowResetPassword(true)}
                  className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                >
                  Esqueceu sua senha?
                </button>
              )}
              
              <button
                type="button"
                onClick={() => {
                  setIsLogin(!isLogin);
                  setLocalError('');
                  clearAuthError();
                  setFormData({ name: '', email: '', password: '', confirmPassword: '' });
                }}
                disabled={isSubmitting}
                className="text-yellow-600 hover:text-yellow-700 font-medium disabled:opacity-50"
              >
                {isLogin 
                  ? 'Não tem uma conta? Cadastre-se' 
                  : 'Já tem uma conta? Faça login'
                }
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Minha Conta
            {isDemoMode && <span className="text-sm text-blue-600 ml-2">(Demo)</span>}
          </h1>
          <p className="text-gray-600">
            Olá, {user?.name}! Gerencie sua conta e pedidos.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-black" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{user?.name}</h3>
                  <p className="text-sm text-gray-600">{user?.email}</p>
                </div>
              </div>

              <nav className="space-y-2">
                <button
                  onClick={() => setActiveTab('profile')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                    activeTab === 'profile' ? 'bg-yellow-50 text-yellow-700' : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <User className="w-5 h-5" />
                  <span>Perfil</span>
                </button>

                <button
                  onClick={() => setActiveTab('orders')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                    activeTab === 'orders' ? 'bg-yellow-50 text-yellow-700' : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Package className="w-5 h-5" />
                  <span>Meus Pedidos</span>
                </button>

                <button
                  onClick={() => setActiveTab('addresses')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                    activeTab === 'addresses' ? 'bg-yellow-50 text-yellow-700' : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <MapPin className="w-5 h-5" />
                  <span>Endereços</span>
                </button>

                <button
                  onClick={() => setActiveTab('favorites')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                    activeTab === 'favorites' ? 'bg-yellow-50 text-yellow-700' : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Heart className="w-5 h-5" />
                  <span>Favoritos</span>
                </button>

                <button
                  onClick={logout}
                  className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left text-red-600 hover:bg-red-50 transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Sair</span>
                </button>
              </nav>
            </div>
          </div>

          {/* Content */}
          <div className="lg:col-span-3">
            {/* Profile Tab */}
            {activeTab === 'profile' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Informações Pessoais</h2>
                
                {userProfile ? (
                  <form onSubmit={handleProfileUpdate} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Nome Completo
                        </label>
                        <input
                          name="fullName"
                          type="text"
                          defaultValue={userProfile.full_name || ''}
                          disabled={isUpdatingProfile}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 disabled:bg-gray-100"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          E-mail
                        </label>
                        <input
                          type="email"
                          value={userProfile.email}
                          disabled
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-100 text-gray-500"
                        />
                        <p className="text-xs text-gray-500 mt-1">O e-mail não pode ser alterado</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Telefone
                        </label>
                        <input
                          name="phone"
                          type="tel"
                          defaultValue={userProfile.phone || ''}
                          disabled={isUpdatingProfile}
                          placeholder="(11) 99999-9999"
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 disabled:bg-gray-100"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Data de Nascimento
                        </label>
                        <input
                          name="birthDate"
                          type="date"
                          defaultValue={userProfile.birth_date || ''}
                          disabled={isUpdatingProfile}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 disabled:bg-gray-100"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isUpdatingProfile}
                      className="bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                    >
                      {isUpdatingProfile ? (
                        <>
                          <Loader className="w-4 h-4 animate-spin mr-2" />
                          Salvando...
                        </>
                      ) : (
                        'Salvar Alterações'
                      )}
                    </button>
                  </form>
                ) : (
                  <div className="text-center py-8">
                    <Loader className="w-8 h-8 animate-spin mx-auto mb-4 text-yellow-600" />
                    <p className="text-gray-600">Carregando perfil...</p>
                  </div>
                )}

                {/* Seção de Redefinição de Senha */}
                <div className="mt-8 pt-8 border-t border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Gerenciamento de Senha</h3>
                  
                  <button
                    onClick={() => {
                      setResetEmail(user?.email || '');
                      setShowResetPassword(true);
                      setIsLogin(true);
                      logout();
                    }}
                    className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span>Redefinir Senha</span>
                  </button>
                  
                  <p className="text-sm text-gray-500 mt-2">
                    Você receberá um e-mail com instruções para redefinir sua senha.
                  </p>
                </div>
              </div>
            )}

            {/* Orders Tab */}
            {activeTab === 'orders' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">
                  Meus Pedidos
                  {isDemoMode && <span className="text-sm text-blue-600 ml-2">(Demo)</span>}
                </h2>
                
                <div className="space-y-4">
                  {mockOrders.map((order) => (
                    <div key={order.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h3 className="font-semibold text-gray-900">{order.id}</h3>
                          <p className="text-sm text-gray-600">Pedido realizado em {order.date}</p>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                          order.status === 'Entregue' ? 'bg-green-100 text-green-800' :
                          order.status === 'Em trânsito' ? 'bg-blue-100 text-blue-800' :
                          'bg-yellow-100 text-yellow-800'
                        }`}>
                          {order.status}
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="text-sm text-gray-600">
                          {order.items} {order.items === 1 ? 'item' : 'itens'} • R$ {order.total.toFixed(2)}
                        </div>
                        <button className="text-yellow-600 hover:text-yellow-700 text-sm font-medium">
                          Ver Detalhes
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Addresses Tab */}
            {activeTab === 'addresses' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-gray-900">Meus Endereços</h2>
                  <button className="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors">
                    Adicionar Endereço
                  </button>
                </div>
                
                <div className="text-center py-12">
                  <MapPin className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500 mb-2">Nenhum endereço cadastrado</p>
                  <p className="text-sm text-gray-400">Adicione um endereço para facilitar suas compras</p>
                </div>
              </div>
            )}

            {/* Favorites Tab */}
            {activeTab === 'favorites' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Meus Favoritos</h2>
                
                <div className="text-center py-12">
                  <Heart className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500 mb-2">Nenhum produto favoritado</p>
                  <p className="text-sm text-gray-400 mb-4">Adicione produtos aos favoritos para encontrá-los facilmente</p>
                  <button
                    onClick={() => onNavigate('shop')}
                    className="bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors"
                  >
                    Explorar Produtos
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Account;