import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  Package, 
  ShoppingCart, 
  Users, 
  Settings, 
  BarChart3, 
  Plus, 
  Edit, 
  Trash2, 
  Save, 
  X,
  Upload,
  Eye,
  LogOut,
  Home,
  DollarSign,
  TrendingUp,
  AlertCircle,
  Palette,
  Image as ImageIcon,
  RotateCcw,
  Check,
  RefreshCw,
  ArrowLeft,
  CreditCard
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSiteCustomization } from '../contexts/SiteCustomizationContext';
import { useProducts } from '../contexts/ProductContext';
import { Product } from '../types';
import ImageUploader from '../components/Admin/ImageUploader';
import ColorPicker from '../components/Admin/ColorPicker';
import ProductForm from '../components/Admin/ProductForm';
import OrderManagement from '../components/Admin/OrderManagement';

interface AdminDashboardProps {
  onLogout: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onLogout }) => {
  const { adminUser, adminLogout } = useAuth();
  const { colors, images, updateColors, updateImages, resetToDefaults } = useSiteCustomization();
  const { products, addProduct, updateProduct, deleteProduct } = useProducts();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  // Estados para controle das alterações
  const [pendingColors, setPendingColors] = useState(colors);
  const [pendingImages, setPendingImages] = useState(images);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [isApplying, setIsApplying] = useState(false);
  const [lastApplied, setLastApplied] = useState<Date | null>(null);

  // Sincronizar estados pendentes com os valores atuais
  useEffect(() => {
    setPendingColors(colors);
    setPendingImages(images);
  }, [colors, images]);

  // Detectar mudanças não salvas
  useEffect(() => {
    const colorsChanged = JSON.stringify(pendingColors) !== JSON.stringify(colors);
    const imagesChanged = JSON.stringify(pendingImages) !== JSON.stringify(images);
    setHasUnsavedChanges(colorsChanged || imagesChanged);
  }, [pendingColors, pendingImages, colors, images]);

  // Dados mockados para o dashboard
  const dashboardStats = {
    totalProducts: products.length,
    totalOrders: 156,
    totalRevenue: 45890.50,
    activeUsers: 1247,
    pendingPayments: 23,
    monthlyGrowth: 12.5
  };

  const recentOrders = [
    { id: '#CD001', customer: 'Ana Silva', total: 299.90, status: 'Entregue', paymentStatus: 'paid', date: '2024-01-15' },
    { id: '#CD002', customer: 'Carlos Mendes', total: 189.90, status: 'Em trânsito', paymentStatus: 'paid', date: '2024-01-14' },
    { id: '#CD003', customer: 'Marina Costa', total: 449.80, status: 'Processando', paymentStatus: 'pending', date: '2024-01-13' },
    { id: '#CD004', customer: 'João Santos', total: 329.90, status: 'Confirmado', paymentStatus: 'paid', date: '2024-01-12' },
    { id: '#CD005', customer: 'Lucia Oliveira', total: 219.90, status: 'Entregue', paymentStatus: 'paid', date: '2024-01-11' }
  ];

  // Função para voltar ao menu principal (página inicial)
  const handleBackToMainMenu = () => {
    // Navegar para a página inicial na mesma aba
    window.location.href = '/';
  };

  const handleAddProduct = () => {
    setIsAddingProduct(true);
    setEditingProduct(null);
    setActiveTab('products');
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setIsAddingProduct(false);
    setActiveTab('products');
  };

  const handleSaveProduct = (productData: Omit<Product, 'id'> | Product) => {
    if (editingProduct) {
      // Editando produto existente
      updateProduct(editingProduct.id, productData);
      alert('Produto atualizado com sucesso!');
    } else {
      // Adicionando novo produto
      addProduct(productData as Omit<Product, 'id'>);
      alert('Produto adicionado com sucesso!');
    }
    
    setIsAddingProduct(false);
    setEditingProduct(null);
  };

  const handleDeleteProduct = (product: Product) => {
    if (confirm(`Tem certeza que deseja excluir o produto "${product.name}"?`)) {
      deleteProduct(product.id);
      alert('Produto excluído com sucesso!');
    }
  };

  const handleCancelProductForm = () => {
    setIsAddingProduct(false);
    setEditingProduct(null);
  };

  // Função para aplicar as alterações em tempo real
  const handleApplyChanges = async () => {
    setIsApplying(true);
    
    try {
      // Simular salvamento no banco de dados (delay para feedback visual)
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Aplicar as mudanças nos contextos
      updateColors(pendingColors);
      updateImages(pendingImages);
      
      // Marcar como aplicado
      setLastApplied(new Date());
      setHasUnsavedChanges(false);
      
      // Feedback visual de sucesso
      const successMessage = document.createElement('div');
      successMessage.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 flex items-center space-x-2';
      successMessage.innerHTML = `
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
        </svg>
        <span>Alterações aplicadas com sucesso!</span>
      `;
      
      document.body.appendChild(successMessage);
      
      // Remover mensagem após 3 segundos
      setTimeout(() => {
        if (document.body.contains(successMessage)) {
          document.body.removeChild(successMessage);
        }
      }, 3000);
      
    } catch (error) {
      console.error('Erro ao aplicar alterações:', error);
      alert('Erro ao aplicar alterações. Tente novamente.');
    } finally {
      setIsApplying(false);
    }
  };

  // Função para descartar alterações
  const handleDiscardChanges = () => {
    if (confirm('Tem certeza que deseja descartar todas as alterações não salvas?')) {
      setPendingColors(colors);
      setPendingImages(images);
      setHasUnsavedChanges(false);
    }
  };

  const handleLogout = () => {
    adminLogout();
    onLogout();
  };

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total de Produtos</p>
              <p className="text-2xl font-bold text-gray-900">{dashboardStats.totalProducts}</p>
            </div>
            <Package className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pedidos Totais</p>
              <p className="text-2xl font-bold text-gray-900">{dashboardStats.totalOrders}</p>
            </div>
            <ShoppingCart className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Receita Total</p>
              <p className="text-2xl font-bold text-gray-900">R$ {dashboardStats.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
            </div>
            <DollarSign className="w-8 h-8 text-yellow-500" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pagamentos Pendentes</p>
              <p className="text-2xl font-bold text-gray-900">{dashboardStats.pendingPayments}</p>
            </div>
            <CreditCard className="w-8 h-8 text-red-500" />
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Ações Rápidas</h3>
          <div className="space-y-3">
            <button
              onClick={handleAddProduct}
              className="w-full flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Produto</span>
            </button>
            <button
              onClick={() => setActiveTab('orders')}
              className="w-full flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>Ver Pedidos</span>
            </button>
            <button
              onClick={() => setActiveTab('customization')}
              className="w-full flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              <Palette className="w-4 h-4" />
              <span>Personalizar Site</span>
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Estatísticas</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Crescimento Mensal</span>
              <div className="flex items-center space-x-1 text-green-600">
                <TrendingUp className="w-4 h-4" />
                <span className="font-semibold">+{dashboardStats.monthlyGrowth}%</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Usuários Ativos</span>
              <span className="font-semibold text-gray-900">{dashboardStats.activeUsers}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Taxa de Conversão</span>
              <span className="font-semibold text-gray-900">3.2%</span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Alertas</h3>
          <div className="space-y-3">
            <div className="flex items-start space-x-2 p-3 bg-yellow-50 rounded-lg">
              <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-yellow-800">Pagamentos Pendentes</p>
                <p className="text-xs text-yellow-600">{dashboardStats.pendingPayments} pagamentos aguardando confirmação</p>
              </div>
            </div>
            <div className="flex items-start space-x-2 p-3 bg-blue-50 rounded-lg">
              <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-blue-800">Produtos em Destaque</p>
                <p className="text-xs text-blue-600">3 produtos precisam de atualização</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Orders */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">Pedidos Recentes</h3>
            <button
              onClick={() => setActiveTab('orders')}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium"
            >
              Ver todos
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Pedido</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Cliente</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Pagamento</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Data</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {recentOrders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{order.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{order.customer}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">R$ {order.total.toFixed(2)}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      order.status === 'Entregue' ? 'bg-green-100 text-green-800' :
                      order.status === 'Em trânsito' ? 'bg-blue-100 text-blue-800' :
                      order.status === 'Processando' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      order.paymentStatus === 'paid' ? 'bg-green-100 text-green-800' :
                      order.paymentStatus === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {order.paymentStatus === 'paid' ? 'Pago' : 
                       order.paymentStatus === 'pending' ? 'Pendente' : 'Cancelado'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{order.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderProducts = () => {
    if (isAddingProduct || editingProduct) {
      return (
        <ProductForm
          product={editingProduct || undefined}
          onSave={handleSaveProduct}
          onCancel={handleCancelProductForm}
          isEditing={!!editingProduct}
        />
      );
    }

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900">Gerenciar Produtos</h2>
          <button
            onClick={handleAddProduct}
            className="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Adicionar Produto</span>
          </button>
        </div>

        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produto</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Categoria</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Preço</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estoque</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {products.map((product) => (
                  <tr key={product.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="relative">
                          <img
                            src={product.images[0]}
                            alt={product.name}
                            className="w-12 h-12 object-cover rounded-lg"
                          />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{product.name}</p>
                          <p className="text-sm text-gray-500">ID: {product.id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900 capitalize">{product.category}</td>
                    <td className="px-6 py-4 text-sm text-gray-900">R$ {product.price.toFixed(2)}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        product.inStock ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {product.inStock ? 'Em estoque' : 'Esgotado'}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleEditProduct(product)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Editar"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(product)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Excluir"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  const renderOrders = () => (
    <OrderManagement />
  );

  const renderCustomization = () => (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Personalização do Visual</h2>
        <div className="flex items-center space-x-3">
          {lastApplied && (
            <span className="text-sm text-gray-500">
              Última aplicação: {lastApplied.toLocaleTimeString()}
            </span>
          )}
          <button
            onClick={resetToDefaults}
            className="flex items-center space-x-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Restaurar Padrão</span>
          </button>
        </div>
      </div>

      {/* Barra de Status das Alterações */}
      {hasUnsavedChanges && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <AlertCircle className="w-5 h-5 text-amber-600" />
              <div>
                <p className="text-sm font-medium text-amber-800">
                  Você tem alterações não aplicadas
                </p>
                <p className="text-xs text-amber-600">
                  Clique em "Aplicar Alterações" para salvar e aplicar as mudanças no site
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={handleDiscardChanges}
                className="px-3 py-1 text-xs border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
              >
                Descartar
              </button>
              <button
                onClick={handleApplyChanges}
                disabled={isApplying}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
              >
                {isApplying ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Aplicando...</span>
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Aplicar Alterações</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Seção de Cores */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center space-x-2 mb-6">
            <Palette className="w-5 h-5 text-gray-700" />
            <h3 className="text-lg font-semibold text-gray-900">Cores do Site</h3>
          </div>
          
          <div className="space-y-6">
            <ColorPicker
              label="Cor Principal (Amarelo)"
              value={pendingColors.primary}
              onChange={(color) => setPendingColors(prev => ({ ...prev, primary: color }))}
              presets={['#facc15', '#f59e0b', '#eab308', '#ca8a04', '#a16207']}
            />
            
            <ColorPicker
              label="Cor Secundária (Preto)"
              value={pendingColors.secondary}
              onChange={(color) => setPendingColors(prev => ({ ...prev, secondary: color }))}
              presets={['#000000', '#1f2937', '#374151', '#4b5563', '#6b7280']}
            />
            
            <ColorPicker
              label="Cor de Destaque"
              value={pendingColors.accent}
              onChange={(color) => setPendingColors(prev => ({ ...prev, accent: color }))}
              presets={['#f59e0b', '#ef4444', '#3b82f6', '#10b981', '#8b5cf6']}
            />
            
            <ColorPicker
              label="Fundo do Cabeçalho"
              value={pendingColors.headerBg}
              onChange={(color) => setPendingColors(prev => ({ ...prev, headerBg: color }))}
              presets={['#000000', '#1f2937', '#374151', '#ffffff', '#f9fafb']}
            />
            
            <ColorPicker
              label="Cor dos Botões"
              value={pendingColors.buttonBg}
              onChange={(color) => setPendingColors(prev => ({ ...prev, buttonBg: color }))}
              presets={['#facc15', '#000000', '#ef4444', '#3b82f6', '#10b981']}
            />
            
            <ColorPicker
              label="Texto dos Botões"
              value={pendingColors.buttonText}
              onChange={(color) => setPendingColors(prev => ({ ...prev, buttonText: color }))}
              presets={['#000000', '#ffffff', '#1f2937', '#374151']}
            />
          </div>
        </div>

        {/* Seção de Imagens */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center space-x-2 mb-6">
            <ImageIcon className="w-5 h-5 text-gray-700" />
            <h3 className="text-lg font-semibold text-gray-900">Imagens do Site</h3>
          </div>
          
          <div className="space-y-8">
            <ImageUploader
              label="Banner Principal (Página Inicial)"
              description="Imagem de fundo da seção hero. Recomendado: 1920x1080px"
              currentImage={pendingImages.heroBanner}
              onImageChange={(url) => setPendingImages(prev => ({ ...prev, heroBanner: url }))}
              aspectRatio="aspect-video"
            />
            
            <ImageUploader
              label="Categoria: Saltos Femininos"
              description="Imagem da categoria de saltos. Recomendado: 800x600px"
              currentImage={pendingImages.categoryImages.saltos}
              onImageChange={(url) => setPendingImages(prev => ({ 
                ...prev, 
                categoryImages: { ...prev.categoryImages, saltos: url }
              }))}
              aspectRatio="aspect-[4/3]"
            />
            
            <ImageUploader
              label="Categoria: Sapatilhas"
              description="Imagem da categoria de sapatilhas. Recomendado: 800x600px"
              currentImage={pendingImages.categoryImages.sapatilhas}
              onImageChange={(url) => setPendingImages(prev => ({ 
                ...prev, 
                categoryImages: { ...prev.categoryImages, sapatilhas: url }
              }))}
              aspectRatio="aspect-[4/3]"
            />
            
            <ImageUploader
              label="Categoria: Sapatos Masculinos"
              description="Imagem da categoria masculina. Recomendado: 800x600px"
              currentImage={pendingImages.categoryImages.masculinos}
              onImageChange={(url) => setPendingImages(prev => ({ 
                ...prev, 
                categoryImages: { ...prev.categoryImages, masculinos: url }
              }))}
              aspectRatio="aspect-[4/3]"
            />
          </div>
        </div>
      </div>

      {/* Preview das Mudanças */}
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Preview das Cores</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div 
              className="w-full h-16 rounded-lg mb-2 border"
              style={{ backgroundColor: pendingColors.primary }}
            />
            <p className="text-xs text-gray-600">Cor Principal</p>
          </div>
          <div className="text-center">
            <div 
              className="w-full h-16 rounded-lg mb-2 border"
              style={{ backgroundColor: pendingColors.secondary }}
            />
            <p className="text-xs text-gray-600">Cor Secundária</p>
          </div>
          <div className="text-center">
            <div 
              className="w-full h-16 rounded-lg mb-2 border"
              style={{ backgroundColor: pendingColors.accent }}
            />
            <p className="text-xs text-gray-600">Cor de Destaque</p>
          </div>
          <div className="text-center">
            <div 
              className="w-full h-16 rounded-lg mb-2 border flex items-center justify-center text-sm font-medium"
              style={{ 
                backgroundColor: pendingColors.buttonBg,
                color: pendingColors.buttonText
              }}
            >
              Botão
            </div>
            <p className="text-xs text-gray-600">Botões</p>
          </div>
        </div>
      </div>

      {/* Botão Principal de Aplicar Alterações */}
      <div className="flex justify-center">
        <button
          onClick={handleApplyChanges}
          disabled={!hasUnsavedChanges || isApplying}
          className="px-8 py-4 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-3 text-lg font-semibold shadow-lg"
        >
          {isApplying ? (
            <>
              <RefreshCw className="w-6 h-6 animate-spin" />
              <span>Aplicando Alterações...</span>
            </>
          ) : (
            <>
              <Check className="w-6 h-6" />
              <span>Aplicar Todas as Alterações</span>
            </>
          )}
        </button>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Configurações do Site</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Configurações Gerais */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Configurações Gerais</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Nome da Loja</label>
              <input
                type="text"
                defaultValue="Comfydance"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Descrição</label>
              <textarea
                defaultValue="Especialistas em calçados de dança com qualidade premium"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
                rows={3}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">E-mail de Contato</label>
              <input
                type="email"
                defaultValue="contato@comfydance.com"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
            </div>
          </div>
        </div>

        {/* Configurações de Pagamento */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Configurações de Pagamento</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Desconto PIX (%)</label>
              <input
                type="number"
                defaultValue="5"
                min="0"
                max="100"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Vencimento Boleto (dias)</label>
              <input
                type="number"
                defaultValue="3"
                min="1"
                max="30"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Expiração PIX (minutos)</label>
              <input
                type="number"
                defaultValue="30"
                min="5"
                max="120"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
            </div>
          </div>
        </div>

        {/* Configurações de Entrega */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Configurações de Entrega</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Frete Grátis Acima de</label>
              <input
                type="number"
                defaultValue="200"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Taxa de Frete Padrão</label>
              <input
                type="number"
                defaultValue="15.90"
                step="0.01"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Prazo de Entrega (dias)</label>
              <input
                type="number"
                defaultValue="7"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
            </div>
          </div>
        </div>

        {/* Configurações de API */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">APIs de Pagamento</h3>
          <div className="space-y-4">
            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <AlertCircle className="w-4 h-4 text-yellow-600" />
                <span className="text-sm font-medium text-yellow-800">Configuração Necessária</span>
              </div>
              <p className="text-sm text-yellow-700">
                Configure as chaves de API dos provedores de pagamento nas variáveis de ambiente:
              </p>
              <ul className="text-xs text-yellow-600 mt-2 space-y-1">
                <li>• VITE_MERCADOPAGO_ACCESS_TOKEN</li>
                <li>• VITE_GERENCIANET_CLIENT_ID</li>
                <li>• VITE_ASAAS_ACCESS_TOKEN</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <button className="bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors flex items-center space-x-2">
          <Save className="w-4 h-4" />
          <span>Salvar Configurações</span>
        </button>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return renderDashboard();
      case 'products':
        return renderProducts();
      case 'orders':
        return renderOrders();
      case 'customization':
        return renderCustomization();
      case 'settings':
        return renderSettings();
      default:
        return renderDashboard();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Shield className="w-8 h-8 text-yellow-400" />
                <h1 className="text-xl font-bold text-gray-900">Painel Administrativo</h1>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{adminUser?.name}</p>
                <p className="text-xs text-gray-500">Administrador</p>
              </div>
              
              <button
                onClick={handleBackToMainMenu}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                title="Voltar para o Menu Principal"
              >
                <ArrowLeft className="w-4 h-4" />
                <span className="hidden sm:inline">Voltar para o Menu Principal</span>
                <span className="sm:hidden">Voltar</span>
              </button>
              
              <button
                onClick={handleLogout}
                className="p-2 text-gray-600 hover:text-red-600 transition-colors"
                title="Sair"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64">
            <nav className="bg-white rounded-lg shadow-md p-4">
              <ul className="space-y-2">
                <li>
                  <button
                    onClick={() => setActiveTab('dashboard')}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'dashboard' ? 'bg-yellow-50 text-yellow-700' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <BarChart3 className="w-5 h-5" />
                    <span>Dashboard</span>
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setActiveTab('products')}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'products' ? 'bg-yellow-50 text-yellow-700' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <Package className="w-5 h-5" />
                    <span>Produtos</span>
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setActiveTab('orders')}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'orders' ? 'bg-yellow-50 text-yellow-700' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <ShoppingCart className="w-5 h-5" />
                      <span>Pedidos</span>
                    </div>
                    {dashboardStats.pendingPayments > 0 && (
                      <span className="bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                        {dashboardStats.pendingPayments}
                      </span>
                    )}
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setActiveTab('customization')}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'customization' ? 'bg-yellow-50 text-yellow-700' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <Palette className="w-5 h-5" />
                      <span>Personalização</span>
                    </div>
                    {hasUnsavedChanges && (
                      <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                    )}
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setActiveTab('settings')}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === 'settings' ? 'bg-yellow-50 text-yellow-700' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <Settings className="w-5 h-5" />
                    <span>Configurações</span>
                  </button>
                </li>
              </ul>
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {renderContent()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;