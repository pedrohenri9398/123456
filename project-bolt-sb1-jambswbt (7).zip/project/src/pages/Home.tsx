import React from 'react';
import { ArrowRight, Star, Shield, Truck, Heart, ChevronLeft, ChevronRight } from 'lucide-react';
import { useProducts } from '../contexts/ProductContext';
import { useSiteCustomization } from '../contexts/SiteCustomizationContext';
import ProductCard from '../components/Product/ProductCard';

interface HomeProps {
  onNavigate: (page: string) => void;
  onProductClick: (productId: string) => void;
}

const Home: React.FC<HomeProps> = ({ onNavigate, onProductClick }) => {
  const { products } = useProducts();
  const { images, colors } = useSiteCustomization();
  const featuredProducts = products.filter(product => product.featured);
  const testimonials = [
    {
      id: 1,
      name: 'Ana Silva',
      rating: 5,
      comment: 'Qualidade excepcional! Os sapatos são lindos e super confortáveis para dançar.',
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100'
    },
    {
      id: 2,
      name: 'Carlos Mendes',
      rating: 5,
      comment: 'Excelente atendimento e produtos de primeira qualidade. Recomendo!',
      image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100'
    },
    {
      id: 3,
      name: 'Marina Costa',
      rating: 5,
      comment: 'Meus sapatos favoritos! Perfeitos para apresentações e super elegantes.',
      image: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=100'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative text-white">
        <div className="absolute inset-0 bg-black bg-opacity-40"></div>
        <div 
          className="relative min-h-[70vh] sm:min-h-[80vh] flex items-center bg-cover bg-center"
          style={{
            backgroundImage: `url(${images.heroBanner})`
          }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-60"></div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-3xl sm:text-4xl md:text-6xl font-bold mb-4 sm:mb-6 leading-tight">
              Dance com <span style={{ color: colors.primary }}>Conforto</span>
              <br />
              Brilhe com <span style={{ color: colors.primary }}>Estilo</span>
            </h1>
            <p className="text-lg sm:text-xl md:text-2xl mb-6 sm:mb-8 text-gray-200 max-w-3xl mx-auto px-4">
              Bem-vindo à Comfydance. Especialistas em calçados de dança com qualidade premium e design elegante.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center px-4">
              <button
                onClick={() => onNavigate('shop')}
                className="w-full sm:w-auto px-6 sm:px-8 py-3 sm:py-4 rounded-lg font-semibold hover:opacity-90 transition-colors flex items-center justify-center space-x-2"
                style={{ 
                  backgroundColor: colors.buttonBg, 
                  color: colors.buttonText 
                }}
              >
                <span>Ver Coleção</span>
                <ArrowRight className="w-5 h-5" />
              </button>
              <button
                onClick={() => onNavigate('about')}
                className="w-full sm:w-auto border-2 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-lg font-semibold hover:bg-white hover:text-black transition-colors"
                style={{ borderColor: 'white' }}
              >
                Sobre Nós
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-12 sm:py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Nossas <span style={{ color: colors.accent }}>Categorias</span>
            </h2>
            <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto px-4">
              Encontre o calçado perfeito para seu estilo de dança
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            <div className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="aspect-[4/3] bg-gradient-to-br from-pink-500 to-purple-600">
                <img
                  src={images.categoryImages.saltos}
                  alt="Saltos Femininos"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 group-hover:bg-opacity-20 transition-all duration-300"></div>
                <div className="absolute inset-0 flex flex-col justify-end p-4 sm:p-6 text-white">
                  <h3 className="text-xl sm:text-2xl font-bold mb-2">Saltos Femininos</h3>
                  <p className="text-sm opacity-90 mb-4">Elegância e sofisticação para suas apresentações</p>
                  <button 
                    onClick={() => onNavigate('shop')}
                    className="self-start px-4 py-2 rounded-lg font-medium hover:opacity-90 transition-colors text-sm sm:text-base"
                    style={{ 
                      backgroundColor: colors.buttonBg, 
                      color: colors.buttonText 
                    }}
                  >
                    Ver Coleção
                  </button>
                </div>
              </div>
            </div>

            <div className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="aspect-[4/3] bg-gradient-to-br from-blue-500 to-indigo-600">
                <img
                  src={images.categoryImages.sapatilhas}
                  alt="Sapatilhas"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 group-hover:bg-opacity-20 transition-all duration-300"></div>
                <div className="absolute inset-0 flex flex-col justify-end p-4 sm:p-6 text-white">
                  <h3 className="text-xl sm:text-2xl font-bold mb-2">Sapatilhas</h3>
                  <p className="text-sm opacity-90 mb-4">Leveza e flexibilidade para todos os estilos</p>
                  <button 
                    onClick={() => onNavigate('shop')}
                    className="self-start px-4 py-2 rounded-lg font-medium hover:opacity-90 transition-colors text-sm sm:text-base"
                    style={{ 
                      backgroundColor: colors.buttonBg, 
                      color: colors.buttonText 
                    }}
                  >
                    Ver Coleção
                  </button>
                </div>
              </div>
            </div>

            <div className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="aspect-[4/3] bg-gradient-to-br from-gray-700 to-black">
                <img
                  src={images.categoryImages.masculinos}
                  alt="Sapatos Masculinos"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 group-hover:bg-opacity-20 transition-all duration-300"></div>
                <div className="absolute inset-0 flex flex-col justify-end p-4 sm:p-6 text-white">
                  <h3 className="text-xl sm:text-2xl font-bold mb-2">Sapatos Masculinos</h3>
                  <p className="text-sm opacity-90 mb-4">Estilo e conforto para dançarinos exigentes</p>
                  <button 
                    onClick={() => onNavigate('shop')}
                    className="self-start px-4 py-2 rounded-lg font-medium hover:opacity-90 transition-colors text-sm sm:text-base"
                    style={{ 
                      backgroundColor: colors.buttonBg, 
                      color: colors.buttonText 
                    }}
                  >
                    Ver Coleção
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-12 sm:py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Produtos em <span style={{ color: colors.accent }}>Destaque</span>
            </h2>
            <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto px-4">
              Nossos modelos mais populares e bem avaliados
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {featuredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onClick={() => onProductClick(product.id)}
              />
            ))}
          </div>

          <div className="text-center mt-8 sm:mt-12">
            <button
              onClick={() => onNavigate('shop')}
              className="px-6 sm:px-8 py-3 rounded-lg hover:opacity-90 transition-colors font-medium inline-flex items-center space-x-2"
              style={{ 
                backgroundColor: colors.secondary, 
                color: 'white' 
              }}
            >
              <span>Ver Todos os Produtos</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section 
        className="py-12 sm:py-16 text-white"
        style={{ backgroundColor: colors.secondary }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            <div className="text-center group">
              <div 
                className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300"
                style={{ backgroundColor: colors.primary }}
              >
                <Truck className="w-8 h-8" style={{ color: colors.secondary }} />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold mb-2">Frete Grátis</h3>
              <p className="text-gray-300 text-sm sm:text-base px-4">Para compras acima de R$ 200,00 em todo o Brasil</p>
            </div>

            <div className="text-center group">
              <div 
                className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300"
                style={{ backgroundColor: colors.primary }}
              >
                <Shield className="w-8 h-8" style={{ color: colors.secondary }} />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold mb-2">Garantia de Qualidade</h3>
              <p className="text-gray-300 text-sm sm:text-base px-4">30 dias para trocas e devoluções sem complicação</p>
            </div>

            <div className="text-center group">
              <div 
                className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300"
                style={{ backgroundColor: colors.primary }}
              >
                <Heart className="w-8 h-8" style={{ color: colors.secondary }} />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold mb-2">Atendimento Premium</h3>
              <p className="text-gray-300 text-sm sm:text-base px-4">Suporte especializado para encontrar seu calçado ideal</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-12 sm:py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              O que nossos <span style={{ color: colors.accent }}>clientes</span> dizem
            </h2>
            <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto px-4">
              Avaliações reais de dançarinos que confiam na Comfydance
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="bg-white p-4 sm:p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
                <div className="flex items-center mb-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-10 h-10 sm:w-12 sm:h-12 rounded-full object-cover mr-3 sm:mr-4"
                  />
                  <div>
                    <h4 className="font-semibold text-gray-900 text-sm sm:text-base">{testimonial.name}</h4>
                    <div className="flex items-center">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-3 h-3 sm:w-4 sm:h-4 fill-current" style={{ color: colors.primary }} />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 italic text-sm sm:text-base">"{testimonial.comment}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section 
        className="py-12 sm:py-16 text-white"
        style={{ backgroundColor: colors.secondary }}
      >
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4">
            Fique por dentro das <span style={{ color: colors.primary }}>novidades</span>
          </h2>
          <p className="text-lg sm:text-xl text-gray-300 mb-6 sm:mb-8 px-4">
            Receba ofertas exclusivas, lançamentos e dicas de dança
          </p>
          
          <div className="max-w-md mx-auto px-4">
            <div className="flex flex-col sm:flex-row rounded-lg overflow-hidden">
              <input
                type="email"
                placeholder="Seu melhor e-mail"
                className="flex-1 px-4 py-3 text-black focus:outline-none mb-2 sm:mb-0 rounded-lg sm:rounded-r-none"
              />
              <button 
                className="px-6 py-3 font-semibold hover:opacity-90 transition-colors rounded-lg sm:rounded-l-none"
                style={{ 
                  backgroundColor: colors.buttonBg, 
                  color: colors.buttonText 
                }}
              >
                Inscrever
              </button>
            </div>
            <p className="text-sm text-gray-400 mt-3">
              Não enviamos spam. Cancele quando quiser.
            </p>
          </div>
        </div>
      </section>

      {/* Location Footer */}
      <section className="py-8 bg-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-8 text-gray-600">
            <div className="flex items-center space-x-2">
              <span className="text-yellow-600">🏪</span>
              <span className="text-sm">Loja: Brasília, DF</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-green-600">💻</span>
              <span className="text-sm">Desenvolvido em Luziânia, GO</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-blue-600">🚚</span>
              <span className="text-sm">Entregamos em todo Brasil</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;