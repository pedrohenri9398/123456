import React, { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Send, MessageCircle, Code, Instagram, Navigation, ExternalLink } from 'lucide-react';
import LocationMap from '../components/Location/LocationMap';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  // Coordenadas de Brasília (nossa loja)
  const BRASILIA_COORDS = { lat: -15.7942, lng: -47.8822 };
  const LUZIANIA_COORDS = { lat: -16.2523, lng: -47.9502 };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
    alert('Mensagem enviada com sucesso! Entraremos em contato em breve.');
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const contactInfo = [
    {
      icon: Phone,
      title: 'Telefone',
      content: '(61) 99611-1535',
      description: 'Segunda a sexta: 8h às 19h'
    },
    {
      icon: Mail,
      title: 'E-mail',
      content: 'sapatos.comfydance@gmail.com',
      description: 'Respondemos em até 24h'
    },
    {
      icon: MapPin,
      title: 'Localização',
      content: 'Brasília, DF',
      description: 'Atendimento online nacional'
    },
    {
      icon: Clock,
      title: 'Horário de Atendimento',
      content: 'Seg - Sex: 8h às 19h',
      description: 'Sáb: 8h às 19h'
    }
  ];

  const faqs = [
    {
      question: 'Como escolher o tamanho correto?',
      answer: 'Recomendamos consultar nossa tabela de medidas. Se tiver dúvidas, nossa equipe pode ajudar via WhatsApp.'
    },
    {
      question: 'Qual o prazo de entrega?',
      answer: 'Entregamos em todo Brasil. Prazo varia de 3 a 10 dias úteis dependendo da região.'
    },
    {
      question: 'Posso trocar se não servir?',
      answer: 'Sim! Você tem 30 dias para trocas e devoluções. O produto deve estar em perfeito estado.'
    },
    {
      question: 'Vocês fazem sapatos sob medida?',
      answer: 'Oferecemos serviços personalizados para casos especiais. Entre em contato para mais informações.'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-black to-gray-800 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Entre em <span className="text-yellow-400">Contato</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Estamos aqui para ajudar você a encontrar o calçado perfeito. 
            Fale conosco através dos canais abaixo.
          </p>
        </div>
      </section>

      {/* Contact Info */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {contactInfo.map((info, index) => {
              const Icon = info.icon;
              return (
                <div key={index} className="bg-white p-6 rounded-xl shadow-md text-center hover:shadow-lg transition-shadow">
                  <div className="bg-yellow-400 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-8 h-8 text-black" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{info.title}</h3>
                  <p className="text-gray-900 font-medium mb-1">{info.content}</p>
                  <p className="text-sm text-gray-600">{info.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Contact Form & Quick Actions */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-8">
                Envie uma <span className="text-yellow-600">Mensagem</span>
              </h2>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                      Nome Completo
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                      placeholder="Seu nome"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                      E-mail
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                      placeholder="seu@email.com"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">
                    Assunto
                  </label>
                  <select
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                  >
                    <option value="">Selecione um assunto</option>
                    <option value="produto">Dúvidas sobre produtos</option>
                    <option value="pedido">Status do pedido</option>
                    <option value="troca">Trocas e devoluções</option>
                    <option value="tamanho">Consultoria de tamanho</option>
                    <option value="personalizado">Serviços personalizados</option>
                    <option value="outro">Outro</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                    Mensagem
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={6}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent resize-vertical"
                    placeholder="Descreva sua dúvida ou necessidade..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-black text-white py-4 rounded-lg hover:bg-gray-800 transition-colors font-semibold flex items-center justify-center space-x-2"
                >
                  <Send className="w-5 h-5" />
                  <span>Enviar Mensagem</span>
                </button>
              </form>
            </div>

            {/* Quick Actions & FAQ */}
            <div className="space-y-8">
              {/* Quick Actions */}
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">
                  Atendimento <span className="text-yellow-600">Rápido</span>
                </h3>
                
                <div className="space-y-4">
                  <a
                    href="https://wa.me/5561999999999"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center p-4 bg-green-50 border border-green-200 rounded-lg hover:bg-green-100 transition-colors group"
                  >
                    <MessageCircle className="w-8 h-8 text-green-600 mr-4" />
                    <div>
                      <h4 className="font-semibold text-gray-900 group-hover:text-green-700">
                        WhatsApp
                      </h4>
                      <p className="text-sm text-gray-600">
                        Atendimento imediato das 9h às 18h
                      </p>
                    </div>
                  </a>

                  <a
                    href="mailto:contato@comfydance.com"
                    className="flex items-center p-4 bg-blue-50 border border-blue-200 rounded-lg hover:bg-blue-100 transition-colors group"
                  >
                    <Mail className="w-8 h-8 text-blue-600 mr-4" />
                    <div>
                      <h4 className="font-semibold text-gray-900 group-hover:text-blue-700">
                        E-mail Direto
                      </h4>
                      <p className="text-sm text-gray-600">
                        contato@comfydance.com
                      </p>
                    </div>
                  </a>

                  <a
                    href="tel:+5561999999999"
                    className="flex items-center p-4 bg-yellow-50 border border-yellow-200 rounded-lg hover:bg-yellow-100 transition-colors group"
                  >
                    <Phone className="w-8 h-8 text-yellow-600 mr-4" />
                    <div>
                      <h4 className="font-semibold text-gray-900 group-hover:text-yellow-700">
                        Telefone
                      </h4>
                      <p className="text-sm text-gray-600">
                        (61) 99611-1535
                      </p>
                    </div>
                  </a>
                </div>
              </div>

              {/* FAQ Preview */}
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">
                  Perguntas <span className="text-yellow-600">Frequentes</span>
                </h3>
                
                <div className="space-y-4">
                  {faqs.map((faq, index) => (
                    <div key={index} className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-2">{faq.question}</h4>
                      <p className="text-sm text-gray-600">{faq.answer}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Maps Section */}
      <section className="py-16 bg-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Nossa <span className="text-yellow-600">Localização</span>
            </h2>
            <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
              Atendemos todo o Brasil a partir do coração do país, com tecnologia desenvolvida 
              no interior de Goiás.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Loja em Brasília */}
            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="flex items-center space-x-3 mb-4">
                <MapPin className="w-6 h-6 text-yellow-600" />
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">Nossa Loja</h3>
                  <p className="text-lg font-medium text-yellow-600">Brasília, DF</p>
                </div>
              </div>
              
              <LocationMap
                coordinates={BRASILIA_COORDS}
                address="Brasília, DF - Centro de operações e atendimento"
                height="250px"
                showOpenInMaps={true}
              />
              
              <div className="mt-4 text-sm text-gray-600">
                <p><strong>Centro de operações e atendimento</strong></p>
                <p>Entregamos para todo o Brasil com frete grátis acima de R$ 200,00</p>
              </div>
            </div>

            {/* Desenvolvimento em Luziânia */}
            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600 font-bold text-sm">💻</span>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">Desenvolvimento</h3>
                  <p className="text-lg font-medium text-green-600">Luziânia, GO</p>
                </div>
              </div>
              
              <LocationMap
                coordinates={LUZIANIA_COORDS}
                address="Luziânia, GO - Onde a inovação acontece"
                height="250px"
                showOpenInMaps={true}
              />
              
              <div className="mt-4 text-sm text-gray-600">
                <p><strong>Onde a inovação acontece</strong></p>
                <p>Site desenvolvido com tecnologia de ponta e muito carinho</p>
              </div>
            </div>
          </div>

          {/* Distance Calculator */}
          <div className="mt-8 bg-white p-6 rounded-xl shadow-md text-center">
            <h4 className="text-lg font-semibold text-gray-900 mb-4">
              📏 Calcule a distância da sua cidade
            </h4>
            <p className="text-gray-600 mb-4">
              Quer saber quanto tempo leva para chegar até você? Use nosso calculador de frete no checkout!
            </p>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="bg-yellow-400 text-black px-6 py-3 rounded-lg hover:bg-yellow-500 transition-colors font-medium"
            >
              Fazer Pedido e Calcular Frete
            </button>
          </div>
        </div>
      </section>

      {/* Developer Contact Section */}
      <section className="py-16 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8">
            <div className="flex flex-col items-center space-y-6">
              <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center">
                <Code className="w-8 h-8 text-white" />
              </div>
              
              <div>
                <h2 className="text-2xl font-bold mb-2">Precisa de Desenvolvimento Web?</h2>
                <p className="text-purple-100 mb-4">
                  Entre em contato com o desenvolvedor deste site
                </p>
                <p className="text-purple-100 text-sm max-w-md mx-auto">
                  Especialista em e-commerce, sistemas web e aplicações modernas
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
                <a
                  href="https://instagram.com/henrique_9397"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-3 bg-white text-purple-600 px-6 py-3 rounded-full hover:bg-purple-50 transition-all duration-300 transform hover:scale-105 font-semibold"
                >
                  <Instagram className="w-5 h-5" />
                  <span>@henrique_9397</span>
                </a>
                
                <div className="text-center">
                  <p className="text-sm font-medium text-purple-100">💻 Henrique - Desenvolvedor</p>
                  <p className="text-xs text-purple-200">Luziânia, GO • Full Stack Developer</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;