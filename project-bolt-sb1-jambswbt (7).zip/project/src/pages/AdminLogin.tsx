import React, { useState, useEffect } from 'react';
import { Shield, Eye, EyeOff, Lock, AlertTriangle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface AdminLoginProps {
  onLoginSuccess: () => void;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ onLoginSuccess }) => {
  const { adminLogin, isAdmin } = useAuth();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [isBlocked, setIsBlocked] = useState(false);

  // Redirecionar se já estiver logado como admin
  useEffect(() => {
    if (isAdmin) {
      onLoginSuccess();
    }
  }, [isAdmin, onLoginSuccess]);

  // Verificar se está bloqueado por tentativas
  useEffect(() => {
    const blockedUntil = localStorage.getItem('admin_blocked_until');
    if (blockedUntil) {
      const blockedTime = parseInt(blockedUntil);
      if (Date.now() < blockedTime) {
        setIsBlocked(true);
        const timeLeft = Math.ceil((blockedTime - Date.now()) / 1000 / 60);
        setError(`Muitas tentativas incorretas. Tente novamente em ${timeLeft} minutos.`);
      } else {
        localStorage.removeItem('admin_blocked_until');
        localStorage.removeItem('admin_attempts');
      }
    }

    const savedAttempts = localStorage.getItem('admin_attempts');
    if (savedAttempts) {
      setAttempts(parseInt(savedAttempts));
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isBlocked) {
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const success = await adminLogin(formData.email, formData.password);
      
      if (success) {
        // Reset attempts on successful login
        localStorage.removeItem('admin_attempts');
        localStorage.removeItem('admin_blocked_until');
        setAttempts(0);
        onLoginSuccess();
      } else {
        const newAttempts = attempts + 1;
        setAttempts(newAttempts);
        localStorage.setItem('admin_attempts', newAttempts.toString());
        
        if (newAttempts >= 5) {
          // Block for 15 minutes after 5 failed attempts
          const blockUntil = Date.now() + (15 * 60 * 1000);
          localStorage.setItem('admin_blocked_until', blockUntil.toString());
          setIsBlocked(true);
          setError('Muitas tentativas incorretas. Acesso bloqueado por 15 minutos.');
        } else {
          setError(`Credenciais inválidas. Tentativa ${newAttempts} de 5.`);
        }
      }
    } catch (error) {
      setError('Erro interno. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    setError(''); // Clear error when user types
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="mx-auto h-16 w-16 bg-yellow-400 rounded-full flex items-center justify-center mb-6">
            <Shield className="h-8 w-8 text-black" />
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">
            Área Administrativa
          </h2>
          <p className="text-gray-400">
            Acesso restrito para administradores
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-xl p-8">
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center space-x-3">
              <AlertTriangle className="h-5 w-5 text-red-500 flex-shrink-0" />
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          )}

          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                E-mail Administrativo
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={formData.email}
                onChange={handleChange}
                disabled={isBlocked || isLoading}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed"
                placeholder="admin@comfydance.com"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                Senha
              </label>
              <div className="relative">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={formData.password}
                  onChange={handleChange}
                  disabled={isBlocked || isLoading}
                  className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed"
                  placeholder="Sua senha administrativa"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  disabled={isBlocked || isLoading}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center disabled:cursor-not-allowed"
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5 text-gray-400" />
                  ) : (
                    <Eye className="h-5 w-5 text-gray-400" />
                  )}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isBlocked || isLoading}
              className="w-full bg-black text-white py-3 px-4 rounded-lg hover:bg-gray-800 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Verificando...</span>
                </>
              ) : (
                <>
                  <Lock className="h-5 w-5" />
                  <span>Acessar Painel</span>
                </>
              )}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="text-center">
              <p className="text-xs text-gray-500 mb-2">
                Área protegida com autenticação de dois fatores
              </p>
              <div className="flex items-center justify-center space-x-2 text-xs text-gray-400">
                <Shield className="h-3 w-3" />
                <span>Conexão segura SSL</span>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center">
          <p className="text-gray-400 text-sm">
            Problemas de acesso? Entre em contato com o suporte técnico
          </p>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;