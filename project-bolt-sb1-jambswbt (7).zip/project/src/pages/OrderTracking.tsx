import React, { useState, useEffect } from 'react';
import { Package, Truck, MapPin, Clock, Check, AlertCircle, Search } from 'lucide-react';
import { Order, OrderTracking } from '../types';

interface OrderTrackingProps {
  onNavigate: (page: string) => void;
}

const OrderTrackingPage: React.FC<OrderTrackingProps> = ({ onNavigate }) => {
  const [orderNumber, setOrderNumber] = useState('');
  const [order, setOrder] = useState<Order | null>(null);
  const [tracking, setTracking] = useState<OrderTracking[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Mock tracking data
  const mockTracking: OrderTracking[] = [
    {
      id: '1',
      orderId: 'CD001',
      status: 'Pedido confirmado',
      description: 'Seu pedido foi confirmado e está sendo preparado',
      location: 'Brasília, DF',
      timestamp: new Date('2024-01-15T10:30:00')
    },
    {
      id: '2',
      orderId: 'CD001',
      status: 'Em preparação',
      description: 'Produto sendo separado e embalado',
      location: 'Centro de Distribuição - Brasília, DF',
      timestamp: new Date('2024-01-15T14:20:00')
    },
    {
      id: '3',
      orderId: 'CD001',
      status: 'Enviado',
      description: 'Produto despachado para entrega',
      location: 'Correios - Brasília, DF',
      timestamp: new Date('2024-01-16T09:15:00')
    },
    {
      id: '4',
      orderId: 'CD001',
      status: 'Em trânsito',
      description: 'Produto em rota de entrega',
      location: 'Centro de Distribuição - São Paulo, SP',
      timestamp: new Date('2024-01-17T16:45:00')
    },
    {
      id: '5',
      orderId: 'CD001',
      status: 'Saiu para entrega',
      description: 'Produto saiu para entrega na sua região',
      location: 'Agência Local - São Paulo, SP',
      timestamp: new Date('2024-01-18T08:30:00')
    }
  ];

  const mockOrder: Order = {
    id: 'order-1',
    orderNumber: 'CD001',
    items: [
      {
        product: {
          id: '1',
          name: 'Sapato de Salto Alto Clássico',
          description: 'Elegante sapato de salto alto',
          price: 299.90,
          images: ['https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=800'],
          category: 'saltos',
          sizes: ['37'],
          colors: ['Preto'],
          inStock: true,
          rating: 4.8,
          reviews: 124
        },
        size: '37',
        color: 'Preto',
        quantity: 1
      }
    ],
    total: 299.90,
    status: 'shipped',
    paymentStatus: 'paid',
    createdAt: new Date('2024-01-15T10:30:00'),
    shippingAddress: {
      id: '1',
      street: 'Rua das Flores',
      number: '123',
      neighborhood: 'Centro',
      city: 'São Paulo',
      state: 'SP',
      zipCode: '01234-567',
      isDefault: true
    },
    paymentMethod: 'pix',
    customerName: 'Ana Silva',
    customerEmail: 'ana@email.com',
    trackingCode: 'BR123456789CD'
  };

  const handleSearch = async () => {
    if (!orderNumber.trim()) {
      setError('Digite o número do pedido');
      return;
    }

    setLoading(true);
    setError('');

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));

      if (orderNumber.toUpperCase() === 'CD001') {
        setOrder(mockOrder);
        setTracking(mockTracking);
      } else {
        setError('Pedido não encontrado. Verifique o número digitado.');
        setOrder(null);
        setTracking([]);
      }
    } catch (error) {
      setError('Erro ao buscar pedido. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    const lowerStatus = status.toLowerCase();
    
    if (lowerStatus.includes('confirmado')) return <Check className="w-5 h-5 text-green-600" />;
    if (lowerStatus.includes('preparação')) return <Package className="w-5 h-5 text-blue-600" />;
    if (lowerStatus.includes('enviado') || lowerStatus.includes('trânsito')) return <Truck className="w-5 h-5 text-purple-600" />;
    if (lowerStatus.includes('entrega')) return <MapPin className="w-5 h-5 text-orange-600" />;
    
    return <Clock className="w-5 h-5 text-gray-600" />;
  };

  const getStatusColor = (status: string) => {
    const lowerStatus = status.toLowerCase();
    
    if (lowerStatus.includes('confirmado')) return 'border-green-200 bg-green-50';
    if (lowerStatus.includes('preparação')) return 'border-blue-200 bg-blue-50';
    if (lowerStatus.includes('enviado') || lowerStatus.includes('trânsito')) return 'border-purple-200 bg-purple-50';
    if (lowerStatus.includes('entrega')) return 'border-orange-200 bg-orange-50';
    
    return 'border-gray-200 bg-gray-50';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Rastrear Pedido
          </h1>
          <p className="text-gray-600">
            Digite o número do seu pedido para acompanhar o status da entrega
          </p>
        </div>

        {/* Search Form */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Número do Pedido
              </label>
              <input
                type="text"
                value={orderNumber}
                onChange={(e) => setOrderNumber(e.target.value.toUpperCase())}
                placeholder="Ex: CD001"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
            </div>
            <div className="sm:pt-7">
              <button
                onClick={handleSearch}
                disabled={loading}
                className="w-full sm:w-auto bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    <span>Buscando...</span>
                  </>
                ) : (
                  <>
                    <Search className="w-5 h-5" />
                    <span>Rastrear</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Demo Notice */}
          <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-blue-700 text-sm">
              <strong>Demonstração:</strong> Use o número "CD001" para ver um exemplo de rastreamento.
            </p>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-8">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
              <p className="text-red-700">{error}</p>
            </div>
          </div>
        )}

        {/* Order Information */}
        {order && (
          <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
            <div className="p-6 border-b">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                Informações do Pedido
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-medium text-gray-900 mb-2">Detalhes do Pedido</h3>
                  <div className="space-y-1 text-sm text-gray-600">
                    <p><strong>Número:</strong> {order.orderNumber}</p>
                    <p><strong>Data:</strong> {order.createdAt.toLocaleDateString('pt-BR')}</p>
                    <p><strong>Total:</strong> R$ {order.total.toFixed(2)}</p>
                    <p><strong>Pagamento:</strong> {order.paymentMethod.toUpperCase()}</p>
                    {order.trackingCode && (
                      <p><strong>Código de Rastreio:</strong> {order.trackingCode}</p>
                    )}
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-900 mb-2">Endereço de Entrega</h3>
                  <div className="text-sm text-gray-600">
                    <p>{order.customerName}</p>
                    <p>{order.shippingAddress.street}, {order.shippingAddress.number}</p>
                    <p>{order.shippingAddress.neighborhood}</p>
                    <p>{order.shippingAddress.city} - {order.shippingAddress.state}</p>
                    <p>CEP: {order.shippingAddress.zipCode}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Order Items */}
            <div className="p-6">
              <h3 className="font-medium text-gray-900 mb-4">Itens do Pedido</h3>
              <div className="space-y-4">
                {order.items.map((item, index) => (
                  <div key={index} className="flex items-center space-x-4">
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{item.product.name}</h4>
                      <p className="text-sm text-gray-600">
                        Tamanho: {item.size} • Cor: {item.color} • Qtd: {item.quantity}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">R$ {(item.product.price * item.quantity).toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tracking Timeline */}
        {tracking.length > 0 && (
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6 border-b">
              <h2 className="text-xl font-semibold text-gray-900">
                Histórico de Rastreamento
              </h2>
            </div>
            
            <div className="p-6">
              <div className="space-y-6">
                {tracking.map((event, index) => (
                  <div key={event.id} className="relative">
                    {/* Timeline Line */}
                    {index < tracking.length - 1 && (
                      <div className="absolute left-6 top-12 w-0.5 h-16 bg-gray-200"></div>
                    )}
                    
                    <div className="flex items-start space-x-4">
                      {/* Status Icon */}
                      <div className={`flex-shrink-0 w-12 h-12 rounded-full border-2 flex items-center justify-center ${getStatusColor(event.status)}`}>
                        {getStatusIcon(event.status)}
                      </div>
                      
                      {/* Event Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h3 className="font-medium text-gray-900">{event.status}</h3>
                          <span className="text-sm text-gray-500">
                            {event.timestamp.toLocaleDateString('pt-BR')} às {event.timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-gray-600 text-sm mb-1">{event.description}</p>
                        {event.location && (
                          <p className="text-gray-500 text-xs flex items-center">
                            <MapPin className="w-3 h-3 mr-1" />
                            {event.location}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Help Section */}
        <div className="mt-8 bg-gray-100 rounded-lg p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Precisa de Ajuda?</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Dúvidas sobre seu pedido?</h4>
              <p className="text-sm text-gray-600 mb-3">
                Entre em contato conosco pelo WhatsApp ou e-mail
              </p>
              <button
                onClick={() => onNavigate('contact')}
                className="text-blue-600 hover:text-blue-700 text-sm font-medium"
              >
                Falar com Atendimento →
              </button>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Política de Entrega</h4>
              <p className="text-sm text-gray-600 mb-3">
                Saiba mais sobre prazos, frete grátis e nossa política de entrega
              </p>
              <button
                onClick={() => onNavigate('about')}
                className="text-blue-600 hover:text-blue-700 text-sm font-medium"
              >
                Ver Política →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderTrackingPage;