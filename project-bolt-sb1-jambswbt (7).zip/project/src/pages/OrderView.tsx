import React, { useState, useEffect } from 'react';
import { ArrowLeft, Package, MapPin, CreditCard, Calendar, Check, Clock, Truck, AlertCircle, Copy, ExternalLink } from 'lucide-react';
import { Order, OrderTracking } from '../types';
import { isDemoMode } from '../lib/supabase';

interface OrderViewProps {
  orderId?: string;
  onBack: () => void;
  onNavigate: (page: string) => void;
}

const OrderView: React.FC<OrderViewProps> = ({ orderId, onBack, onNavigate }) => {
  const [order, setOrder] = useState<Order | null>(null);
  const [tracking, setTracking] = useState<OrderTracking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  // Mock order data for demonstration
  const mockOrder: Order = {
    id: orderId || 'demo-order-1',
    orderNumber: 'CD001',
    items: [
      {
        product: {
          id: '1',
          name: 'Sapato de Salto Alto Clássico',
          description: 'Elegante sapato de salto alto em couro premium',
          price: 299.90,
          images: ['https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=800'],
          category: 'saltos',
          sizes: ['37'],
          colors: ['Preto'],
          inStock: true,
          rating: 4.8,
          reviews: 124
        },
        size: '37',
        color: 'Preto',
        quantity: 1
      }
    ],
    total: 314.90,
    status: 'shipped',
    paymentStatus: 'paid',
    createdAt: new Date('2024-01-15T10:30:00'),
    shippingAddress: {
      id: '1',
      street: 'Rua das Flores',
      number: '123',
      complement: 'Apto 45',
      neighborhood: 'Centro',
      city: 'São Paulo',
      state: 'SP',
      zipCode: '01234-567',
      isDefault: true
    },
    paymentMethod: 'pix',
    customerName: 'Ana Silva',
    customerEmail: 'ana@email.com',
    trackingCode: 'BR123456789CD'
  };

  const mockTracking: OrderTracking[] = [
    {
      id: '1',
      orderId: 'CD001',
      status: 'Pedido confirmado',
      description: 'Seu pedido foi confirmado e está sendo preparado',
      location: 'Brasília, DF',
      timestamp: new Date('2024-01-15T10:30:00')
    },
    {
      id: '2',
      orderId: 'CD001',
      status: 'Em preparação',
      description: 'Produto sendo separado e embalado',
      location: 'Centro de Distribuição - Brasília, DF',
      timestamp: new Date('2024-01-15T14:20:00')
    },
    {
      id: '3',
      orderId: 'CD001',
      status: 'Enviado',
      description: 'Produto despachado para entrega',
      location: 'Correios - Brasília, DF',
      timestamp: new Date('2024-01-16T09:15:00')
    },
    {
      id: '4',
      orderId: 'CD001',
      status: 'Em trânsito',
      description: 'Produto em rota de entrega',
      location: 'Centro de Distribuição - São Paulo, SP',
      timestamp: new Date('2024-01-17T16:45:00')
    }
  ];

  useEffect(() => {
    loadOrder();
  }, [orderId]);

  const loadOrder = async () => {
    setLoading(true);
    setError('');

    try {
      // Simulate loading
      await new Promise(resolve => setTimeout(resolve, 1000));

      if (isDemoMode || !orderId) {
        // Demo mode or no orderId - use mock data
        setOrder(mockOrder);
        setTracking(mockTracking);
      } else {
        // In production, load from database
        // const { data, error } = await supabase.from('user_orders').select('*').eq('id', orderId).single();
        // For now, use mock data
        setOrder(mockOrder);
        setTracking(mockTracking);
      }
    } catch (error) {
      console.error('Error loading order:', error);
      setError('Erro ao carregar pedido. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'pending':
      case 'pendente':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'processing':
      case 'processando':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'shipped':
      case 'enviado':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'delivered':
      case 'entregue':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'cancelled':
      case 'cancelado':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'paid':
      case 'pago':
        return 'bg-green-100 text-green-800';
      case 'pending':
      case 'pendente':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
      case 'cancelado':
        return 'bg-red-100 text-red-800';
      case 'expired':
      case 'expirado':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const copyOrderLink = async () => {
    const orderLink = `${window.location.origin}/pedido/${order?.orderNumber}`;
    try {
      await navigator.clipboard.writeText(orderLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Error copying link:', error);
    }
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando pedido...</p>
        </div>
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-4">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900 mb-4">Pedido não encontrado</h2>
          <p className="text-gray-600 mb-6">
            {error || 'Não foi possível encontrar este pedido. Verifique o número e tente novamente.'}
          </p>
          <div className="space-y-3">
            <button
              onClick={() => onNavigate('order-tracking')}
              className="w-full bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors"
            >
              Rastrear Outro Pedido
            </button>
            <button
              onClick={onBack}
              className="w-full border border-gray-300 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Voltar
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 sm:mb-8">
          <div className="flex items-center">
            <button
              onClick={onBack}
              className="flex items-center text-gray-600 hover:text-gray-900 transition-colors mr-4 sm:mr-6"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              <span className="hidden sm:inline">Voltar</span>
            </button>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">
                Pedido {order.orderNumber}
              </h1>
              <p className="text-gray-600 text-sm sm:text-base">
                Realizado em {formatDate(order.createdAt)}
              </p>
            </div>
          </div>

          {/* Share Order Link */}
          <button
            onClick={copyOrderLink}
            className="flex items-center space-x-2 px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-sm"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-green-600" />
                <span className="text-green-600">Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span className="hidden sm:inline">Copiar Link</span>
              </>
            )}
          </button>
        </div>

        {/* Demo Notice */}
        {isDemoMode && (
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-blue-600 mr-2" />
              <p className="text-blue-700 text-sm">
                <strong>Modo Demonstração:</strong> Este é um pedido fictício para fins de demonstração.
              </p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
          {/* Order Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Order Status */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900">Status do Pedido</h2>
                <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(order.status)}`}>
                  {order.status === 'pending' ? 'Pendente' :
                   order.status === 'processing' ? 'Processando' :
                   order.status === 'shipped' ? 'Enviado' :
                   order.status === 'delivered' ? 'Entregue' :
                   order.status === 'cancelled' ? 'Cancelado' : order.status}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <h3 className="font-medium text-gray-900 mb-2">Pagamento</h3>
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPaymentStatusColor(order.paymentStatus)}`}>
                      {order.paymentStatus === 'paid' ? 'Pago' :
                       order.paymentStatus === 'pending' ? 'Pendente' :
                       order.paymentStatus === 'cancelled' ? 'Cancelado' :
                       order.paymentStatus === 'expired' ? 'Expirado' : order.paymentStatus}
                    </span>
                    <span className="text-sm text-gray-600">
                      via {order.paymentMethod.toUpperCase()}
                    </span>
                  </div>
                </div>

                {order.trackingCode && (
                  <div>
                    <h3 className="font-medium text-gray-900 mb-2">Código de Rastreio</h3>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-mono text-gray-700">{order.trackingCode}</span>
                      <button
                        onClick={() => onNavigate('order-tracking')}
                        className="text-blue-600 hover:text-blue-700 text-sm"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Order Items */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Itens do Pedido</h2>
              
              <div className="space-y-4">
                {order.items.map((item, index) => (
                  <div key={index} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg">
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      className="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-lg flex-shrink-0"
                    />
                    
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-gray-900 mb-1 line-clamp-2">
                        {item.product.name}
                      </h3>
                      <div className="text-sm text-gray-600 space-y-1">
                        <p>Tamanho: {item.size}</p>
                        <p>Cor: {item.color}</p>
                        <p>Quantidade: {item.quantity}</p>
                      </div>
                    </div>
                    
                    <div className="text-right flex-shrink-0">
                      <p className="font-semibold text-gray-900">
                        R$ {(item.product.price * item.quantity).toFixed(2)}
                      </p>
                      <p className="text-sm text-gray-600">
                        R$ {item.product.price.toFixed(2)} cada
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Tracking Timeline */}
            {tracking.length > 0 && (
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Rastreamento</h2>
                
                <div className="space-y-4">
                  {tracking.map((event, index) => (
                    <div key={event.id} className="relative">
                      {/* Timeline Line */}
                      {index < tracking.length - 1 && (
                        <div className="absolute left-6 top-12 w-0.5 h-12 bg-gray-200"></div>
                      )}
                      
                      <div className="flex items-start space-x-4">
                        {/* Status Icon */}
                        <div className="flex-shrink-0 w-12 h-12 rounded-full bg-blue-100 border-2 border-blue-200 flex items-center justify-center">
                          {event.status.toLowerCase().includes('entregue') ? (
                            <Check className="w-5 h-5 text-green-600" />
                          ) : event.status.toLowerCase().includes('enviado') || event.status.toLowerCase().includes('trânsito') ? (
                            <Truck className="w-5 h-5 text-blue-600" />
                          ) : (
                            <Clock className="w-5 h-5 text-gray-600" />
                          )}
                        </div>
                        
                        {/* Event Details */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <h3 className="font-medium text-gray-900">{event.status}</h3>
                            <span className="text-sm text-gray-500">
                              {formatDate(event.timestamp)}
                            </span>
                          </div>
                          <p className="text-gray-600 text-sm mb-1">{event.description}</p>
                          {event.location && (
                            <p className="text-gray-500 text-xs flex items-center">
                              <MapPin className="w-3 h-3 mr-1" />
                              {event.location}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Order Summary */}
            <div className="bg-white p-6 rounded-lg shadow-md sticky top-8">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Resumo do Pedido</h2>
              
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>R$ {(order.total - 15.90).toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Frete:</span>
                  <span>R$ 15,90</span>
                </div>
                <div className="flex justify-between font-semibold text-lg pt-3 border-t">
                  <span>Total:</span>
                  <span>R$ {order.total.toFixed(2)}</span>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t">
                <h3 className="font-medium text-gray-900 mb-3">Informações de Entrega</h3>
                <div className="text-sm text-gray-600 space-y-1">
                  <p className="font-medium">{order.customerName}</p>
                  <p>{order.shippingAddress.street}, {order.shippingAddress.number}</p>
                  {order.shippingAddress.complement && (
                    <p>{order.shippingAddress.complement}</p>
                  )}
                  <p>{order.shippingAddress.neighborhood}</p>
                  <p>{order.shippingAddress.city} - {order.shippingAddress.state}</p>
                  <p>CEP: {order.shippingAddress.zipCode}</p>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t">
                <h3 className="font-medium text-gray-900 mb-3">Contato</h3>
                <div className="text-sm text-gray-600">
                  <p>{order.customerEmail}</p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-medium text-gray-900 mb-4">Ações</h3>
              
              <div className="space-y-3">
                <button
                  onClick={() => onNavigate('order-tracking')}
                  className="w-full flex items-center justify-center space-x-2 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <Package className="w-4 h-4" />
                  <span>Rastrear Pedido</span>
                </button>
                
                <button
                  onClick={() => onNavigate('contact')}
                  className="w-full flex items-center justify-center space-x-2 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <AlertCircle className="w-4 h-4" />
                  <span>Precisa de Ajuda?</span>
                </button>
                
                <button
                  onClick={() => onNavigate('shop')}
                  className="w-full bg-black text-white px-4 py-3 rounded-lg hover:bg-gray-800 transition-colors"
                >
                  Continuar Comprando
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderView;