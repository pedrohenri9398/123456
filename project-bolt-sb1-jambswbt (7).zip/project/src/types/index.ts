export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  images: string[];
  category: 'saltos' | 'sapatilhas' | 'masculinos';
  sizes: string[];
  colors: string[];
  colorImages?: { [color: string]: string[] }; // NEW: Images for each color
  inStock: boolean;
  featured?: boolean;
  rating: number;
  reviews: number;
  slug?: string; // For individual product URLs
}

export interface CartItem {
  product: Product;
  size: string;
  color: string;
  quantity: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  addresses: Address[];
  orders: Order[];
  role?: 'customer' | 'admin';
}

export interface Address {
  id: string;
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
  state: string;
  zipCode: string;
  isDefault: boolean;
}

export interface Order {
  id: string;
  orderNumber: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  paymentStatus: 'pending' | 'paid' | 'cancelled' | 'expired';
  createdAt: Date;
  shippingAddress: Address;
  paymentMethod: string;
  customerName: string;
  customerEmail: string;
  trackingCode?: string;
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  productId: string;
  rating: number;
  comment: string;
  images?: string[];
  createdAt: Date;
  verified: boolean; // Only users who bought and received the product can review
}

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  role: 'admin';
  permissions: string[];
}

// Institutional Pages
export interface InstitutionalPage {
  id: string;
  slug: string;
  title: string;
  content: string;
  lastUpdated: Date;
}

// Order Tracking
export interface OrderTracking {
  id: string;
  orderId: string;
  status: string;
  description: string;
  location?: string;
  timestamp: Date;
}

// Security Features
export interface SecurityFeature {
  id: string;
  name: string;
  icon: string;
  description: string;
  enabled: boolean;
}