export interface PaymentProvider {
  id: string;
  name: string;
  type: 'mercadopago';
  enabled: boolean;
  config: {
    clientId?: string;
    clientSecret?: string;
    accessToken?: string;
    publicKey?: string;
    environment: 'sandbox' | 'production';
    qrCodeUrl?: string;
  };
}

export interface PaymentMethod {
  id: string;
  type: 'pix' | 'boleto' | 'credit_card';
  name: string;
  enabled: boolean;
  discount?: number; // Percentage discount (e.g., 5 for 5%)
  installments?: number; // Max installments for credit card
}

export interface PaymentTransaction {
  id: string;
  orderId: string;
  paymentId?: string; // ID from payment provider
  method: 'pix' | 'boleto' | 'credit_card';
  amount: number;
  status: 'pending' | 'paid' | 'cancelled' | 'expired';
  pixCode?: string;
  pixQrCode?: string;
  boletoUrl?: string;
  boletoBarcode?: string;
  creditCardData?: {
    installments: number;
    brand: string;
    lastFourDigits: string;
  };
  expiresAt?: Date;
  paidAt?: Date;
  createdAt: Date;
  updatedAt: Date;
  providerData?: any; // Raw data from payment provider
}

export interface PaymentConfig {
  providers: PaymentProvider[];
  methods: PaymentMethod[];
  settings: {
    pixExpirationMinutes: number;
    boletoExpirationDays: number;
    maxInstallments: number;
    webhookUrl?: string;
  };
}

export interface PaymentResponse {
  success: boolean;
  transactionId?: string;
  paymentId?: string;
  pixCode?: string;
  pixQrCode?: string;
  boletoUrl?: string;
  boletoBarcode?: string;
  creditCardData?: {
    installments: number;
    authorizationCode: string;
  };
  expiresAt?: Date;
  error?: string;
}

export interface CreditCardData {
  number: string;
  holderName: string;
  expiryMonth: string;
  expiryYear: string;
  cvv: string;
  installments: number;
}

import axios from 'axios';

export async function createPixPayment(amount: number, description: string) {
  const accessToken = import.meta.env.MERCADO_PAGO_ACCESS_TOKEN;

  if (!accessToken) {
    throw new Error('Token do Mercado Pago não encontrado no .env');
  }

  const body = {
    transaction_amount: amount,
    description,
    payment_method_id: "pix",
    payer: {
      email: "comprador@email.com" // pode trocar se quiser
    }
  };

  const response = await axios.post(
    'https://api.mercadopago.com/v1/payments',
    body,
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    }
  );

  const payment = response.data;

  return {
    qrCodeBase64: payment.point_of_interaction.transaction_data.qr_code_base64,
    qrCode: payment.point_of_interaction.transaction_data.qr_code
  };
}
  