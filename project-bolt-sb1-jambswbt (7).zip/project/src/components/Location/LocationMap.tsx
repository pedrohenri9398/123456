import React, { useEffect, useRef } from 'react';
import { MapPin, ExternalLink } from 'lucide-react';

interface LocationMapProps {
  coordinates: { lat: number; lng: number };
  address?: string;
  zoom?: number;
  height?: string;
  showOpenInMaps?: boolean;
}

const LocationMap: React.FC<LocationMapProps> = ({
  coordinates,
  address,
  zoom = 15,
  height = '300px',
  showOpenInMaps = true
}) => {
  const mapRef = useRef<HTMLDivElement>(null);

  // URL para OpenStreetMap
  const osmUrl = `https://www.openstreetmap.org/export/embed.html?bbox=${coordinates.lng - 0.01},${coordinates.lat - 0.01},${coordinates.lng + 0.01},${coordinates.lat + 0.01}&layer=mapnik&marker=${coordinates.lat},${coordinates.lng}`;

  // URLs para abrir em apps de mapas
  const openInGoogleMaps = () => {
    const url = `https://www.google.com/maps?q=${coordinates.lat},${coordinates.lng}`;
    window.open(url, '_blank');
  };

  const openInAppleMaps = () => {
    const url = `https://maps.apple.com/?q=${coordinates.lat},${coordinates.lng}`;
    window.open(url, '_blank');
  };

  const openInWaze = () => {
    const url = `https://waze.com/ul?ll=${coordinates.lat},${coordinates.lng}&navigate=yes`;
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-4">
      {/* Map Container */}
      <div className="relative rounded-lg overflow-hidden border border-gray-300 shadow-md">
        <iframe
          ref={mapRef}
          src={osmUrl}
          width="100%"
          height={height}
          style={{ border: 0 }}
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="Mapa da localização"
        />
        
        {/* Map Overlay with Address */}
        {address && (
          <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-75 text-white p-3">
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-yellow-400 flex-shrink-0" />
              <span className="text-sm">{address}</span>
            </div>
          </div>
        )}
      </div>

      {/* Open in Maps Buttons */}
      {showOpenInMaps && (
        <div className="flex flex-wrap gap-2">
          <button
            onClick={openInGoogleMaps}
            className="flex items-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
          >
            <ExternalLink className="w-4 h-4" />
            <span>Google Maps</span>
          </button>
          
          <button
            onClick={openInAppleMaps}
            className="flex items-center space-x-2 px-3 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-900 transition-colors text-sm"
          >
            <ExternalLink className="w-4 h-4" />
            <span>Apple Maps</span>
          </button>
          
          <button
            onClick={openInWaze}
            className="flex items-center space-x-2 px-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm"
          >
            <ExternalLink className="w-4 h-4" />
            <span>Waze</span>
          </button>
        </div>
      )}

      {/* Coordinates Info */}
      <div className="text-xs text-gray-500 text-center">
        📍 {coordinates.lat.toFixed(6)}, {coordinates.lng.toFixed(6)}
      </div>
    </div>
  );
};

export default LocationMap;