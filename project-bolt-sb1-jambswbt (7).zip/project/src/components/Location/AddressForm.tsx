import React, { useState, useEffect } from 'react';
import { MapPin, Search, Loader, CheckCircle, AlertCircle, Navigation } from 'lucide-react';
import { locationService, Address } from '../../lib/location';

interface AddressFormProps {
  onAddressChange: (address: Address & { coordinates?: { lat: number; lng: number } }) => void;
  initialAddress?: Partial<Address>;
  showShipping?: boolean;
}

const AddressForm: React.FC<AddressFormProps> = ({ 
  onAddressChange, 
  initialAddress = {},
  showShipping = false 
}) => {
  const [address, setAddress] = useState<Partial<Address>>(initialAddress);
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState('');
  const [searchSuccess, setSearchSuccess] = useState(false);
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const [coordinates, setCoordinates] = useState<{ lat: number; lng: number } | null>(null);
  const [shippingInfo, setShippingInfo] = useState<{ cost: number; days: number } | null>(null);

  // Coordenadas de Brasília (nossa loja)
  const BRASILIA_COORDS = { lat: -15.7942, lng: -47.8822 };

  useEffect(() => {
    if (coordinates && showShipping) {
      calculateShipping();
    }
  }, [coordinates, showShipping]);

  const calculateShipping = () => {
    if (!coordinates) return;

    const distance = locationService.calculateDistance(
      BRASILIA_COORDS.lat,
      BRASILIA_COORDS.lng,
      coordinates.lat,
      coordinates.lng
    );

    const shipping = locationService.calculateShipping(distance);
    setShippingInfo({ cost: shipping.cost, days: shipping.estimatedDays });
  };

  const handleCEPSearch = async () => {
    if (!address.cep || !locationService.isValidCEP(address.cep)) {
      setSearchError('CEP inválido. Digite um CEP com 8 dígitos.');
      return;
    }

    setIsSearching(true);
    setSearchError('');
    setSearchSuccess(false);

    try {
      const result = await locationService.searchByCEP(address.cep);
      
      if (result) {
        const newAddress = { ...address, ...result };
        setAddress(newAddress);
        setSearchSuccess(true);

        // Buscar coordenadas
        const fullAddress = `${result.logradouro}, ${result.bairro}, ${result.localidade}, ${result.uf}, Brasil`;
        const coords = await locationService.getCoordinates(fullAddress);
        
        if (coords) {
          setCoordinates(coords);
          onAddressChange({ ...newAddress, coordinates: coords });
        } else {
          onAddressChange(newAddress);
        }

        setTimeout(() => setSearchSuccess(false), 3000);
      } else {
        setSearchError('CEP não encontrado. Verifique o número digitado.');
      }
    } catch (error) {
      setSearchError('Erro ao buscar CEP. Tente novamente.');
    } finally {
      setIsSearching(false);
    }
  };

  const handleGetCurrentLocation = async () => {
    setIsGettingLocation(true);
    setSearchError('');

    try {
      const coords = await locationService.getCurrentLocation();
      
      if (coords) {
        setCoordinates(coords);
        
        // Buscar endereço pelas coordenadas
        const addressFromCoords = await locationService.reverseGeocode(coords.lat, coords.lng);
        
        if (addressFromCoords) {
          setAddress(addressFromCoords);
          onAddressChange({ ...addressFromCoords, coordinates: coords });
          setSearchSuccess(true);
          setTimeout(() => setSearchSuccess(false), 3000);
        } else {
          setSearchError('Não foi possível obter o endereço da sua localização.');
        }
      } else {
        setSearchError('Não foi possível obter sua localização. Verifique as permissões do navegador.');
      }
    } catch (error) {
      setSearchError('Erro ao obter localização. Tente novamente.');
    } finally {
      setIsGettingLocation(false);
    }
  };

  const handleInputChange = (field: keyof Address, value: string) => {
    const newAddress = { ...address, [field]: value };
    setAddress(newAddress);
    
    // Se tem coordenadas, manter elas
    if (coordinates) {
      onAddressChange({ ...newAddress, coordinates });
    } else {
      onAddressChange(newAddress);
    }
  };

  const handleCEPChange = (value: string) => {
    const formatted = locationService.formatCEP(value);
    handleInputChange('cep', formatted);
    setSearchError('');
    setSearchSuccess(false);
  };

  return (
    <div className="space-y-4">
      {/* CEP Search */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          CEP *
        </label>
        <div className="flex space-x-2">
          <input
            type="text"
            value={address.cep || ''}
            onChange={(e) => handleCEPChange(e.target.value)}
            placeholder="00000-000"
            maxLength={9}
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
          />
          <button
            type="button"
            onClick={handleCEPSearch}
            disabled={isSearching || !address.cep}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
          >
            {isSearching ? (
              <Loader className="w-4 h-4 animate-spin" />
            ) : (
              <Search className="w-4 h-4" />
            )}
            <span className="hidden sm:inline">Buscar</span>
          </button>
        </div>

        {/* Get Current Location Button */}
        <button
          type="button"
          onClick={handleGetCurrentLocation}
          disabled={isGettingLocation}
          className="mt-2 w-full sm:w-auto flex items-center justify-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isGettingLocation ? (
            <Loader className="w-4 h-4 animate-spin" />
          ) : (
            <Navigation className="w-4 h-4" />
          )}
          <span>Usar Minha Localização</span>
        </button>

        {/* Status Messages */}
        {searchError && (
          <div className="mt-2 flex items-center space-x-2 text-red-600 text-sm">
            <AlertCircle className="w-4 h-4" />
            <span>{searchError}</span>
          </div>
        )}

        {searchSuccess && (
          <div className="mt-2 flex items-center space-x-2 text-green-600 text-sm">
            <CheckCircle className="w-4 h-4" />
            <span>Endereço encontrado com sucesso!</span>
          </div>
        )}
      </div>

      {/* Address Fields */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Logradouro *
          </label>
          <input
            type="text"
            value={address.logradouro || ''}
            onChange={(e) => handleInputChange('logradouro', e.target.value)}
            placeholder="Rua, Avenida, etc."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Bairro *
          </label>
          <input
            type="text"
            value={address.bairro || ''}
            onChange={(e) => handleInputChange('bairro', e.target.value)}
            placeholder="Nome do bairro"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Cidade *
          </label>
          <input
            type="text"
            value={address.localidade || ''}
            onChange={(e) => handleInputChange('localidade', e.target.value)}
            placeholder="Nome da cidade"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Estado *
          </label>
          <input
            type="text"
            value={address.uf || ''}
            onChange={(e) => handleInputChange('uf', e.target.value.toUpperCase())}
            placeholder="UF"
            maxLength={2}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Complemento
          </label>
          <input
            type="text"
            value={address.complemento || ''}
            onChange={(e) => handleInputChange('complemento', e.target.value)}
            placeholder="Apto, casa, etc."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
          />
        </div>
      </div>

      {/* Shipping Information */}
      {showShipping && shippingInfo && coordinates && (
        <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <MapPin className="w-5 h-5 text-blue-600" />
            <h4 className="font-medium text-blue-800">Informações de Entrega</h4>
          </div>
          <div className="text-sm text-blue-700 space-y-1">
            <p>
              <strong>Distância de Brasília:</strong> {' '}
              {Math.round(locationService.calculateDistance(
                BRASILIA_COORDS.lat,
                BRASILIA_COORDS.lng,
                coordinates.lat,
                coordinates.lng
              ))} km
            </p>
            <p>
              <strong>Custo do frete:</strong> R$ {shippingInfo.cost.toFixed(2)}
            </p>
            <p>
              <strong>Prazo estimado:</strong> {shippingInfo.days} dias úteis
            </p>
          </div>
        </div>
      )}

      {/* Location Coordinates (for debugging) */}
      {coordinates && (
        <div className="mt-2 text-xs text-gray-500">
          📍 Localização: {coordinates.lat.toFixed(6)}, {coordinates.lng.toFixed(6)}
        </div>
      )}
    </div>
  );
};

export default AddressForm;