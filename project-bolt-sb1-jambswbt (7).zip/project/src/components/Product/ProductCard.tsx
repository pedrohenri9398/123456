import React from 'react';
import { Heart, Star, ShoppingBag } from 'lucide-react';
import { Product } from '../../types';

interface ProductCardProps {
  product: Product;
  onClick: () => void;
  onQuickAdd?: () => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onClick, onQuickAdd }) => {
  return (
    <div className="group bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
      <div className="relative overflow-hidden">
        <img
          src={product.images[0]}
          alt={product.name}
          className="w-full h-48 sm:h-56 md:h-64 object-cover group-hover:scale-105 transition-transform duration-300 cursor-pointer"
          onClick={onClick}
        />
        
        {/* Badge de desconto */}
        {product.originalPrice && (
          <div className="absolute top-2 sm:top-3 left-2 sm:left-3 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
            -{Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}%
          </div>
        )}
        
        {/* Botões de ação */}
        <div className="absolute top-2 sm:top-3 right-2 sm:right-3 space-y-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-50 transition-colors">
            <Heart className="w-4 h-4 text-gray-600" />
          </button>
        </div>
        
        {/* Quick Add Button */}
        {onQuickAdd && (
          <div className="absolute bottom-2 sm:bottom-3 left-2 sm:left-3 right-2 sm:right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button
              onClick={onQuickAdd}
              className="w-full bg-black text-white py-2 rounded-lg hover:bg-gray-800 transition-colors text-sm font-medium flex items-center justify-center space-x-2"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Adicionar</span>
            </button>
          </div>
        )}
      </div>
      
      <div className="p-3 sm:p-4 space-y-2 sm:space-y-3">
        <div className="space-y-1 sm:space-y-2">
          <h3 
            className="font-semibold text-gray-900 leading-tight cursor-pointer hover:text-yellow-600 transition-colors text-sm sm:text-base line-clamp-2"
            onClick={onClick}
          >
            {product.name}
          </h3>
          
          <div className="flex items-center space-x-1">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-3 h-3 ${
                    i < Math.floor(product.rating)
                      ? 'text-yellow-400 fill-current'
                      : 'text-gray-300'
                  }`}
                />
              ))}
            </div>
            <span className="text-xs text-gray-500">({product.reviews})</span>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="text-base sm:text-lg font-bold text-gray-900">
                R$ {product.price.toFixed(2)}
              </span>
              {product.originalPrice && (
                <span className="text-sm text-gray-500 line-through">
                  R$ {product.originalPrice.toFixed(2)}
                </span>
              )}
            </div>
            
            {!product.inStock && (
              <span className="text-xs text-red-500 font-medium">Esgotado</span>
            )}
          </div>
          
          <div className="text-xs text-gray-500">
            {product.sizes.length} tamanhos
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;