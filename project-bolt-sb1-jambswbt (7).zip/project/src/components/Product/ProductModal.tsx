import React, { useState, useEffect } from 'react';
import { X, Star, ShoppingBag, Heart, ChevronLeft, ChevronRight, AlertCircle } from 'lucide-react';
import { useProducts } from '../../contexts/ProductContext';
import { useCart } from '../../contexts/CartContext';

interface ProductModalProps {
  product: string | null;
  isOpen: boolean;
  onClose: () => void;
}

const ProductModal: React.FC<ProductModalProps> = ({ product: productId, isOpen, onClose }) => {
  const { getProduct } = useProducts();
  const product = productId ? getProduct(productId) : null;
  
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const { addItem } = useCart();

  // Prevent body scroll when modal is open and handle scroll restoration
  useEffect(() => {
    if (isOpen) {
      // Save current scroll position
      const scrollY = window.scrollY;
      
      // Prevent body scroll
      document.body.style.position = 'fixed';
      document.body.style.top = `-${scrollY}px`;
      document.body.style.width = '100%';
      document.body.style.overflow = 'hidden';
      
      return () => {
        // Restore body scroll
        document.body.style.position = '';
        document.body.style.top = '';
        document.body.style.width = '';
        document.body.style.overflow = '';
        
        // Restore scroll position
        window.scrollTo(0, scrollY);
      };
    }
  }, [isOpen]);

  // Reset selections when product changes
  useEffect(() => {
    if (product) {
      setSelectedSize('');
      setSelectedColor('');
      setQuantity(1);
      setCurrentImageIndex(0);
    }
  }, [product]);

  if (!isOpen || !product) return null;

  const handleAddToCart = () => {
    if (!selectedSize || !selectedColor) {
      // Scroll to selection area if not visible
      const selectionArea = document.getElementById('product-selections');
      if (selectionArea) {
        selectionArea.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }
    
    addItem(product, selectedSize, selectedColor, quantity);
    
    // Show success feedback
    const successMessage = document.createElement('div');
    successMessage.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-[70] flex items-center space-x-2';
    successMessage.innerHTML = `
      <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
        <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
      </svg>
      <span>Produto adicionado ao carrinho!</span>
    `;
    
    document.body.appendChild(successMessage);
    
    // Remove message after 3 seconds
    setTimeout(() => {
      if (document.body.contains(successMessage)) {
        document.body.removeChild(successMessage);
      }
    }, 3000);
    
    onClose();
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => 
      prev === product.images.length - 1 ? 0 : prev + 1
    );
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => 
      prev === 0 ? product.images.length - 1 : prev - 1
    );
  };

  const canAddToCart = product.inStock && selectedSize && selectedColor;

  return (
    <div className="fixed inset-0 z-50">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 transition-opacity" 
        onClick={onClose} 
      />
      
      {/* Modal Container - CRITICAL: Proper scroll configuration */}
      <div className="fixed inset-0 flex items-start justify-center p-0 sm:p-4 sm:items-center">
        <div className="relative bg-white w-full h-full sm:h-auto sm:max-h-[95vh] sm:rounded-2xl sm:max-w-6xl shadow-2xl flex flex-col sm:overflow-hidden">
          {/* Close Button - Fixed position */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-30 p-2 bg-white rounded-full shadow-lg hover:bg-gray-50 transition-colors"
            style={{ position: 'fixed', zIndex: 30 }}
          >
            <X className="w-5 h-5" />
          </button>

          {/* Modal Content - CRITICAL: Flex layout with proper overflow */}
          <div className="flex flex-col lg:flex-row h-full min-h-0 overflow-hidden">
            
            {/* Image Gallery - Fixed height on mobile, flexible on desktop */}
            <div className="relative bg-gray-50 flex-shrink-0 lg:flex-1">
              <div className="h-64 sm:h-80 lg:h-full relative overflow-hidden">
                <img
                  src={product.images[currentImageIndex]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                
                {product.images.length > 1 && (
                  <>
                    <button
                      onClick={prevImage}
                      className="absolute left-2 sm:left-4 top-1/2 transform -translate-y-1/2 p-2 bg-white rounded-full shadow-lg hover:bg-gray-50 transition-colors z-20"
                    >
                      <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                    <button
                      onClick={nextImage}
                      className="absolute right-2 sm:right-4 top-1/2 transform -translate-y-1/2 p-2 bg-white rounded-full shadow-lg hover:bg-gray-50 transition-colors z-20"
                    >
                      <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                  </>
                )}
              </div>
              
              {/* Image indicators */}
              {product.images.length > 1 && (
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2 z-20">
                  {product.images.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`w-2 h-2 rounded-full transition-colors ${
                        index === currentImageIndex ? 'bg-white' : 'bg-white bg-opacity-50'
                      }`}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Product Info Container - CRITICAL: Proper flex and overflow setup */}
            <div className="flex flex-col flex-1 lg:flex-1 min-h-0 max-h-full">
              
              {/* Product Header - Fixed at top */}
              <div className="flex-shrink-0 p-4 sm:p-6 border-b border-gray-200 bg-white">
                <h1 className="text-xl sm:text-2xl font-bold text-gray-900 leading-tight mb-3 pr-12">
                  {product.name}
                </h1>
                
                <div className="flex items-center space-x-2 mb-4">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < Math.floor(product.rating)
                            ? 'text-yellow-400 fill-current'
                            : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-500">({product.reviews} avaliações)</span>
                </div>

                <div className="flex items-center space-x-3">
                  <span className="text-2xl sm:text-3xl font-bold text-gray-900">
                    R$ {product.price.toFixed(2)}
                  </span>
                  {product.originalPrice && (
                    <span className="text-lg sm:text-xl text-gray-500 line-through">
                      R$ {product.originalPrice.toFixed(2)}
                    </span>
                  )}
                </div>
              </div>

              {/* CRITICAL: Scrollable Content Area with proper overflow settings */}
              <div 
                className="flex-1 overflow-y-auto overscroll-contain"
                style={{
                  maxHeight: 'calc(100vh - 300px)', // Ensure it doesn't exceed viewport
                  minHeight: '200px', // Minimum height for content
                  WebkitOverflowScrolling: 'touch' // Smooth scrolling on iOS
                }}
              >
                <div className="p-4 sm:p-6 space-y-6" id="product-selections">
                  
                  {/* Description */}
                  <div>
                    <p className="text-gray-600 leading-relaxed text-sm sm:text-base">
                      {product.description}
                    </p>
                  </div>

                  {/* Size Selection */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold text-gray-900">Tamanho</h3>
                      {!selectedSize && (
                        <span className="text-xs text-red-500 flex items-center">
                          <AlertCircle className="w-3 h-3 mr-1" />
                          Obrigatório
                        </span>
                      )}
                    </div>
                    <div className="grid grid-cols-4 sm:grid-cols-5 lg:grid-cols-6 gap-2">
                      {product.sizes.map((size) => (
                        <button
                          key={size}
                          onClick={() => setSelectedSize(size)}
                          className={`py-3 px-2 sm:px-3 border rounded-lg text-sm font-medium transition-all duration-200 ${
                            selectedSize === size
                              ? 'border-black bg-black text-white shadow-md'
                              : 'border-gray-300 hover:border-gray-400 hover:shadow-sm'
                          }`}
                        >
                          {size}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Color Selection */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold text-gray-900">Cor</h3>
                      {!selectedColor && (
                        <span className="text-xs text-red-500 flex items-center">
                          <AlertCircle className="w-3 h-3 mr-1" />
                          Obrigatório
                        </span>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {product.colors.map((color) => (
                        <button
                          key={color}
                          onClick={() => setSelectedColor(color)}
                          className={`py-3 px-3 sm:px-4 border rounded-lg text-sm font-medium transition-all duration-200 ${
                            selectedColor === color
                              ? 'border-black bg-black text-white shadow-md'
                              : 'border-gray-300 hover:border-gray-400 hover:shadow-sm'
                          }`}
                        >
                          {color}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Quantity */}
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-3">Quantidade</h3>
                    <div className="flex items-center space-x-3">
                      <button
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="p-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        -
                      </button>
                      <span className="text-lg font-medium min-w-[3rem] text-center">{quantity}</span>
                      <button
                        onClick={() => setQuantity(quantity + 1)}
                        className="p-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  {/* Stock Status */}
                  {!product.inStock && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                      <p className="text-red-700 font-medium">Produto esgotado</p>
                      <p className="text-red-600 text-sm">Entre em contato para saber sobre reposição</p>
                    </div>
                  )}

                  {/* Selection Status */}
                  {(!selectedSize || !selectedColor) && product.inStock && (
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                      <div className="flex items-center">
                        <AlertCircle className="w-5 h-5 text-amber-600 mr-2" />
                        <div>
                          <p className="text-amber-800 font-medium text-sm">
                            Seleções obrigatórias
                          </p>
                          <p className="text-amber-700 text-xs">
                            {!selectedSize && !selectedColor && 'Selecione tamanho e cor para continuar'}
                            {selectedSize && !selectedColor && 'Selecione uma cor'}
                            {!selectedSize && selectedColor && 'Selecione um tamanho'}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Extra spacing for better scroll experience */}
                  <div className="h-16 sm:h-8"></div>
                </div>
              </div>

              {/* Fixed Footer with Actions - ALWAYS VISIBLE AND ACCESSIBLE */}
              <div className="flex-shrink-0 p-4 sm:p-6 border-t border-gray-200 bg-white shadow-lg">
                <div className="space-y-3">
                  
                  {/* Quick Selection Summary */}
                  <div className="text-center">
                    <div className="flex items-center justify-center space-x-4 text-xs text-gray-600 mb-3">
                      <span className={selectedSize ? 'text-green-600 font-medium' : ''}>
                        Tamanho: {selectedSize || 'Não selecionado'}
                      </span>
                      <span className="text-gray-300">•</span>
                      <span className={selectedColor ? 'text-green-600 font-medium' : ''}>
                        Cor: {selectedColor || 'Não selecionada'}
                      </span>
                      <span className="text-gray-300">•</span>
                      <span className="text-gray-600">
                        Qtd: {quantity}
                      </span>
                    </div>
                  </div>

                  {/* Main Add to Cart Button - ALWAYS PRESENT AND FUNCTIONAL */}
                  <button
                    onClick={handleAddToCart}
                    disabled={!product.inStock}
                    className={`w-full py-4 rounded-lg font-semibold flex items-center justify-center space-x-2 transition-all duration-200 text-base ${
                      !product.inStock
                        ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                        : canAddToCart
                        ? 'bg-black text-white hover:bg-gray-800 shadow-lg hover:shadow-xl'
                        : 'bg-amber-500 text-white hover:bg-amber-600 shadow-lg hover:shadow-xl'
                    }`}
                  >
                    <ShoppingBag className="w-5 h-5" />
                    <span>
                      {!product.inStock 
                        ? 'Produto Esgotado' 
                        : canAddToCart
                        ? 'Adicionar ao Carrinho'
                        : 'Selecione Tamanho e Cor'
                      }
                    </span>
                  </button>
                  
                  {/* Favorites Button */}
                  <button className="w-full border-2 border-gray-300 text-gray-700 py-3 rounded-lg hover:bg-gray-50 hover:border-gray-400 transition-all duration-200 font-medium flex items-center justify-center space-x-2">
                    <Heart className="w-5 h-5" />
                    <span>Adicionar aos Favoritos</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductModal;