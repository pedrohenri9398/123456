import React, { useState } from 'react';
import { CreditCard, Lock, Calendar, User, Shield } from 'lucide-react';
import { CreditCardData } from '../../types/payment';

interface CreditCardFormProps {
  onSubmit: (cardData: CreditCardData) => void;
  totalAmount: number;
  isProcessing: boolean;
}

const CreditCardForm: React.FC<CreditCardFormProps> = ({
  onSubmit,
  totalAmount,
  isProcessing
}) => {
  const [cardData, setCardData] = useState<CreditCardData>({
    number: '',
    holderName: '',
    expiryMonth: '',
    expiryYear: '',
    cvv: '',
    installments: 1
  });

  const [errors, setErrors] = useState<Partial<CreditCardData>>({});

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const getCardBrand = (number: string) => {
    const cleanNumber = number.replace(/\s/g, '');
    
    if (/^4/.test(cleanNumber)) return 'visa';
    if (/^5[1-5]/.test(cleanNumber)) return 'mastercard';
    if (/^3[47]/.test(cleanNumber)) return 'amex';
    if (/^6/.test(cleanNumber)) return 'discover';
    if (/^35(2[89]|[3-8][0-9])/.test(cleanNumber)) return 'jcb';
    
    return 'unknown';
  };

  const validateCard = () => {
    const newErrors: Partial<CreditCardData> = {};

    if (!cardData.number || cardData.number.replace(/\s/g, '').length < 13) {
      newErrors.number = 'Número do cartão inválido';
    }

    if (!cardData.holderName || cardData.holderName.length < 3) {
      newErrors.holderName = 'Nome do titular é obrigatório';
    }

    if (!cardData.expiryMonth || !cardData.expiryYear) {
      newErrors.expiryMonth = 'Data de validade é obrigatória';
    }

    if (!cardData.cvv || cardData.cvv.length < 3) {
      newErrors.cvv = 'CVV inválido';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateCard()) {
      onSubmit(cardData);
    }
  };

  const handleInputChange = (field: keyof CreditCardData, value: string) => {
    setCardData(prev => ({ ...prev, [field]: value }));
    
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const calculateInstallmentValue = (installments: number) => {
    return totalAmount / installments;
  };

  const generateInstallmentOptions = () => {
    const options = [];
    for (let i = 1; i <= 10; i++) {
      const value = calculateInstallmentValue(i);
      const interest = i > 1 ? ' (com juros)' : ' (sem juros)';
      options.push({
        value: i,
        label: `${i}x de R$ ${value.toFixed(2)}${interest}`
      });
    }
    return options;
  };

  const cardBrand = getCardBrand(cardData.number);

  return (
    <div className="max-w-md mx-auto">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex items-center space-x-2 mb-6">
          <CreditCard className="w-6 h-6 text-blue-600" />
          <h3 className="text-lg font-semibold text-gray-900">Cartão de Crédito</h3>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Card Number */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Número do Cartão
            </label>
            <div className="relative">
              <input
                type="text"
                value={cardData.number}
                onChange={(e) => handleInputChange('number', formatCardNumber(e.target.value))}
                placeholder="1234 5678 9012 3456"
                maxLength={19}
                className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 ${
                  errors.number ? 'border-red-500' : 'border-gray-300'
                }`}
              />
              {cardBrand !== 'unknown' && (
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <span className="text-xs font-medium text-gray-500 uppercase">
                    {cardBrand}
                  </span>
                </div>
              )}
            </div>
            {errors.number && (
              <p className="text-red-500 text-sm mt-1">{errors.number}</p>
            )}
          </div>

          {/* Cardholder Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nome do Titular
            </label>
            <div className="relative">
              <input
                type="text"
                value={cardData.holderName}
                onChange={(e) => handleInputChange('holderName', e.target.value.toUpperCase())}
                placeholder="NOME COMO NO CARTÃO"
                className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 ${
                  errors.holderName ? 'border-red-500' : 'border-gray-300'
                }`}
              />
              <User className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            </div>
            {errors.holderName && (
              <p className="text-red-500 text-sm mt-1">{errors.holderName}</p>
            )}
          </div>

          {/* Expiry and CVV */}
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mês
              </label>
              <select
                value={cardData.expiryMonth}
                onChange={(e) => handleInputChange('expiryMonth', e.target.value)}
                className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 ${
                  errors.expiryMonth ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                <option value="">Mês</option>
                {Array.from({ length: 12 }, (_, i) => i + 1).map(month => (
                  <option key={month} value={month.toString().padStart(2, '0')}>
                    {month.toString().padStart(2, '0')}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ano
              </label>
              <select
                value={cardData.expiryYear}
                onChange={(e) => handleInputChange('expiryYear', e.target.value)}
                className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 ${
                  errors.expiryYear ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                <option value="">Ano</option>
                {Array.from({ length: 10 }, (_, i) => new Date().getFullYear() + i).map(year => (
                  <option key={year} value={year.toString()}>
                    {year}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                CVV
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={cardData.cvv}
                  onChange={(e) => handleInputChange('cvv', e.target.value.replace(/\D/g, ''))}
                  placeholder="123"
                  maxLength={4}
                  className={`w-full px-3 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 ${
                    errors.cvv ? 'border-red-500' : 'border-gray-300'
                  }`}
                />
                <Lock className="absolute right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              </div>
            </div>
          </div>

          {errors.expiryMonth && (
            <p className="text-red-500 text-sm">{errors.expiryMonth}</p>
          )}
          {errors.cvv && (
            <p className="text-red-500 text-sm">{errors.cvv}</p>
          )}

          {/* Installments */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Parcelamento
            </label>
            <select
              value={cardData.installments}
              onChange={(e) => handleInputChange('installments', e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
            >
              {generateInstallmentOptions().map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          {/* Security Notice */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-3">
            <div className="flex items-center space-x-2">
              <Shield className="w-4 h-4 text-green-600" />
              <div>
                <p className="text-green-800 text-sm font-medium">Pagamento Seguro</p>
                <p className="text-green-700 text-xs">
                  Seus dados são protegidos com criptografia SSL
                </p>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isProcessing}
            className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
          >
            {isProcessing ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                <span>Processando...</span>
              </>
            ) : (
              <>
                <CreditCard className="w-5 h-5" />
                <span>Finalizar Pagamento</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default CreditCardForm;