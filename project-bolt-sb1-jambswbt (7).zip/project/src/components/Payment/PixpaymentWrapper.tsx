import React, { useEffect, useState } from 'react';
import PixPayment from './PixPayment';
import { createPixPayment } from '../../lib/payment';

interface Product {
  name: string;
  price: number;
}

interface PixWrapperProps {
  product: Product;
}

const PixPaymentWrapper: React.FC<PixWrapperProps> = ({ product }) => {
  const [pixCode, setPixCode] = useState('');
  const [pixQrCode, setPixQrCode] = useState('');
  const [expiresAt, setExpiresAt] = useState<Date | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const gerarPagamento = async () => {
      try {
        const response = await createPixPayment(product.price, product.name);

        setPixCode(response.qrCode);
        setPixQrCode(response.qrCodeBase64);

        // Válido por 15 minutos
        const validade = new Date();
        validade.setMinutes(validade.getMinutes() + 15);
        setExpiresAt(validade);
      } catch (err) {
        console.error('Erro ao gerar pagamento Pix:', err);
      } finally {
        setLoading(false);
      }
    };

    gerarPagamento();
  }, [product]);

  if (loading || !expiresAt) {
    return <p>Gerando pagamento Pix...</p>;
  }

  return (
    <PixPayment
      pixCode={pixCode}
      pixQrCode={pixQrCode}
      amount={product.price}
      expiresAt={expiresAt}
    />
  );
};

export default PixPaymentWrapper;