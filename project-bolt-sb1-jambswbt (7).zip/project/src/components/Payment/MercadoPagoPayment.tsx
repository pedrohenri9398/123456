import React, { useState, useEffect } from 'react';
import { QrCode, Copy, Check, Clock, AlertCircle, RefreshCw, CreditCard } from 'lucide-react';
import { mercadoPagoService, PaymentItem, CustomerData, PaymentResponse } from '../../lib/mercadopago';

interface MercadoPagoPaymentProps {
  items: PaymentItem[];
  customerData: CustomerData;
  orderNumber?: string;
  onPaymentSuccess?: (paymentData: PaymentResponse) => void;
  onPaymentError?: (error: string) => void;
}

const MercadoPagoPayment: React.FC<MercadoPagoPaymentProps> = ({
  items,
  customerData,
  orderNumber,
  onPaymentSuccess,
  onPaymentError
}) => {
  const [paymentData, setPaymentData] = useState<PaymentResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [timeLeft, setTimeLeft] = useState<string>('');
  const [checkingStatus, setCheckingStatus] = useState(false);

  // Calculate total
  const totalAmount = items.reduce((total, item) => total + (item.price * item.quantity), 0);

  // Timer for expiration
  useEffect(() => {
    if (!paymentData?.expires_at) return;

    const updateTimer = () => {
      const now = new Date().getTime();
      const expiry = new Date(paymentData.expires_at!).getTime();
      const difference = expiry - now;

      if (difference > 0) {
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);
        setTimeLeft(`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
      } else {
        setTimeLeft('00:00');
      }
    };

    updateTimer();
    const timer = setInterval(updateTimer, 1000);
    return () => clearInterval(timer);
  }, [paymentData]);

  // Check payment status periodically
  useEffect(() => {
    if (!paymentData?.payment_id) return;

    const checkStatus = async () => {
      try {
        setCheckingStatus(true);
        const status = await mercadoPagoService.checkPaymentStatus(paymentData.payment_id!);
        
        if (status.status === 'approved') {
          onPaymentSuccess?.(paymentData);
        }
      } catch (error) {
        console.error('Error checking status:', error);
      } finally {
        setCheckingStatus(false);
      }
    };

    // Check every 5 seconds
    const statusInterval = setInterval(checkStatus, 5000);
    return () => clearInterval(statusInterval);
  }, [paymentData, onPaymentSuccess]);

  const handleCreatePayment = async () => {
    setLoading(true);
    setError('');

    try {
      // Check if server is running
      const serverHealthy = await mercadoPagoService.checkServerHealth();
      if (!serverHealthy) {
        throw new Error('Payment server unavailable. Please try again in a few moments.');
      }

      const response = await mercadoPagoService.createPayment(items, customerData, orderNumber);
      setPaymentData(response);
    } catch (error: any) {
      const errorMessage = error.message || 'Error processing payment';
      setError(errorMessage);
      onPaymentError?.(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleCopyPixCode = async () => {
    if (!paymentData?.pix?.qr_code) return;

    try {
      await navigator.clipboard.writeText(paymentData.pix.qr_code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Error copying PIX code:', error);
    }
  };

  const handleCheckStatus = async () => {
    if (!paymentData?.payment_id) return;

    try {
      setCheckingStatus(true);
      const status = await mercadoPagoService.checkPaymentStatus(paymentData.payment_id);
      
      if (status.status === 'approved') {
        onPaymentSuccess?.(paymentData);
      } else {
        alert(`Current status: ${status.status}`);
      }
    } catch (error: any) {
      alert('Error checking status: ' + error.message);
    } finally {
      setCheckingStatus(false);
    }
  };

  if (!paymentData) {
    return (
      <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg p-6">
        <div className="text-center mb-6">
          <CreditCard className="w-12 h-12 mx-auto mb-4 text-blue-600" />
          <h2 className="text-xl font-bold text-gray-900 mb-2">
            Complete Payment
          </h2>
          <p className="text-gray-600">
            Total: <span className="text-2xl font-bold text-green-600">
              R$ {totalAmount.toFixed(2)}
            </span>
          </p>
        </div>

        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          </div>
        )}

        <div className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold text-gray-900 mb-2">Order Summary</h3>
            {items.map((item, index) => (
              <div key={index} className="flex justify-between text-sm text-gray-600 mb-1">
                <span>{item.name} x{item.quantity}</span>
                <span>R$ {(item.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
            <div className="border-t pt-2 mt-2">
              <div className="flex justify-between font-semibold">
                <span>Total:</span>
                <span>R$ {totalAmount.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleCreatePayment}
            disabled={loading}
            className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-semibold disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                Generating PIX...
              </>
            ) : (
              'Pay with PIX'
            )}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
      {/* Header */}
      <div className="bg-green-600 text-white p-6 text-center">
        <QrCode className="w-12 h-12 mx-auto mb-3" />
        <h2 className="text-xl font-bold mb-2">PIX Payment</h2>
        <p className="text-green-100">
          Amount: <span className="text-2xl font-bold">R$ {paymentData.amount?.toFixed(2)}</span>
        </p>
      </div>

      {/* Timer */}
      <div className="p-4 text-center border-b bg-green-50">
        <div className="flex items-center justify-center space-x-2">
          <Clock className="w-5 h-5 text-green-600" />
          <span className="font-mono text-lg font-bold text-green-600">
            {timeLeft || '30:00'}
          </span>
        </div>
        <p className="text-sm text-green-600 mt-1">
          Time remaining for payment
        </p>
      </div>

      {/* QR Code */}
      <div className="p-6 text-center">
        {paymentData.pix?.qr_code_base64 ? (
          <div className="bg-white p-4 rounded-lg border-2 border-green-200 inline-block mb-4 shadow-md">
            <img
              src={`data:image/png;base64,${paymentData.pix.qr_code_base64}`}
              alt="PIX QR Code"
              className="w-48 h-48 mx-auto"
            />
          </div>
        ) : (
          <div className="bg-gray-100 w-48 h-48 mx-auto rounded-lg flex items-center justify-center mb-4">
            <p className="text-gray-500">QR Code unavailable</p>
          </div>
        )}
        <div className="bg-green-50 p-3 rounded-lg mb-4">
          <p className="text-sm text-green-800 font-medium mb-1">Bank or Digital Wallet</p>
          <p className="text-xs text-green-700">
            Scan the QR code with your bank or wallet app.
          </p>
        </div>
      </div>

      {/* PIX Copy and Paste Code */}
      <div className="px-6 pb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          PIX Code (Copy and Paste)
        </label>
        <div className="flex space-x-2">
          <input
            type="text"
            value={paymentData.pix?.qr_code || ''}
            readOnly
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-sm font-mono"
          />
          <button
            onClick={handleCopyPixCode}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              copied ? 'bg-green-600 text-white' : 'bg-green-500 text-white hover:bg-green-600'
            }`}
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
        {copied && (
          <p className="text-green-600 text-sm mt-2 flex items-center">
            <Check className="w-4 h-4 mr-1" />
            Code copied!
          </p>
        )}
      </div>

      {/* Instructions */}
      <div className="px-6 pb-6">
        <h3 className="font-semibold text-gray-900 mb-3">How to pay:</h3>
        <ol className="space-y-2 text-sm text-gray-600">
          {['Open your bank or digital wallet app',
            'Scan the QR code or paste the PIX code',
            'Confirm the details and amount',
            'Complete the payment'
          ].map((item, i) => (
            <li key={i} className="flex items-start space-x-2">
              <span className="bg-green-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">
                {i + 1}
              </span>
              <span>{item}</span>
            </li>
          ))}
        </ol>
      </div>

      {/* Check Button */}
      <div className="px-6 pb-6">
        <button
          onClick={handleCheckStatus}
          disabled={checkingStatus}
          className="w-full flex items-center justify-center space-x-2 py-3 border border-green-300 rounded-lg hover:bg-green-50 transition-colors disabled:opacity-50"
        >
          {checkingStatus ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Checking...</span>
            </>
          ) : (
            <>
              <RefreshCw className="w-4 h-4" />
              <span>Check Payment Status</span>
            </>
          )}
        </button>
      </div>

      {/* Payment ID */}
      <div className="px-6 pb-6 text-center">
        <p className="text-xs text-gray-500">
          Payment ID: {paymentData.payment_id}
        </p>
      </div>
    </div>
  );
};

export default MercadoPagoPayment;