import React, { useState } from 'react';
import { FileText, Download, Copy, Check, Calendar, AlertCircle, ExternalLink } from 'lucide-react';

interface BoletoPaymentProps {
  boletoUrl: string;
  boletoBarcode: string;
  amount: number;
  expiresAt: Date;
  customerName: string;
}

const BoletoPayment: React.FC<BoletoPaymentProps> = ({
  boletoUrl,
  boletoBarcode,
  amount,
  expiresAt,
  customerName
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopyBarcode = async () => {
    try {
      await navigator.clipboard.writeText(boletoBarcode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Erro ao copiar código de barras:', error);
    }
  };

  const handleDownloadBoleto = () => {
    window.open(boletoUrl, '_blank');
  };

  const formatExpiryDate = (date: Date) => {
    return new Date(date).toLocaleDateString('pt-BR');
  };

  const isExpired = new Date() > new Date(expiresAt);

  return (
    <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
      {/* Header */}
      <div className="bg-blue-600 text-white p-6 text-center">
        <FileText className="w-12 h-12 mx-auto mb-3" />
        <h2 className="text-xl font-bold mb-2">Boleto Bancário</h2>
        <p className="text-blue-100">
          Valor: <span className="text-2xl font-bold">R$ {amount.toFixed(2)}</span>
        </p>
      </div>

      {/* Expiry Info */}
      <div className={`p-4 text-center border-b ${isExpired ? 'bg-red-50' : 'bg-blue-50'}`}>
        <div className="flex items-center justify-center space-x-2">
          <Calendar className={`w-5 h-5 ${isExpired ? 'text-red-600' : 'text-blue-600'}`} />
          <span className={`font-semibold ${isExpired ? 'text-red-600' : 'text-blue-600'}`}>
            Vencimento: {formatExpiryDate(expiresAt)}
          </span>
        </div>
        {isExpired && (
          <p className="text-red-600 text-sm mt-1">
            Boleto vencido - Entre em contato para gerar um novo
          </p>
        )}
      </div>

      {!isExpired ? (
        <>
          {/* Customer Info */}
          <div className="p-6 border-b border-gray-200">
            <h3 className="font-semibold text-gray-900 mb-2">Dados do Pagador</h3>
            <p className="text-gray-600">{customerName}</p>
          </div>

          {/* Download Button */}
          <div className="p-6 border-b border-gray-200">
            <button
              onClick={handleDownloadBoleto}
              className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center justify-center space-x-2"
            >
              <Download className="w-5 h-5" />
              <span>Baixar Boleto PDF</span>
            </button>
            <p className="text-sm text-gray-600 mt-2 text-center">
              Clique para baixar e imprimir o boleto
            </p>
          </div>

          {/* Barcode */}
          <div className="p-6 border-b border-gray-200">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Código de Barras
            </label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={boletoBarcode}
                readOnly
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-sm font-mono"
              />
              <button
                onClick={handleCopyBarcode}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  copied
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-600 text-white hover:bg-gray-700'
                }`}
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
            {copied && (
              <p className="text-green-600 text-sm mt-2 flex items-center">
                <Check className="w-4 h-4 mr-1" />
                Código copiado!
              </p>
            )}
          </div>

          {/* Instructions */}
          <div className="p-6">
            <h3 className="font-semibold text-gray-900 mb-3">Como pagar:</h3>
            <ol className="space-y-2 text-sm text-gray-600">
              <li className="flex items-start space-x-2">
                <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">1</span>
                <span>Baixe e imprima o boleto ou copie o código de barras</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">2</span>
                <span>Pague em qualquer banco, lotérica ou internet banking</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">3</span>
                <span>O pagamento será confirmado em até 3 dias úteis</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">4</span>
                <span>Você receberá um e-mail de confirmação</span>
              </li>
            </ol>
          </div>

          {/* Important Notes */}
          <div className="p-6 bg-amber-50 border-t border-amber-200">
            <div className="flex items-start space-x-2">
              <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-medium text-amber-800 mb-1">Importante:</h4>
                <ul className="text-sm text-amber-700 space-y-1">
                  <li>• Pague até a data de vencimento</li>
                  <li>• Após o vencimento, o boleto perde a validade</li>
                  <li>• Guarde o comprovante de pagamento</li>
                  <li>• Em caso de dúvidas, entre em contato conosco</li>
                </ul>
              </div>
            </div>
          </div>
        </>
      ) : (
        /* Expired State */
        <div className="p-6 text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Boleto Vencido</h3>
          <p className="text-gray-600 mb-4">
            Este boleto venceu em {formatExpiryDate(expiresAt)}. Entre em contato para gerar um novo boleto.
          </p>
          <button className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium">
            Entrar em Contato
          </button>
        </div>
      )}
    </div>
  );
};

export default BoletoPayment;