import React, { useState } from 'react';
import { Smartphone, FileText, CreditCard, Clock, Shield, Check, AlertCircle, Info } from 'lucide-react';
import { isDemoMode } from '../../lib/supabase';

interface PaymentMethod {
  id: string;
  type: 'pix' | 'boleto' | 'credit_card';
  name: string;
  description: string;
  discount?: number;
  icon: React.ComponentType<any>;
  estimatedTime: string;
  enabled: boolean;
  provider?: string;
  installments?: number;
}

interface PaymentMethodsProps {
  selectedMethod: string;
  onMethodSelect: (methodId: string) => void;
  totalAmount: number;
}

const PaymentMethods: React.FC<PaymentMethodsProps> = ({
  selectedMethod,
  onMethodSelect,
  totalAmount
}) => {
  const paymentMethods: PaymentMethod[] = [
    {
      id: 'pix',
      type: 'pix',
      name: 'PIX',
      description: 'Pagamento instantâneo via PIX Itaú',
      discount: 5,
      icon: Smartphone,
      estimatedTime: 'Aprovação instantânea',
      enabled: true,
      provider: 'Itaú'
    },
    {
      id: 'credit_card',
      type: 'credit_card',
      name: 'Cartão de Crédito',
      description: 'Parcelamento em até 10x',
      discount: 0,
      icon: CreditCard,
      estimatedTime: 'Aprovação em minutos',
      enabled: true,
      installments: 10
    },
    {
      id: 'boleto',
      type: 'boleto',
      name: 'Boleto Bancário',
      description: isDemoMode ? 'Pagamento via boleto bancário (Demonstração)' : 'Pagamento via boleto bancário',
      discount: 0,
      icon: FileText,
      estimatedTime: 'Até 3 dias úteis',
      enabled: true
    }
  ];

  const calculateFinalAmount = (method: PaymentMethod) => {
    if (method.discount) {
      return totalAmount * (1 - method.discount / 100);
    }
    return totalAmount;
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">
        Escolha a forma de pagamento
      </h3>

      {/* Payment Provider Notice */}
      <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-6">
        <div className="flex items-start space-x-3">
          <div className="bg-orange-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold flex-shrink-0">
            🏦
          </div>
          <div>
            <h4 className="text-sm font-medium text-orange-800 mb-1">Pagamentos Seguros</h4>
            <p className="text-sm text-orange-700">
              PIX via Banco Itaú configurado. Cartão de crédito e boleto disponíveis.
              Todos os pagamentos são processados com segurança SSL.
            </p>
          </div>
        </div>
      </div>

      {paymentMethods.map((method) => {
        const Icon = method.icon;
        const finalAmount = calculateFinalAmount(method);
        const isSelected = selectedMethod === method.id;
        const savings = totalAmount - finalAmount;

        return (
          <div
            key={method.id}
            className={`relative border-2 rounded-lg p-4 cursor-pointer transition-all duration-200 ${
              isSelected
                ? method.type === 'pix' 
                  ? 'border-orange-500 bg-orange-50'
                  : method.type === 'credit_card'
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-green-500 bg-green-50'
                : method.enabled
                ? 'border-gray-200 hover:border-gray-300 hover:shadow-md'
                : 'border-gray-100 bg-gray-50 cursor-not-allowed opacity-60'
            }`}
            onClick={() => method.enabled && onMethodSelect(method.id)}
          >
            <div className="flex items-start space-x-4">
              {/* Radio Button */}
              <div className="flex-shrink-0 mt-1">
                <div
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                    isSelected
                      ? method.type === 'pix'
                        ? 'border-orange-500 bg-orange-500'
                        : method.type === 'credit_card'
                        ? 'border-blue-500 bg-blue-500'
                        : 'border-green-500 bg-green-500'
                      : 'border-gray-300'
                  }`}
                >
                  {isSelected && <Check className="w-3 h-3 text-white" />}
                </div>
              </div>

              {/* Method Icon */}
              <div
                className={`flex-shrink-0 w-12 h-12 rounded-lg flex items-center justify-center ${
                  method.type === 'pix'
                    ? 'bg-orange-100 text-orange-600'
                    : method.type === 'credit_card'
                    ? 'bg-blue-100 text-blue-600'
                    : method.type === 'boleto'
                    ? 'bg-green-100 text-green-600'
                    : 'bg-gray-100 text-gray-600'
                }`}
              >
                <Icon className="w-6 h-6" />
              </div>

              {/* Method Details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-lg font-semibold text-gray-900 flex items-center">
                    {method.name}
                    {method.provider && (
                      <span className="ml-2 text-xs bg-orange-100 text-orange-800 px-2 py-1 rounded-full">
                        {method.provider}
                      </span>
                    )}
                    {method.installments && (
                      <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                        até {method.installments}x
                      </span>
                    )}
                  </h4>
                  <div className="text-right">
                    <div className="text-lg font-bold text-gray-900">
                      R$ {finalAmount.toFixed(2)}
                    </div>
                    {savings > 0 && (
                      <div className="text-sm text-green-600 font-medium">
                        Economia: R$ {savings.toFixed(2)}
                      </div>
                    )}
                  </div>
                </div>

                <p className="text-gray-600 text-sm mb-3">
                  {method.description}
                </p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{method.estimatedTime}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Shield className="w-4 h-4" />
                      <span>Seguro</span>
                    </div>
                  </div>

                  {method.discount && (
                    <div className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                      {method.discount}% OFF
                    </div>
                  )}
                </div>

                {/* Special Features */}
                {method.type === 'pix' && (
                  <div className="mt-3 p-3 bg-orange-50 rounded-lg border border-orange-200">
                    <div className="flex items-center space-x-2 text-orange-700 text-sm">
                      <Check className="w-4 h-4" />
                      <span>QR Code Itaú configurado</span>
                    </div>
                    <div className="flex items-center space-x-2 text-orange-700 text-sm mt-1">
                      <Check className="w-4 h-4" />
                      <span>Pagamento via qualquer banco</span>
                    </div>
                    <div className="flex items-center space-x-2 text-orange-700 text-sm mt-1">
                      <Check className="w-4 h-4" />
                      <span>Confirmação instantânea</span>
                    </div>
                  </div>
                )}

                {method.type === 'credit_card' && (
                  <div className="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <div className="flex items-center space-x-2 text-blue-700 text-sm">
                      <Check className="w-4 h-4" />
                      <span>Parcelamento em até 10x</span>
                    </div>
                    <div className="flex items-center space-x-2 text-blue-700 text-sm mt-1">
                      <Check className="w-4 h-4" />
                      <span>Visa, Mastercard, Elo</span>
                    </div>
                    <div className="flex items-center space-x-2 text-blue-700 text-sm mt-1">
                      <Check className="w-4 h-4" />
                      <span>Aprovação em minutos</span>
                    </div>
                  </div>
                )}

                {method.type === 'boleto' && (
                  <div className="mt-3 p-3 bg-green-50 rounded-lg border border-green-200">
                    <div className="flex items-center space-x-2 text-green-700 text-sm">
                      <Check className="w-4 h-4" />
                      <span>Boleto gerado automaticamente</span>
                    </div>
                    <div className="flex items-center space-x-2 text-green-700 text-sm mt-1">
                      <AlertCircle className="w-4 h-4" />
                      <span>Vencimento em 3 dias úteis</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Selected Indicator */}
            {isSelected && (
              <div className="absolute top-2 right-2">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                  method.type === 'pix' ? 'bg-orange-500' : 
                  method.type === 'credit_card' ? 'bg-blue-500' : 'bg-green-500'
                }`}>
                  <Check className="w-4 h-4 text-white" />
                </div>
              </div>
            )}
          </div>
        );
      })}

      {/* Security Notice */}
      <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
        <div className="flex items-center space-x-2 text-gray-700">
          <Shield className="w-5 h-5 text-green-600" />
          <div>
            <p className="font-medium text-sm">Pagamento 100% Seguro</p>
            <p className="text-xs text-gray-600 mt-1">
              PIX via Itaú com QR Code oficial. Cartão protegido com criptografia SSL. 
              Seus dados nunca são armazenados em nossos servidores.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentMethods;