import React, { useState, useEffect } from 'react';
import { Copy, Check, Clock, RefreshCw, Smartphone, AlertCircle } from 'lucide-react';

interface PixPaymentProps {
  pixCode: string;
  pixQrCode: string;
  amount: number;
  expiresAt: Date;
  onPaymentConfirmed?: () => void;
}

const PixPayment: React.FC<PixPaymentProps> = ({
  pixCode,
  pixQrCode,
  amount,
  expiresAt,
  onPaymentConfirmed
}) => {
  const [copied, setCopied] = useState(false);
  const [timeLeft, setTimeLeft] = useState('');
  const [isExpired, setIsExpired] = useState(false);

  // Atualiza o contador regressivo
  useEffect(() => {
    const updateTimer = () => {
      const now = new Date().getTime();
      const expiry = new Date(expiresAt).getTime();
      const difference = expiry - now;

      if (difference > 0) {
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);
        setTimeLeft(`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
        setIsExpired(false);
      } else {
        setTimeLeft('00:00');
        setIsExpired(true);
      }
    };

    updateTimer();
    const timer = setInterval(updateTimer, 1000);
    return () => clearInterval(timer);
  }, [expiresAt]);

  const handleCopyPixCode = async () => {
    try {
      await navigator.clipboard.writeText(pixCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Erro ao copiar o código PIX:', error);
    }
  };

  const handleRefreshPayment = () => {
    window.location.reload();
  };

  // Verifica se é base64
  const isBase64 = pixQrCode?.length > 100 && !pixQrCode.startsWith('/') && !pixQrCode.startsWith('http');

  return (
    <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
      {/* Cabeçalho */}
      <div className="bg-gradient-to-r from-green-500 to-green-600 text-white p-6 text-center">
        <div className="flex items-center justify-center mb-3">
          <Smartphone className="w-8 h-8 mr-2" />
          <span className="text-lg font-semibold">Pagamento via PIX</span>
        </div>
        <p className="text-green-100">
          Valor: <span className="text-2xl font-bold">R$ {amount.toFixed(2)}</span>
        </p>
      </div>

      {/* Contador */}
      <div className={`p-4 text-center border-b ${isExpired ? 'bg-red-50' : 'bg-green-50'}`}>
        <div className="flex items-center justify-center space-x-2">
          <Clock className={`w-5 h-5 ${isExpired ? 'text-red-600' : 'text-green-600'}`} />
          <span className={`font-mono text-lg font-bold ${isExpired ? 'text-red-600' : 'text-green-600'}`}>
            {timeLeft}
          </span>
        </div>
        <p className={`text-sm mt-1 ${isExpired ? 'text-red-600' : 'text-green-600'}`}>
          {isExpired ? 'PIX expirado' : 'Tempo restante para pagamento'}
        </p>
      </div>

      {!isExpired ? (
        <>
          {/* QR Code */}
          <div className="p-6 text-center">
            {pixQrCode ? (
              <div className="bg-white p-4 rounded-lg border-2 border-green-200 inline-block mb-4 shadow-md">
                <img
                  src={isBase64 ? `data:image/png;base64,${pixQrCode}` : pixQrCode}
                  alt="QR Code PIX"
                  className="w-48 h-48 mx-auto"
                  style={{ imageRendering: 'pixelated' }}
                />
              </div>
            ) : (
              <p className="text-red-600">QR Code indisponível</p>
            )}
            <div className="bg-green-50 p-3 rounded-lg mb-4">
              <p className="text-sm text-green-800 font-medium mb-1">Banco ou Carteira Digital</p>
              <p className="text-xs text-green-700">
                Escaneie o QR Code com o aplicativo do seu banco ou carteira.
              </p>
            </div>
          </div>

          {/* Código PIX Copia e Cola */}
          <div className="px-6 pb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Código PIX (Copia e Cola)
            </label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={pixCode}
                readOnly
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-sm font-mono"
              />
              <button
                onClick={handleCopyPixCode}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  copied ? 'bg-green-600 text-white' : 'bg-green-500 text-white hover:bg-green-600'
                }`}
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
            {copied && (
              <p className="text-green-600 text-sm mt-2 flex items-center">
                <Check className="w-4 h-4 mr-1" />
                Código copiado!
              </p>
            )}
          </div>

          {/* Instruções */}
          <div className="px-6 pb-6">
            <h3 className="font-semibold text-gray-900 mb-3">Como pagar:</h3>
            <ol className="space-y-2 text-sm text-gray-600">
              {['Abra o app do seu banco ou carteira digital',
                'Escaneie o QR Code ou cole o código PIX',
                'Confirme os dados e o valor',
                'Finalize o pagamento'
              ].map((item, i) => (
                <li key={i} className="flex items-start space-x-2">
                  <span className="bg-green-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">
                    {i + 1}
                  </span>
                  <span>{item}</span>
                </li>
              ))}
            </ol>
          </div>

          {/* Botão de Verificar */}
          <div className="px-6 pb-6">
            <button
              onClick={handleRefreshPayment}
              className="w-full flex items-center justify-center space-x-2 py-3 border border-green-300 rounded-lg hover:bg-green-50 transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Verificar Pagamento</span>
            </button>
          </div>
        </>
      ) : (
        <div className="p-6 text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">PIX Expirado</h3>
          <p className="text-gray-600 mb-4">
            O tempo para pagamento expirou. Gere um novo PIX para continuar.
          </p>
          <button
            onClick={handleRefreshPayment}
            className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors font-medium"
          >
            Gerar Novo PIX
          </button>
        </div>
      )}
    </div>
  );
};

export default PixPayment;