import React from 'react';
import { Facebook, Instagram, Mail, Phone, MapPin, Heart, Code, Shield, CreditCard, Truck, RotateCcw } from 'lucide-react';

interface FooterProps {
  onNavigate?: (page: string) => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const handleInstitutionalPage = (page: string) => {
    if (onNavigate) {
      onNavigate(`institutional-${page}`);
    }
  };

  return (
    <footer className="bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-yellow-400">Comfydance</h3>
            <p className="text-gray-300 text-sm leading-relaxed">
              Conforto e estilo nos seus passos. Especialistas em calçados para dança com qualidade premium e design elegante.
            </p>
            <div className="flex space-x-4">
              <a href="https://instagram.com/comfydance" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-yellow-400 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="https://facebook.com/comfydance" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-yellow-400 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Links Institucionais */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-yellow-400">Institucional</h4>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => handleInstitutionalPage('about-us')}
                  className="text-gray-300 hover:text-yellow-400 transition-colors text-sm text-left"
                >
                  Quem Somos
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleInstitutionalPage('contact-info')}
                  className="text-gray-300 hover:text-yellow-400 transition-colors text-sm text-left"
                >
                  Contato
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleInstitutionalPage('privacy')}
                  className="text-gray-300 hover:text-yellow-400 transition-colors text-sm text-left"
                >
                  Política de Privacidade
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleInstitutionalPage('returns')}
                  className="text-gray-300 hover:text-yellow-400 transition-colors text-sm text-left"
                >
                  Trocas e Devoluções
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleInstitutionalPage('terms')}
                  className="text-gray-300 hover:text-yellow-400 transition-colors text-sm text-left"
                >
                  Termos de Uso
                </button>
              </li>
            </ul>
          </div>

          {/* Categorias */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-yellow-400">Categorias</h4>
            <ul className="space-y-2">
              <li><button onClick={() => onNavigate?.('shop')} className="text-gray-300 hover:text-yellow-400 transition-colors text-sm text-left">Saltos Femininos</button></li>
              <li><button onClick={() => onNavigate?.('shop')} className="text-gray-300 hover:text-yellow-400 transition-colors text-sm text-left">Sapatilhas</button></li>
              <li><button onClick={() => onNavigate?.('shop')} className="text-gray-300 hover:text-yellow-400 transition-colors text-sm text-left">Sapatos Masculinos</button></li>
              <li><button onClick={() => onNavigate?.('shop')} className="text-gray-300 hover:text-yellow-400 transition-colors text-sm text-left">Lançamentos</button></li>
              <li><button onClick={() => onNavigate?.('shop')} className="text-gray-300 hover:text-yellow-400 transition-colors text-sm text-left">Promoções</button></li>
            </ul>
          </div>

          {/* Contato e Newsletter */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-yellow-400">Contato</h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-yellow-400" />
                <span className="text-gray-300 text-sm">(61) 99611-1535</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-yellow-400" />
                <span className="text-gray-300 text-sm">sapatos.comfydance@gmail.com</span>
              </div>
              <div className="flex items-start space-x-2">
                <MapPin className="w-4 h-4 text-yellow-400 mt-0.5" />
                <div className="text-gray-300 text-sm">
                  <div>Loja: Brasília, DF</div>
                  <div className="text-xs text-gray-400 mt-1">Desenvolvido em Luziânia, GO</div>
                </div>
              </div>
            </div>

            {/* Newsletter */}
            <div className="pt-4">
              <h5 className="text-sm font-semibold text-yellow-400 mb-2">Newsletter</h5>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Seu e-mail"
                  className="flex-1 bg-gray-800 text-white placeholder-gray-400 rounded-l-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-yellow-400"
                />
                <button className="bg-yellow-400 text-black px-4 py-2 rounded-r-lg hover:bg-yellow-500 transition-colors">
                  <Mail className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Security and Payment Features */}
        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {/* Security Features */}
            <div className="text-center">
              <Shield className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <h5 className="text-sm font-semibold text-white mb-1">Compra Segura</h5>
              <p className="text-xs text-gray-400">SSL • Dados Protegidos</p>
            </div>

            {/* Payment Methods */}
            <div className="text-center">
              <CreditCard className="w-8 h-8 text-blue-400 mx-auto mb-2" />
              <h5 className="text-sm font-semibold text-white mb-1">Formas de Pagamento</h5>
              <p className="text-xs text-gray-400">PIX • Cartão • Boleto</p>
            </div>

            {/* Shipping */}
            <div className="text-center">
              <Truck className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
              <h5 className="text-sm font-semibold text-white mb-1">Entrega</h5>
              <p className="text-xs text-gray-400">Frete Grátis acima de R$ 200</p>
            </div>
          </div>

          {/* Payment Icons */}
          <div className="text-center mb-6">
            <p className="text-sm text-gray-400 mb-3">Formas de pagamento aceitas:</p>
            <div className="flex justify-center items-center space-x-4 text-gray-400">
              <span className="text-xs bg-gray-800 px-3 py-1 rounded">PIX</span>
              <span className="text-xs bg-gray-800 px-3 py-1 rounded">Visa</span>
              <span className="text-xs bg-gray-800 px-3 py-1 rounded">Mastercard</span>
              <span className="text-xs bg-gray-800 px-3 py-1 rounded">Elo</span>
              <span className="text-xs bg-gray-800 px-3 py-1 rounded">Boleto</span>
            </div>
          </div>

          {/* Benefits */}
          <div className="text-center mb-6">
            <div className="flex flex-wrap justify-center items-center gap-6 text-xs text-gray-400">
              <div className="flex items-center space-x-1">
                <Truck className="w-3 h-3" />
                <span>Frete grátis acima de R$ 199</span>
              </div>
              <div className="flex items-center space-x-1">
                <CreditCard className="w-3 h-3" />
                <span>Parcele em até 10x sem juros</span>
              </div>
              <div className="flex items-center space-x-1">
                <RotateCcw className="w-3 h-3" />
                <span>30 dias para trocas</span>
              </div>
            </div>
          </div>
        </div>

        {/* Developer Section */}
        <div className="border-t border-gray-800 pt-6">
          <div className="bg-gray-900 rounded-lg p-4 mb-6">
            <div className="flex flex-col sm:flex-row items-center justify-between space-y-3 sm:space-y-0">
              <div className="flex items-center space-x-3">
                <div className="bg-gradient-to-r from-purple-500 to-pink-500 w-10 h-10 rounded-full flex items-center justify-center">
                  <Code className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="text-white font-semibold text-sm">Desenvolvido por</h4>
                  <p className="text-gray-400 text-xs">Henrique - Luziânia, GO</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <a
                  href="https://instagram.com/henrique_9397"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105"
                >
                  <Instagram className="w-4 h-4" />
                  <span className="text-sm font-medium">@henrique_9397</span>
                </a>
                
                <div className="text-center">
                  <p className="text-xs text-gray-400">💻 Desenvolvedor</p>
                  <p className="text-xs text-yellow-400 font-medium">Full Stack</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-gray-800 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-gray-400 text-sm">
              © 2024 Comfydance. Todos os direitos reservados.
            </p>
            <div className="flex items-center space-x-1 text-gray-400 text-sm">
              <span>Feito com</span>
              <Heart className="w-4 h-4 text-red-500 fill-current" />
              <span>em Luziânia, GO para dançarinos de todo Brasil</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;