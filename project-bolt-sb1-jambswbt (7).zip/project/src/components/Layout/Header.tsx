import React, { useState } from 'react';
import { ShoppingBag, User, Menu, X, Search, Heart, Shield, Edit, Package } from 'lucide-react';
import { useCart } from '../../contexts/CartContext';
import { useAuth } from '../../contexts/AuthContext';
import { useSiteCustomization } from '../../contexts/SiteCustomizationContext';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onCartOpen: () => void;
}

const Header: React.FC<HeaderProps> = ({ currentPage, onNavigate, onCartOpen }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { itemCount } = useCart();
  const { isAuthenticated, user, isAdmin } = useAuth();
  const { colors } = useSiteCustomization();

  const navigation = [
    { name: 'Home', href: 'home' },
    { name: 'Loja', href: 'shop' },
    { name: 'Sobre', href: 'about' },
    { name: 'Contato', href: 'contact' },
  ];

  return (
    <header 
      className="text-white sticky top-0 z-50 shadow-lg"
      style={{ backgroundColor: colors.headerBg }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0 cursor-pointer" onClick={() => onNavigate('home')}>
            <h1 className="text-xl sm:text-2xl font-bold" style={{ color: colors.primary }}>
              Comfydance {isAdmin && <span className="text-sm" style={{ color: colors.accent }}>(ADM)</span>}
            </h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-6 lg:space-x-8">
            {navigation.map((item) => (
              <button
                key={item.name}
                onClick={() => onNavigate(item.href)}
                className={`px-2 lg:px-3 py-2 text-sm font-medium transition-colors duration-200 ${
                  currentPage === item.href
                    ? 'border-b-2'
                    : 'text-white hover:opacity-80'
                }`}
                style={{
                  color: currentPage === item.href ? colors.primary : 'white',
                  borderBottomColor: currentPage === item.href ? colors.primary : 'transparent'
                }}
              >
                {item.name}
              </button>
            ))}
          </nav>

          {/* Search Bar - Hidden on mobile, shown on tablet+ */}
          <div className="hidden md:flex items-center space-x-4 flex-1 max-w-sm lg:max-w-md mx-4 lg:mx-8">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Buscar produtos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-gray-800 text-white placeholder-gray-400 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2"
                style={{ 
                  '--tw-ring-color': colors.primary,
                  borderColor: 'transparent'
                } as React.CSSProperties}
              />
            </div>
          </div>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-2 lg:space-x-4">
            <button className="p-2 text-white hover:opacity-80 transition-colors">
              <Heart className="w-5 h-5" />
            </button>

            {/* Meus Pedidos Button - NEW */}
            <button
              onClick={() => onNavigate('my-orders')}
              className="flex items-center space-x-1 px-3 py-2 text-white hover:opacity-80 transition-colors"
              title="Meus Pedidos"
            >
              <Package className="w-5 h-5" />
              <span className="text-sm hidden lg:block">Meus Pedidos</span>
            </button>
            
            {/* Admin Edit Button - Positioned before user button */}
            {isAdmin && (
              <button
                onClick={() => onNavigate('admin')}
                className="flex items-center space-x-1 px-3 py-2 rounded-lg hover:opacity-90 transition-colors font-medium"
                style={{ 
                  backgroundColor: colors.buttonBg, 
                  color: colors.buttonText 
                }}
                title="Editar Página"
              >
                <Edit className="w-4 h-4" />
                <span className="hidden lg:block">Editar Página</span>
              </button>
            )}
            
            <button
              onClick={() => onNavigate('account')}
              className="flex items-center space-x-1 text-white hover:opacity-80 transition-colors px-2"
            >
              <User className="w-5 h-5" />
              <span className="text-sm hidden lg:block">
                {isAuthenticated ? user?.name?.split(' ')[0] : 'Entrar'}
              </span>
            </button>

            <button
              onClick={onCartOpen}
              className="relative p-2 text-white hover:opacity-80 transition-colors"
            >
              <ShoppingBag className="w-5 h-5" />
              {itemCount > 0 && (
                <span 
                  className="absolute -top-1 -right-1 text-xs rounded-full w-5 h-5 flex items-center justify-center font-medium"
                  style={{ 
                    backgroundColor: colors.primary, 
                    color: colors.secondary 
                  }}
                >
                  {itemCount}
                </span>
              )}
            </button>
          </div>

          {/* Mobile menu button and cart */}
          <div className="md:hidden flex items-center space-x-2">
            <button
              onClick={onCartOpen}
              className="relative p-2 text-white"
            >
              <ShoppingBag className="w-5 h-5" />
              {itemCount > 0 && (
                <span 
                  className="absolute -top-1 -right-1 text-xs rounded-full w-4 h-4 flex items-center justify-center font-medium"
                  style={{ 
                    backgroundColor: colors.primary, 
                    color: colors.secondary 
                  }}
                >
                  {itemCount}
                </span>
              )}
            </button>
            
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-white"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="md:hidden py-3 border-t border-gray-800">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Buscar produtos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-800 text-white placeholder-gray-400 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2"
              style={{ 
                '--tw-ring-color': colors.primary 
              } as React.CSSProperties}
            />
          </div>
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-gray-900 border-t border-gray-800">
          <div className="px-2 pt-2 pb-3 space-y-1">
            {navigation.map((item) => (
              <button
                key={item.name}
                onClick={() => {
                  onNavigate(item.href);
                  setIsMobileMenuOpen(false);
                }}
                className={`block w-full text-left px-3 py-3 text-base font-medium transition-colors ${
                  currentPage === item.href
                    ? 'bg-gray-800'
                    : 'text-white hover:bg-gray-800'
                }`}
                style={{
                  color: currentPage === item.href ? colors.primary : 'white'
                }}
              >
                {item.name}
              </button>
            ))}
            
            <div className="border-t border-gray-700 pt-2">
              {/* Meus Pedidos Button for Mobile - NEW */}
              <button
                onClick={() => {
                  onNavigate('my-orders');
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center w-full px-3 py-3 text-base font-medium text-white hover:bg-gray-800"
              >
                <Package className="w-5 h-5 mr-3" />
                Meus Pedidos
              </button>

              <button
                onClick={() => {
                  onNavigate('account');
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center w-full px-3 py-3 text-base font-medium text-white hover:bg-gray-800"
              >
                <User className="w-5 h-5 mr-3" />
                {isAuthenticated ? user?.name : 'Entrar'}
              </button>
              
              <button className="flex items-center w-full px-3 py-3 text-base font-medium text-white hover:bg-gray-800">
                <Heart className="w-5 h-5 mr-3" />
                Favoritos
              </button>

              {/* Admin Edit Button for Mobile */}
              {isAdmin && (
                <button
                  onClick={() => {
                    onNavigate('admin');
                    setIsMobileMenuOpen(false);
                  }}
                  className="flex items-center w-full px-3 py-3 text-base font-medium hover:opacity-90"
                  style={{ 
                    backgroundColor: colors.buttonBg, 
                    color: colors.buttonText 
                  }}
                >
                  <Edit className="w-5 h-5 mr-3" />
                  Editar Página
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;