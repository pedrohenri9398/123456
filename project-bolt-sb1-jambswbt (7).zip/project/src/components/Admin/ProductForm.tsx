import React, { useState, useEffect } from 'react';
import { Save, X, Upload, Image as ImageIcon } from 'lucide-react';
import { Product } from '../../types';
import ProductImageManager from './ProductImageManager';
import ColorImageManager from './ColorImageManager';

interface ProductFormProps {
  product?: Product;
  onSave: (product: Omit<Product, 'id'> | Product) => void;
  onCancel: () => void;
  isEditing?: boolean;
}

const ProductForm: React.FC<ProductFormProps> = ({ 
  product, 
  onSave, 
  onCancel, 
  isEditing = false 
}) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: 0,
    originalPrice: 0,
    images: [''],
    colorImages: {} as { [color: string]: string[] },
    category: 'saltos' as 'saltos' | 'sapatilhas' | 'masculinos',
    sizes: [] as string[],
    colors: [] as string[],
    inStock: true,
    featured: false,
    rating: 0,
    reviews: 0,
    stock: 0
  });

  const [newSize, setNewSize] = useState('');
  const [newColor, setNewColor] = useState('');
  const [activeImageTab, setActiveImageTab] = useState<'general' | 'colors'>('general');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [previewColor, setPreviewColor] = useState<string>('');

  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name,
        description: product.description,
        price: product.price,
        originalPrice: product.originalPrice || 0,
        images: product.images.length > 0 ? product.images : [''],
        colorImages: product.colorImages || {},
        category: product.category,
        sizes: product.sizes,
        colors: product.colors,
        inStock: product.inStock,
        featured: product.featured || false,
        rating: product.rating,
        reviews: product.reviews,
        stock: 0
      });
      
      // Set first color as preview if available
      if (product.colors.length > 0) {
        setPreviewColor(product.colors[0]);
      }
    }
  }, [product]);

  // Set first color as preview when colors are added
  useEffect(() => {
    if (formData.colors.length > 0 && !previewColor) {
      setPreviewColor(formData.colors[0]);
    }
  }, [formData.colors, previewColor]);

  // Detectar mudanças no formulário
  useEffect(() => {
    if (product) {
      const hasChanges = 
        formData.name !== product.name ||
        formData.description !== product.description ||
        formData.price !== product.price ||
        formData.originalPrice !== (product.originalPrice || 0) ||
        JSON.stringify(formData.images) !== JSON.stringify(product.images) ||
        JSON.stringify(formData.colorImages) !== JSON.stringify(product.colorImages || {}) ||
        formData.category !== product.category ||
        JSON.stringify(formData.sizes) !== JSON.stringify(product.sizes) ||
        JSON.stringify(formData.colors) !== JSON.stringify(product.colors) ||
        formData.inStock !== product.inStock ||
        formData.featured !== (product.featured || false);
      
      setHasUnsavedChanges(hasChanges);
    } else {
      // Para novos produtos, verificar se há dados preenchidos
      const hasData = 
        formData.name.trim() !== '' ||
        formData.description.trim() !== '' ||
        formData.price > 0 ||
        formData.images.some(img => img.trim() !== '') ||
        Object.keys(formData.colorImages).length > 0 ||
        formData.sizes.length > 0 ||
        formData.colors.length > 0;
      
      setHasUnsavedChanges(hasData);
    }
  }, [formData, product]);

  // Get current preview images
  const getPreviewImages = () => {
    if (!previewColor) {
      // No color selected, show general images
      return formData.images.filter(img => img.trim() !== '');
    }
    
    // Color selected, check if it has specific images
    const colorImages = formData.colorImages[previewColor];
    if (colorImages && colorImages.length > 0) {
      return colorImages;
    }
    
    // Fallback to general images
    return formData.images.filter(img => img.trim() !== '');
  };

  const previewImages = getPreviewImages();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.description.trim() || formData.price <= 0) {
      alert('Por favor, preencha todos os campos obrigatórios');
      return;
    }

    if (formData.colors.length === 0) {
      alert('Por favor, adicione pelo menos uma cor disponível');
      return;
    }

    if (formData.sizes.length === 0) {
      alert('Por favor, adicione pelo menos um tamanho disponível');
      return;
    }

    // Verificar se há pelo menos uma imagem (geral ou por cor)
    const hasGeneralImages = formData.images.some(img => img.trim() !== '');
    const hasColorImages = Object.values(formData.colorImages).some(images => images.length > 0);
    
    if (!hasGeneralImages && !hasColorImages) {
      alert('Por favor, adicione pelo menos uma imagem (geral ou específica por cor)');
      return;
    }

    // Filtrar imagens vazias
    const validImages = formData.images.filter(img => img.trim() !== '');

    const productData = {
      ...formData,
      originalPrice: formData.originalPrice > 0 ? formData.originalPrice : undefined,
      images: validImages.length > 0 ? validImages : [''], // Manter pelo menos uma string vazia se não houver imagens gerais
      colorImages: formData.colorImages
    };

    if (isEditing && product) {
      onSave({ ...product, ...productData });
    } else {
      onSave(productData);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else if (type === 'number') {
      setFormData(prev => ({ ...prev, [name]: parseFloat(value) || 0 }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const addSize = () => {
    if (newSize.trim() && !formData.sizes.includes(newSize.trim())) {
      setFormData(prev => ({
        ...prev,
        sizes: [...prev.sizes, newSize.trim()].sort()
      }));
      setNewSize('');
    }
  };

  const removeSize = (size: string) => {
    setFormData(prev => ({
      ...prev,
      sizes: prev.sizes.filter(s => s !== size)
    }));
  };

  const addColor = () => {
    if (newColor.trim() && !formData.colors.includes(newColor.trim())) {
      const newColors = [...formData.colors, newColor.trim()];
      setFormData(prev => ({
        ...prev,
        colors: newColors
      }));
      
      // Set as preview color if it's the first one
      if (!previewColor) {
        setPreviewColor(newColor.trim());
      }
      
      setNewColor('');
    }
  };

  const removeColor = (color: string) => {
    const newColors = formData.colors.filter(c => c !== color);
    const newColorImages = { ...formData.colorImages };
    delete newColorImages[color];
    
    setFormData(prev => ({
      ...prev,
      colors: newColors,
      colorImages: newColorImages
    }));
    
    // Update preview color if the removed color was selected
    if (previewColor === color) {
      setPreviewColor(newColors.length > 0 ? newColors[0] : '');
    }
  };

  const handleImagesChange = (images: string[]) => {
    setFormData(prev => ({
      ...prev,
      images: images
    }));
  };

  const handleColorImagesChange = (colorImages: { [color: string]: string[] }) => {
    setFormData(prev => ({
      ...prev,
      colorImages: colorImages
    }));
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-semibold text-gray-900">
          {isEditing ? 'Editar Produto' : 'Adicionar Novo Produto'}
        </h3>
        <button
          onClick={onCancel}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Indicador de mudanças não salvas */}
      {hasUnsavedChanges && (
        <div className="mb-6 p-3 bg-amber-50 border border-amber-200 rounded-lg">
          <p className="text-amber-800 text-sm">
            ⚠️ Você tem alterações não salvas. Lembre-se de salvar antes de sair.
          </p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Nome do Produto */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Nome do Produto *
          </label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
            placeholder="Ex: Sapato de Salto Alto Clássico"
          />
        </div>

        {/* Descrição */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Descrição do Produto *
          </label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            required
            rows={4}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
            placeholder="Descreva as características, materiais e benefícios do produto..."
          />
        </div>

        {/* Categoria e Preços */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Categoria *
            </label>
            <select
              name="category"
              value={formData.category}
              onChange={handleChange}
              required
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
            >
              <option value="saltos">Saltos Femininos</option>
              <option value="sapatilhas">Sapatilhas</option>
              <option value="masculinos">Sapatos Masculinos</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Preço Atual (R$) *
            </label>
            <input
              type="number"
              name="price"
              value={formData.price}
              onChange={handleChange}
              required
              min="0"
              step="0.01"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              placeholder="299.90"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Preço Original (R$)
            </label>
            <input
              type="number"
              name="originalPrice"
              value={formData.originalPrice}
              onChange={handleChange}
              min="0"
              step="0.01"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              placeholder="399.90 (opcional)"
            />
          </div>
        </div>

        {/* Cores */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Cores Disponíveis *
          </label>
          <div className="flex flex-wrap gap-2 mb-3">
            {formData.colors.map((color) => (
              <span
                key={color}
                className="bg-gray-100 px-3 py-1 rounded-full text-sm flex items-center space-x-2"
              >
                <span>{color}</span>
                <button
                  type="button"
                  onClick={() => removeColor(color)}
                  className="text-red-500 hover:text-red-700"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
          <div className="flex space-x-2">
            <input
              type="text"
              value={newColor}
              onChange={(e) => setNewColor(e.target.value)}
              placeholder="Ex: Preto"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
            />
            <button
              type="button"
              onClick={addColor}
              className="px-4 py-2 bg-gray-100 border border-gray-300 rounded-lg hover:bg-gray-200 transition-colors"
            >
              Adicionar
            </button>
          </div>
        </div>

        {/* Tamanhos */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Tamanhos Disponíveis *
          </label>
          <div className="flex flex-wrap gap-2 mb-3">
            {formData.sizes.map((size) => (
              <span
                key={size}
                className="bg-gray-100 px-3 py-1 rounded-full text-sm flex items-center space-x-2"
              >
                <span>{size}</span>
                <button
                  type="button"
                  onClick={() => removeSize(size)}
                  className="text-red-500 hover:text-red-700"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
          <div className="flex space-x-2">
            <input
              type="text"
              value={newSize}
              onChange={(e) => setNewSize(e.target.value)}
              placeholder="Ex: 37"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
            />
            <button
              type="button"
              onClick={addSize}
              className="px-4 py-2 bg-gray-100 border border-gray-300 rounded-lg hover:bg-gray-200 transition-colors"
            >
              Adicionar
            </button>
          </div>
        </div>

        {/* Preview do Produto */}
        {formData.colors.length > 0 && (
          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <ImageIcon className="w-5 h-5 mr-2" />
              Preview do Produto
            </h3>

            {/* Seletor de Cor para Preview */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Visualizar produto na cor:
              </label>
              <div className="flex flex-wrap gap-2">
                {formData.colors.map((color) => {
                  const hasColorImages = formData.colorImages[color] && formData.colorImages[color].length > 0;
                  
                  return (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setPreviewColor(color)}
                      className={`relative py-2 px-4 border rounded-lg text-sm font-medium transition-colors ${
                        previewColor === color
                          ? 'border-blue-500 bg-blue-50 text-blue-700'
                          : 'border-gray-300 hover:border-gray-400'
                      }`}
                    >
                      {color}
                      {hasColorImages && (
                        <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white" 
                             title="Esta cor tem imagens específicas" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Preview das Imagens */}
            <div className="border border-gray-200 rounded-lg p-4 bg-white">
              {previewImages.length > 0 ? (
                <div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
                    {previewImages.slice(0, 4).map((image, index) => (
                      <div key={index} className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                        <img
                          src={image}
                          alt={`${formData.name} - ${previewColor}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                  </div>
                  
                  <div className="text-sm text-gray-600">
                    {previewColor && formData.colorImages[previewColor] && formData.colorImages[previewColor].length > 0 ? (
                      <span className="text-green-600">
                        ✨ Mostrando {previewImages.length} imagem(s) específica(s) da cor "{previewColor}"
                      </span>
                    ) : (
                      <span className="text-blue-600">
                        📷 Mostrando {previewImages.length} imagem(s) geral(is) do produto
                        {previewColor && (
                          <span className="text-gray-500"> (cor "{previewColor}" não tem imagens específicas)</span>
                        )}
                      </span>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <ImageIcon className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                  <p>Nenhuma imagem disponível para preview</p>
                  <p className="text-sm">Adicione imagens gerais ou específicas por cor</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Sistema de Gerenciamento de Imagens */}
        <div className="bg-gray-50 p-6 rounded-lg">
          <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center">
            <ImageIcon className="w-5 h-5 mr-2" />
            Gerenciar Imagens do Produto
          </h3>

          {/* Abas para Imagens */}
          <div className="border-b border-gray-200 mb-6">
            <nav className="-mb-px flex space-x-8">
              <button
                type="button"
                onClick={() => setActiveImageTab('general')}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeImageTab === 'general'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Imagens Gerais
                <span className="ml-2 bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs">
                  {formData.images.filter(img => img.trim()).length}
                </span>
              </button>
              <button
                type="button"
                onClick={() => setActiveImageTab('colors')}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeImageTab === 'colors'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Imagens por Cor
                {formData.colors.length > 0 && (
                  <span className="ml-2 bg-blue-100 text-blue-600 px-2 py-1 rounded-full text-xs">
                    {formData.colors.length} cores
                  </span>
                )}
              </button>
            </nav>
          </div>

          {/* Conteúdo das Abas */}
          {activeImageTab === 'general' && (
            <ProductImageManager
              images={formData.images}
              onImagesChange={handleImagesChange}
              maxImages={8}
            />
          )}

          {activeImageTab === 'colors' && (
            <ColorImageManager
              colors={formData.colors}
              colorImages={formData.colorImages}
              onColorImagesChange={handleColorImagesChange}
              maxImagesPerColor={5}
            />
          )}
        </div>

        {/* Opções */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                name="inStock"
                checked={formData.inStock}
                onChange={handleChange}
                className="rounded"
              />
              <span className="text-sm font-medium text-gray-700">Produto em estoque</span>
            </label>

            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                name="featured"
                checked={formData.featured}
                onChange={handleChange}
                className="rounded"
              />
              <span className="text-sm font-medium text-gray-700">Produto em destaque</span>
            </label>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Quantidade em Estoque
            </label>
            <input
              type="number"
              name="stock"
              value={formData.stock}
              onChange={handleChange}
              min="0"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              placeholder="100"
            />
          </div>
        </div>

        {/* Botões */}
        <div className="flex justify-end space-x-4 pt-6 border-t">
          <button
            type="button"
            onClick={onCancel}
            className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Cancelar
          </button>
          <button
            type="submit"
            className="px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors flex items-center space-x-2"
          >
            <Save className="w-5 h-5" />
            <span>{isEditing ? 'Atualizar Produto' : 'Salvar Produto'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};

export default ProductForm;