import React, { useState } from 'react';
import { Plus, X, Upload, Eye, ExternalLink, Palette, Image as ImageIcon, AlertCircle, ArrowUp, ArrowDown } from 'lucide-react';

interface ColorImageManagerProps {
  colors: string[];
  colorImages: { [color: string]: string[] };
  onColorImagesChange: (colorImages: { [color: string]: string[] }) => void;
  maxImagesPerColor?: number;
}

const ColorImageManager: React.FC<ColorImageManagerProps> = ({
  colors,
  colorImages,
  onColorImagesChange,
  maxImagesPerColor = 5
}) => {
  const [selectedColor, setSelectedColor] = useState<string>(colors[0] || '');
  const [urlInput, setUrlInput] = useState('');
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const currentColorImages = colorImages[selectedColor] || [];

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || !selectedColor) return;

    setIsUploading(true);

    Array.from(files).forEach((file) => {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          if (result && currentColorImages.length < maxImagesPerColor) {
            const newColorImages = {
              ...colorImages,
              [selectedColor]: [...currentColorImages, result]
            };
            onColorImagesChange(newColorImages);
          }
          setIsUploading(false);
        };
        reader.readAsDataURL(file);
      }
    });

    event.target.value = '';
  };

  const handleUrlAdd = () => {
    if (urlInput.trim() && selectedColor && currentColorImages.length < maxImagesPerColor) {
      try {
        new URL(urlInput.trim());
        const newColorImages = {
          ...colorImages,
          [selectedColor]: [...currentColorImages, urlInput.trim()]
        };
        onColorImagesChange(newColorImages);
        setUrlInput('');
        setShowUrlInput(false);
      } catch (error) {
        alert('URL inválida. Por favor, insira uma URL válida.');
      }
    }
  };

  const handleStockImageAdd = (stockImage: string) => {
    if (selectedColor && currentColorImages.length < maxImagesPerColor && !currentColorImages.includes(stockImage)) {
      const newColorImages = {
        ...colorImages,
        [selectedColor]: [...currentColorImages, stockImage]
      };
      onColorImagesChange(newColorImages);
    }
  };

  const removeImage = (imageIndex: number) => {
    const newImages = currentColorImages.filter((_, i) => i !== imageIndex);
    const newColorImages = {
      ...colorImages,
      [selectedColor]: newImages
    };
    onColorImagesChange(newColorImages);
  };

  const moveImage = (fromIndex: number, toIndex: number) => {
    if (fromIndex === toIndex) return;
    
    const newImages = [...currentColorImages];
    const [movedImage] = newImages.splice(fromIndex, 1);
    newImages.splice(toIndex, 0, movedImage);
    
    const newColorImages = {
      ...colorImages,
      [selectedColor]: newImages
    };
    onColorImagesChange(newColorImages);
  };

  const moveImageUp = (index: number) => {
    if (index > 0) {
      moveImage(index, index - 1);
    }
  };

  const moveImageDown = (index: number) => {
    if (index < currentColorImages.length - 1) {
      moveImage(index, index + 1);
    }
  };

  const getColorStats = () => {
    return colors.map(color => ({
      color,
      imageCount: colorImages[color]?.length || 0,
      hasImages: (colorImages[color]?.length || 0) > 0
    }));
  };

  const stockImages = [
    'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/1598508/pexels-photo-1598508.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/8923522/pexels-photo-8923522.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/1598663/pexels-photo-1598663.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/1598507/pexels-photo-1598507.jpeg?auto=compress&cs=tinysrgb&w=800'
  ];

  if (colors.length === 0) {
    return (
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <div className="flex items-center space-x-2">
          <AlertCircle className="w-5 h-5 text-amber-600" />
          <p className="text-amber-800 text-sm">
            <strong>Adicione cores primeiro:</strong> Você precisa definir as cores disponíveis antes de associar imagens.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
          <Palette className="w-5 h-5" />
          <span>Imagens por Cor</span>
        </h3>
        <div className="text-sm text-gray-500">
          {getColorStats().filter(c => c.hasImages).length} de {colors.length} cores com imagens
        </div>
      </div>

      {/* Color Selector - MELHORADO */}
      <div className="bg-white border border-gray-200 rounded-lg p-4">
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Clique na cor para gerenciar suas imagens:
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {colors.map((color) => {
            const stats = getColorStats().find(c => c.color === color);
            return (
              <button
                key={color}
                type="button"
                onClick={() => setSelectedColor(color)}
                className={`relative p-4 border-2 rounded-lg text-sm font-medium transition-all hover:shadow-md ${
                  selectedColor === color
                    ? 'border-blue-500 bg-blue-50 text-blue-700 shadow-md'
                    : 'border-gray-300 hover:border-gray-400 bg-white hover:bg-gray-50'
                }`}
              >
                <div className="text-center">
                  <span className="block font-semibold">{color}</span>
                  <span className="text-xs text-gray-500 mt-1">
                    {stats?.imageCount || 0} imagem{(stats?.imageCount || 0) !== 1 ? 's' : ''}
                  </span>
                </div>
                
                {/* Status Indicator */}
                <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full ${
                  stats?.hasImages ? 'bg-green-500' : 'bg-gray-300'
                }`} />
                
                {/* Selected Indicator */}
                {selectedColor === color && (
                  <div className="absolute top-1 left-1 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Color Images */}
      {selectedColor && (
        <div className="space-y-6">
          {/* Header da Cor Selecionada */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <h4 className="text-lg font-semibold text-blue-900 flex items-center">
                <div className="w-4 h-4 bg-blue-500 rounded-full mr-2"></div>
                Gerenciando imagens da cor "{selectedColor}"
              </h4>
              <span className="text-sm text-blue-700">
                {currentColorImages.length}/{maxImagesPerColor} imagens
              </span>
            </div>
            {currentColorImages.length > 1 && (
              <p className="text-sm text-blue-700 mt-2">
                💡 Arraste para reordenar • Primeira imagem é a principal para esta cor
              </p>
            )}
          </div>

          {/* Current Images for Selected Color */}
          {currentColorImages.length > 0 && (
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <h5 className="font-medium text-gray-900 mb-3">
                Imagens da cor "{selectedColor}"
              </h5>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {currentColorImages.map((image, index) => (
                  <div
                    key={`${selectedColor}-${index}`}
                    className="relative group bg-gray-100 rounded-lg overflow-hidden border-2 border-gray-200 hover:border-gray-300 transition-all"
                  >
                    {/* Main Image Badge */}
                    {index === 0 && (
                      <div className="absolute top-2 left-2 bg-blue-500 text-white px-2 py-1 rounded text-xs font-medium z-20">
                        Principal
                      </div>
                    )}

                    {/* Position Indicator */}
                    <div className="absolute top-2 right-2 bg-black bg-opacity-75 text-white px-2 py-1 rounded text-xs font-medium z-20">
                      {index + 1}
                    </div>

                    {/* Image */}
                    <div className="aspect-square">
                      <img
                        src={image}
                        alt={`${selectedColor} ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Actions Overlay */}
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                      <div className="flex flex-wrap gap-1 justify-center">
                        {/* Reorder Buttons */}
                        {currentColorImages.length > 1 && (
                          <>
                            <button
                              type="button"
                              onClick={() => moveImageUp(index)}
                              disabled={index === 0}
                              className="p-1.5 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                              title="Mover para cima"
                            >
                              <ArrowUp className="w-3 h-3" />
                            </button>
                            <button
                              type="button"
                              onClick={() => moveImageDown(index)}
                              disabled={index === currentColorImages.length - 1}
                              className="p-1.5 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                              title="Mover para baixo"
                            >
                              <ArrowDown className="w-3 h-3" />
                            </button>
                          </>
                        )}
                        
                        {/* View Actions */}
                        <button
                          type="button"
                          onClick={() => setPreviewImage(image)}
                          className="p-1.5 bg-white text-gray-700 rounded hover:bg-gray-100 transition-colors"
                          title="Visualizar"
                        >
                          <Eye className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          onClick={() => window.open(image, '_blank')}
                          className="p-1.5 bg-white text-gray-700 rounded hover:bg-gray-100 transition-colors"
                          title="Abrir em nova aba"
                        >
                          <ExternalLink className="w-3 h-3" />
                        </button>
                        
                        {/* Remove Button */}
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="p-1.5 bg-red-500 text-white rounded hover:bg-red-600 transition-colors"
                          title="Remover"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Add Images for Selected Color */}
          {currentColorImages.length < maxImagesPerColor && (
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 bg-white">
                <div className="text-center">
                  <ImageIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h4 className="text-lg font-medium text-gray-900 mb-2">
                    Adicionar Imagens para "{selectedColor}"
                  </h4>
                  <p className="text-gray-600 mb-4">
                    Adicione até {maxImagesPerColor - currentColorImages.length} imagens para esta cor
                  </p>

                  <div className="flex flex-col sm:flex-row gap-3 justify-center">
                    {/* Upload Button */}
                    <label className="cursor-pointer">
                      <input
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="hidden"
                        disabled={isUploading}
                      />
                      <div className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50">
                        {isUploading ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        ) : (
                          <Upload className="w-4 h-4" />
                        )}
                        <span>Upload Arquivos</span>
                      </div>
                    </label>

                    {/* URL Button */}
                    <button
                      type="button"
                      onClick={() => setShowUrlInput(!showUrlInput)}
                      className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      <span>URL da Imagem</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* URL Input */}
              {showUrlInput && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    URL da Imagem para "{selectedColor}"
                  </label>
                  <div className="flex space-x-2">
                    <input
                      type="url"
                      value={urlInput}
                      onChange={(e) => setUrlInput(e.target.value)}
                      placeholder="https://exemplo.com/imagem.jpg"
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                    />
                    <button
                      type="button"
                      onClick={handleUrlAdd}
                      disabled={!urlInput.trim()}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Adicionar
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowUrlInput(false);
                        setUrlInput('');
                      }}
                      className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              )}

              {/* Stock Images */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-3">
                  Imagens Sugeridas para "{selectedColor}" (Pexels)
                </h4>
                <div className="grid grid-cols-3 md:grid-cols-5 gap-2">
                  {stockImages.map((stockImage, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => handleStockImageAdd(stockImage)}
                      disabled={currentColorImages.includes(stockImage) || currentColorImages.length >= maxImagesPerColor}
                      className="relative aspect-square rounded-lg overflow-hidden border-2 border-gray-200 hover:border-blue-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <img
                        src={stockImage}
                        alt={`Sugestão ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                      {currentColorImages.includes(stockImage) && (
                        <div className="absolute inset-0 bg-green-500 bg-opacity-75 flex items-center justify-center">
                          <span className="text-white text-xs font-medium">Adicionada</span>
                        </div>
                      )}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Clique para adicionar • Imagens gratuitas do Pexels
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Summary */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start space-x-2">
          <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-blue-800">
            <p className="font-medium mb-2">Como funciona o sistema de cores e imagens:</p>
            <ul className="space-y-1 text-xs">
              <li>• <strong>Cada cor pode ter suas próprias imagens:</strong> Mostre como o produto fica em cada cor</li>
              <li>• <strong>Primeira imagem é principal:</strong> Será exibida por padrão para cada cor</li>
              <li>• <strong>Fallback inteligente:</strong> Se uma cor não tiver imagens, usa as imagens gerais do produto</li>
              <li>• <strong>Experiência do cliente:</strong> Ao selecionar uma cor, as imagens mudam automaticamente</li>
              <li>• <strong>Recomendação:</strong> Adicione pelo menos 1 imagem para cada cor disponível</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Preview Modal */}
      {previewImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75">
          <div className="relative max-w-4xl max-h-[90vh] p-4">
            <button
              type="button"
              onClick={() => setPreviewImage(null)}
              className="absolute top-2 right-2 p-2 bg-white rounded-full hover:bg-gray-100 transition-colors z-10"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={previewImage}
              alt="Preview"
              className="max-w-full max-h-full object-contain rounded-lg"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default ColorImageManager;