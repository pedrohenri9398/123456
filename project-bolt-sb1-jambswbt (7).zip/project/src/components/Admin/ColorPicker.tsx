import React, { useState } from 'react';
import { Palette, RotateCcw } from 'lucide-react';

interface ColorPickerProps {
  label: string;
  value: string;
  onChange: (color: string) => void;
  presets?: string[];
}

const ColorPicker: React.FC<ColorPickerProps> = ({
  label,
  value,
  onChange,
  presets = ['#facc15', '#000000', '#ffffff', '#f59e0b', '#ef4444', '#3b82f6', '#10b981', '#8b5cf6']
}) => {
  const [showPicker, setShowPicker] = useState(false);

  return (
    <div className="space-y-3">
      <label className="block text-sm font-medium text-gray-700">
        {label}
      </label>
      
      <div className="flex items-center space-x-3">
        {/* Preview da cor atual */}
        <div
          className="w-10 h-10 rounded-lg border-2 border-gray-300 cursor-pointer shadow-sm"
          style={{ backgroundColor: value }}
          onClick={() => setShowPicker(!showPicker)}
        />
        
        {/* Input de cor */}
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-16 h-10 border border-gray-300 rounded-lg cursor-pointer"
        />
        
        {/* Input de texto */}
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 text-sm font-mono"
          placeholder="#000000"
        />
      </div>

      {/* Cores predefinidas */}
      <div className="space-y-2">
        <p className="text-xs text-gray-500">Cores predefinidas:</p>
        <div className="flex flex-wrap gap-2">
          {presets.map((preset) => (
            <button
              key={preset}
              onClick={() => onChange(preset)}
              className={`w-8 h-8 rounded-lg border-2 transition-all hover:scale-110 ${
                value === preset ? 'border-gray-800 ring-2 ring-yellow-400' : 'border-gray-300'
              }`}
              style={{ backgroundColor: preset }}
              title={preset}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ColorPicker;