import React, { useState, useEffect } from 'react';
import { 
  Package, 
  Eye, 
  Check, 
  X, 
  Clock, 
  Truck, 
  AlertCircle, 
  Search,
  Filter,
  Download,
  RefreshCw,
  User,
  Calendar,
  DollarSign
} from 'lucide-react';
import { supabase, isDemoMode } from '../../lib/supabase';
import { paymentService } from '../../lib/payment';

interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  customer_email: string;
  total_amount: number;
  shipping_cost: number;
  status: string;
  payment_method: string;
  created_at: string;
  items: any[];
  shipping_address: any;
  payment_transactions?: any[];
}

interface OrderManagementProps {
  onOrderSelect?: (order: Order) => void;
}

const OrderManagement: React.FC<OrderManagementProps> = ({ onOrderSelect }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);

  const statusOptions = [
    { value: 'all', label: 'Todos os Status', color: 'gray' },
    { value: 'pending', label: 'Pendente', color: 'yellow' },
    { value: 'processing', label: 'Processando', color: 'blue' },
    { value: 'shipped', label: 'Enviado', color: 'purple' },
    { value: 'delivered', label: 'Entregue', color: 'green' },
    { value: 'cancelled', label: 'Cancelado', color: 'red' }
  ];

  const paymentStatusMap = {
    pending: { label: 'Pendente', color: 'yellow' },
    paid: { label: 'Pago', color: 'green' },
    cancelled: { label: 'Cancelado', color: 'red' },
    expired: { label: 'Expirado', color: 'gray' }
  };

  // Mock orders for demo mode
  const mockOrders: Order[] = [
    {
      id: 'demo-order-1',
      order_number: 'CD001',
      customer_name: 'Ana Silva',
      customer_email: 'ana@email.com',
      total_amount: 299.90,
      shipping_cost: 15.90,
      status: 'delivered',
      payment_method: 'pix',
      created_at: '2024-01-15T10:30:00Z',
      items: [
        {
          product_name: 'Sapato de Salto Alto Clássico',
          product_image: 'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=800',
          size: '37',
          color: 'Preto',
          quantity: 1,
          unit_price: 299.90,
          total_price: 299.90
        }
      ],
      shipping_address: {
        street: 'Rua das Flores',
        number: '123',
        neighborhood: 'Centro',
        city: 'São Paulo',
        state: 'SP',
        zipCode: '01234-567'
      },
      payment_transactions: [
        {
          id: 'demo-tx-1',
          status: 'paid'
        }
      ]
    },
    {
      id: 'demo-order-2',
      order_number: 'CD002',
      customer_name: 'Carlos Mendes',
      customer_email: 'carlos@email.com',
      total_amount: 189.90,
      shipping_cost: 0,
      status: 'shipped',
      payment_method: 'boleto',
      created_at: '2024-01-14T14:20:00Z',
      items: [
        {
          product_name: 'Sapatilha de Ballet Profissional',
          product_image: 'https://images.pexels.com/photos/8923522/pexels-photo-8923522.jpeg?auto=compress&cs=tinysrgb&w=800',
          size: '39',
          color: 'Rosa',
          quantity: 1,
          unit_price: 189.90,
          total_price: 189.90
        }
      ],
      shipping_address: {
        street: 'Av. Paulista',
        number: '456',
        neighborhood: 'Bela Vista',
        city: 'São Paulo',
        state: 'SP',
        zipCode: '01310-100'
      },
      payment_transactions: [
        {
          id: 'demo-tx-2',
          status: 'paid'
        }
      ]
    },
    {
      id: 'demo-order-3',
      order_number: 'CD003',
      customer_name: 'Marina Costa',
      customer_email: 'marina@email.com',
      total_amount: 449.80,
      shipping_cost: 15.90,
      status: 'processing',
      payment_method: 'pix',
      created_at: '2024-01-13T09:15:00Z',
      items: [
        {
          product_name: 'Sapato Social Masculino para Dança',
          product_image: 'https://images.pexels.com/photos/1598663/pexels-photo-1598663.jpeg?auto=compress&cs=tinysrgb&w=800',
          size: '42',
          color: 'Preto',
          quantity: 1,
          unit_price: 249.90,
          total_price: 249.90
        },
        {
          product_name: 'Sandália de Salto para Dança Latina',
          product_image: 'https://images.pexels.com/photos/1598507/pexels-photo-1598507.jpeg?auto=compress&cs=tinysrgb&w=800',
          size: '36',
          color: 'Dourado',
          quantity: 1,
          unit_price: 219.90,
          total_price: 219.90
        }
      ],
      shipping_address: {
        street: 'Rua Augusta',
        number: '789',
        neighborhood: 'Consolação',
        city: 'São Paulo',
        state: 'SP',
        zipCode: '01305-000'
      },
      payment_transactions: [
        {
          id: 'demo-tx-3',
          status: 'pending'
        }
      ]
    }
  ];

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    try {
      setLoading(true);
      setError('');
      
      if (isDemoMode) {
        // Demo mode - use mock data
        console.warn('Demo mode: using mock orders');
        await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate loading
        setOrders(mockOrders);
        setLoading(false);
        return;
      }

      // Try to load orders from database
      try {
        const { data: ordersData, error: ordersError } = await supabase
          .from('user_orders')
          .select(`
            *,
            payment_transactions (*)
          `)
          .order('created_at', { ascending: false });

        if (ordersError) {
          throw ordersError;
        }

        setOrders(ordersData || []);
      } catch (dbError: any) {
        console.error('Database error, falling back to demo mode:', dbError);
        
        // Check if it's a policy error
        if (dbError.message?.includes('policy') || dbError.message?.includes('recursion')) {
          setError('Erro de configuração do banco de dados. Usando dados de demonstração. Por favor, execute a migração para corrigir as políticas RLS.');
        } else {
          setError('Erro ao conectar com o banco de dados. Usando dados de demonstração.');
        }
        
        // Fallback to demo data
        setOrders(mockOrders);
      }
    } catch (error: any) {
      console.error('Error loading orders:', error);
      setError('Erro ao carregar pedidos. Usando dados de demonstração.');
      
      // Always fallback to demo data on error
      setOrders(mockOrders);
    } finally {
      setLoading(false);
    }
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      setIsUpdating(true);
      
      if (isDemoMode || orderId.startsWith('demo-')) {
        // Demo mode - simulate update
        console.warn('Demo mode: simulating order status update');
        await new Promise(resolve => setTimeout(resolve, 500));
        
        setOrders(prev => prev.map(order => 
          order.id === orderId 
            ? { ...order, status: newStatus }
            : order
        ));

        if (selectedOrder?.id === orderId) {
          setSelectedOrder(prev => prev ? { ...prev, status: newStatus } : null);
        }

        alert('Status do pedido atualizado com sucesso! (Modo demonstração)');
        return;
      }
      
      const { error } = await supabase
        .from('user_orders')
        .update({ 
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', orderId);

      if (error) {
        throw error;
      }

      // Update local state
      setOrders(prev => prev.map(order => 
        order.id === orderId 
          ? { ...order, status: newStatus }
          : order
      ));

      // Update selected order if it's the one being updated
      if (selectedOrder?.id === orderId) {
        setSelectedOrder(prev => prev ? { ...prev, status: newStatus } : null);
      }

      alert('Status do pedido atualizado com sucesso!');
    } catch (error: any) {
      console.error('Error updating order status:', error);
      
      if (error.message?.includes('policy') || error.message?.includes('recursion')) {
        alert('Erro de permissão: Execute a migração para corrigir as políticas RLS.');
      } else {
        alert('Erro ao atualizar status: ' + error.message);
      }
    } finally {
      setIsUpdating(false);
    }
  };

  const updatePaymentStatus = async (transactionId: string, newStatus: 'paid' | 'cancelled' | 'expired') => {
    try {
      setIsUpdating(true);
      
      if (isDemoMode || transactionId.startsWith('demo-')) {
        // Demo mode - simulate update
        console.warn('Demo mode: simulating payment status update');
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Update the payment status in mock data
        setOrders(prev => prev.map(order => ({
          ...order,
          payment_transactions: order.payment_transactions?.map(tx => 
            tx.id === transactionId ? { ...tx, status: newStatus } : tx
          )
        })));
        
        alert('Status do pagamento atualizado com sucesso! (Modo demonstração)');
        return;
      }
      
      const success = await paymentService.updatePaymentStatus(transactionId, newStatus);
      
      if (!success) {
        throw new Error('Falha ao atualizar status do pagamento');
      }

      // Reload orders to get updated payment status
      await loadOrders();
      
      alert('Status do pagamento atualizado com sucesso!');
    } catch (error: any) {
      console.error('Error updating payment status:', error);
      
      if (error.message?.includes('policy') || error.message?.includes('recursion')) {
        alert('Erro de permissão: Execute a migração para corrigir as políticas RLS.');
      } else {
        alert('Erro ao atualizar status do pagamento: ' + error.message);
      }
    } finally {
      setIsUpdating(false);
    }
  };

  const filteredOrders = orders.filter(order => {
    const matchesSearch = 
      order.order_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer_email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    const statusOption = statusOptions.find(opt => opt.value === status);
    return statusOption?.color || 'gray';
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-gray-600" />
          <p className="text-gray-600">Carregando pedidos...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">
            Gerenciar Pedidos
            {isDemoMode && <span className="text-sm text-blue-600 ml-2">(Modo Demo)</span>}
          </h2>
          <p className="text-gray-600">Total de {filteredOrders.length} pedidos</p>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={loadOrders}
            disabled={loading}
            className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Atualizar</span>
          </button>
          
          <button className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            <Download className="w-4 h-4" />
            <span>Exportar</span>
          </button>
        </div>
      </div>

      {/* Demo Mode Notice */}
      {isDemoMode && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center">
            <AlertCircle className="w-5 h-5 text-blue-600 mr-2" />
            <p className="text-blue-700 text-sm">
              <strong>Modo Demonstração:</strong> Os dados exibidos são fictícios para fins de demonstração. 
              Configure o Supabase para usar dados reais.
            </p>
          </div>
        </div>
      )}

      {/* Database Error Notice */}
      {error && !isDemoMode && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <div className="flex items-start">
            <AlertCircle className="w-5 h-5 text-amber-600 mr-2 mt-0.5" />
            <div>
              <p className="text-amber-800 text-sm font-medium">Problema de Configuração</p>
              <p className="text-amber-700 text-sm mt-1">{error}</p>
              {error.includes('policy') && (
                <div className="mt-2 text-xs text-amber-600">
                  <p><strong>Solução:</strong> Execute a migração SQL para corrigir as políticas RLS:</p>
                  <code className="bg-amber-100 px-2 py-1 rounded mt-1 block">
                    supabase migration up
                  </code>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg shadow-md">
        <div className="flex flex-col sm:flex-row gap-4">
          {/* Search */}
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Buscar por número do pedido, cliente ou email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
            </div>
          </div>
          
          {/* Status Filter */}
          <div className="sm:w-48">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
            >
              {statusOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        {filteredOrders.length === 0 ? (
          <div className="text-center py-12">
            <Package className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg mb-2">Nenhum pedido encontrado</p>
            <p className="text-gray-400">Tente ajustar os filtros de busca</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Pedido
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Cliente
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Valor
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Pagamento
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Data
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredOrders.map((order) => {
                  const paymentTransaction = order.payment_transactions?.[0];
                  const paymentStatus = paymentTransaction?.status || 'pending';
                  
                  return (
                    <tr key={order.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm font-medium text-gray-900">
                            {order.order_number}
                          </div>
                          <div className="text-sm text-gray-500">
                            {order.payment_method.toUpperCase()}
                          </div>
                        </div>
                      </td>
                      
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm font-medium text-gray-900">
                            {order.customer_name}
                          </div>
                          <div className="text-sm text-gray-500">
                            {order.customer_email}
                          </div>
                        </div>
                      </td>
                      
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {formatCurrency(order.total_amount)}
                        </div>
                        {order.shipping_cost > 0 && (
                          <div className="text-sm text-gray-500">
                            + {formatCurrency(order.shipping_cost)} frete
                          </div>
                        )}
                      </td>
                      
                      <td className="px-6 py-4 whitespace-nowrap">
                        <select
                          value={order.status}
                          onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                          disabled={isUpdating}
                          className={`text-xs border rounded px-2 py-1 ${
                            getStatusColor(order.status) === 'green' ? 'bg-green-100 text-green-800 border-green-200' :
                            getStatusColor(order.status) === 'yellow' ? 'bg-yellow-100 text-yellow-800 border-yellow-200' :
                            getStatusColor(order.status) === 'blue' ? 'bg-blue-100 text-blue-800 border-blue-200' :
                            getStatusColor(order.status) === 'purple' ? 'bg-purple-100 text-purple-800 border-purple-200' :
                            getStatusColor(order.status) === 'red' ? 'bg-red-100 text-red-800 border-red-200' :
                            'bg-gray-100 text-gray-800 border-gray-200'
                          }`}
                        >
                          {statusOptions.slice(1).map(option => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </select>
                      </td>
                      
                      <td className="px-6 py-4 whitespace-nowrap">
                        {paymentTransaction ? (
                          <select
                            value={paymentStatus}
                            onChange={(e) => updatePaymentStatus(paymentTransaction.id, e.target.value as any)}
                            disabled={isUpdating}
                            className={`text-xs border rounded px-2 py-1 ${
                              paymentStatus === 'paid' ? 'bg-green-100 text-green-800 border-green-200' :
                              paymentStatus === 'pending' ? 'bg-yellow-100 text-yellow-800 border-yellow-200' :
                              paymentStatus === 'cancelled' ? 'bg-red-100 text-red-800 border-red-200' :
                              'bg-gray-100 text-gray-800 border-gray-200'
                            }`}
                          >
                            <option value="pending">Pendente</option>
                            <option value="paid">Pago</option>
                            <option value="cancelled">Cancelado</option>
                            <option value="expired">Expirado</option>
                          </select>
                        ) : (
                          <span className="text-xs text-gray-500">Sem pagamento</span>
                        )}
                      </td>
                      
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {formatDate(order.created_at)}
                      </td>
                      
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="text-blue-600 hover:text-blue-900 mr-3"
                          title="Ver detalhes"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Order Details Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setSelectedOrder(null)} />
            
            <div className="relative bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden">
              <div className="flex items-center justify-between p-6 border-b">
                <h3 className="text-lg font-semibold text-gray-900">
                  Detalhes do Pedido {selectedOrder.order_number}
                  {isDemoMode && <span className="text-sm text-blue-600 ml-2">(Demo)</span>}
                </h3>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Customer Info */}
                  <div className="space-y-4">
                    <h4 className="font-semibold text-gray-900 flex items-center">
                      <User className="w-4 h-4 mr-2" />
                      Informações do Cliente
                    </h4>
                    <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                      <p><strong>Nome:</strong> {selectedOrder.customer_name}</p>
                      <p><strong>Email:</strong> {selectedOrder.customer_email}</p>
                      {selectedOrder.shipping_address && (
                        <div>
                          <strong>Endereço:</strong>
                          <p className="text-sm text-gray-600 mt-1">
                            {selectedOrder.shipping_address.street}, {selectedOrder.shipping_address.number}
                            {selectedOrder.shipping_address.complement && `, ${selectedOrder.shipping_address.complement}`}
                            <br />
                            {selectedOrder.shipping_address.neighborhood} - {selectedOrder.shipping_address.city}/{selectedOrder.shipping_address.state}
                            <br />
                            CEP: {selectedOrder.shipping_address.zipCode}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Order Info */}
                  <div className="space-y-4">
                    <h4 className="font-semibold text-gray-900 flex items-center">
                      <Package className="w-4 h-4 mr-2" />
                      Informações do Pedido
                    </h4>
                    <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                      <p><strong>Data:</strong> {formatDate(selectedOrder.created_at)}</p>
                      <p><strong>Status:</strong> 
                        <span className={`ml-2 px-2 py-1 rounded-full text-xs ${
                          getStatusColor(selectedOrder.status) === 'green' ? 'bg-green-100 text-green-800' :
                          getStatusColor(selectedOrder.status) === 'yellow' ? 'bg-yellow-100 text-yellow-800' :
                          getStatusColor(selectedOrder.status) === 'blue' ? 'bg-blue-100 text-blue-800' :
                          getStatusColor(selectedOrder.status) === 'purple' ? 'bg-purple-100 text-purple-800' :
                          getStatusColor(selectedOrder.status) === 'red' ? 'bg-red-100 text-red-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {statusOptions.find(opt => opt.value === selectedOrder.status)?.label}
                        </span>
                      </p>
                      <p><strong>Pagamento:</strong> {selectedOrder.payment_method.toUpperCase()}</p>
                      <p><strong>Total:</strong> {formatCurrency(selectedOrder.total_amount)}</p>
                    </div>
                  </div>
                </div>
                
                {/* Items */}
                <div className="mt-6">
                  <h4 className="font-semibold text-gray-900 mb-4">Itens do Pedido</h4>
                  <div className="space-y-3">
                    {selectedOrder.items.map((item, index) => (
                      <div key={index} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                        {item.product_image && (
                          <img
                            src={item.product_image}
                            alt={item.product_name}
                            className="w-16 h-16 object-cover rounded"
                          />
                        )}
                        <div className="flex-1">
                          <h5 className="font-medium text-gray-900">{item.product_name}</h5>
                          <p className="text-sm text-gray-600">
                            Tamanho: {item.size} • Cor: {item.color}
                          </p>
                          <p className="text-sm text-gray-600">
                            Quantidade: {item.quantity} • Preço unitário: {formatCurrency(item.unit_price)}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">{formatCurrency(item.total_price)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrderManagement;