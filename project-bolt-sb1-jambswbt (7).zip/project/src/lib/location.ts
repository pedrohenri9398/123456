export interface Address {
  cep: string;
  logradouro: string;
  complemento?: string;
  bairro: string;
  localidade: string;
  uf: string;
  ibge?: string;
  gia?: string;
  ddd?: string;
  siafi?: string;
}

export interface LocationData {
  address: Address;
  coordinates?: {
    lat: number;
    lng: number;
  };
  formattedAddress: string;
}

class LocationService {
  private static instance: LocationService;

  private constructor() {}

  static getInstance(): LocationService {
    if (!LocationService.instance) {
      LocationService.instance = new LocationService();
    }
    return LocationService.instance;
  }

  // Buscar endereço por CEP usando ViaCEP
  async searchByCEP(cep: string): Promise<Address | null> {
    try {
      // Remove caracteres não numéricos
      const cleanCEP = cep.replace(/\D/g, '');
      
      if (cleanCEP.length !== 8) {
        throw new Error('CEP deve ter 8 dígitos');
      }

      const response = await fetch(`https://viacep.com.br/ws/${cleanCEP}/json/`);
      
      if (!response.ok) {
        throw new Error('Erro ao buscar CEP');
      }

      const data = await response.json();
      
      if (data.erro) {
        throw new Error('CEP não encontrado');
      }

      return {
        cep: data.cep,
        logradouro: data.logradouro,
        complemento: data.complemento,
        bairro: data.bairro,
        localidade: data.localidade,
        uf: data.uf,
        ibge: data.ibge,
        gia: data.gia,
        ddd: data.ddd,
        siafi: data.siafi
      };
    } catch (error) {
      console.error('Erro ao buscar CEP:', error);
      return null;
    }
  }

  // Obter coordenadas usando Nominatim (OpenStreetMap)
  async getCoordinates(address: string): Promise<{ lat: number; lng: number } | null> {
    try {
      const encodedAddress = encodeURIComponent(address);
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodedAddress}&limit=1&countrycodes=br`
      );

      if (!response.ok) {
        throw new Error('Erro ao buscar coordenadas');
      }

      const data = await response.json();
      
      if (data.length === 0) {
        return null;
      }

      return {
        lat: parseFloat(data[0].lat),
        lng: parseFloat(data[0].lon)
      };
    } catch (error) {
      console.error('Erro ao buscar coordenadas:', error);
      return null;
    }
  }

  // Obter localização atual do usuário
  async getCurrentLocation(): Promise<{ lat: number; lng: number } | null> {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        console.warn('Geolocalização não suportada');
        resolve(null);
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.warn('Erro ao obter localização:', error);
          resolve(null);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000 // 5 minutos
        }
      );
    });
  }

  // Buscar endereço por coordenadas (geocodificação reversa)
  async reverseGeocode(lat: number, lng: number): Promise<Address | null> {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`
      );

      if (!response.ok) {
        throw new Error('Erro ao buscar endereço');
      }

      const data = await response.json();
      
      if (!data.address) {
        return null;
      }

      const addr = data.address;
      
      return {
        cep: addr.postcode || '',
        logradouro: addr.road || addr.pedestrian || '',
        bairro: addr.suburb || addr.neighbourhood || addr.quarter || '',
        localidade: addr.city || addr.town || addr.village || '',
        uf: this.getStateAbbreviation(addr.state || ''),
        complemento: addr.house_number || ''
      };
    } catch (error) {
      console.error('Erro na geocodificação reversa:', error);
      return null;
    }
  }

  // Converter nome do estado para sigla
  private getStateAbbreviation(stateName: string): string {
    const states: { [key: string]: string } = {
      'acre': 'AC',
      'alagoas': 'AL',
      'amapá': 'AP',
      'amazonas': 'AM',
      'bahia': 'BA',
      'ceará': 'CE',
      'distrito federal': 'DF',
      'espírito santo': 'ES',
      'goiás': 'GO',
      'maranhão': 'MA',
      'mato grosso': 'MT',
      'mato grosso do sul': 'MS',
      'minas gerais': 'MG',
      'pará': 'PA',
      'paraíba': 'PB',
      'paraná': 'PR',
      'pernambuco': 'PE',
      'piauí': 'PI',
      'rio de janeiro': 'RJ',
      'rio grande do norte': 'RN',
      'rio grande do sul': 'RS',
      'rondônia': 'RO',
      'roraima': 'RR',
      'santa catarina': 'SC',
      'são paulo': 'SP',
      'sergipe': 'SE',
      'tocantins': 'TO'
    };

    return states[stateName.toLowerCase()] || stateName.toUpperCase();
  }

  // Calcular distância entre dois pontos (em km)
  calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 6371; // Raio da Terra em km
    const dLat = this.toRad(lat2 - lat1);
    const dLng = this.toRad(lng2 - lng1);
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private toRad(value: number): number {
    return value * Math.PI / 180;
  }

  // Calcular frete baseado na distância
  calculateShipping(distance: number): { cost: number; estimatedDays: number } {
    // Brasília, DF (nossa loja) como ponto de referência
    const baseCost = 15.90;
    const costPerKm = 0.02;
    
    let cost = baseCost + (distance * costPerKm);
    let estimatedDays = 3;

    // Ajustar baseado na distância
    if (distance > 1000) {
      estimatedDays = 7;
      cost += 10; // Taxa adicional para longas distâncias
    } else if (distance > 500) {
      estimatedDays = 5;
      cost += 5;
    }

    // Frete grátis acima de R$ 200
    return {
      cost: Math.round(cost * 100) / 100,
      estimatedDays
    };
  }

  // Formatar CEP
  formatCEP(cep: string): string {
    const clean = cep.replace(/\D/g, '');
    if (clean.length === 8) {
      return `${clean.slice(0, 5)}-${clean.slice(5)}`;
    }
    return cep;
  }

  // Validar CEP
  isValidCEP(cep: string): boolean {
    const clean = cep.replace(/\D/g, '');
    return clean.length === 8;
  }
}

export const locationService = LocationService.getInstance();