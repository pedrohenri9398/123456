import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Check if we're in demo mode (missing or placeholder Supabase environment variables)
const isValidUrl = (url: string) => {
  try {
    new URL(url);
    return !url.includes('your_supabase_url_here');
  } catch {
    return false;
  }
};

const isValidKey = (key: string) => {
  return key && !key.includes('your_supabase_anon_key_here');
};

export const isDemoMode = !supabaseUrl || !supabaseAnonKey || !isValidUrl(supabaseUrl) || !isValidKey(supabaseAnonKey);

// Create Supabase client or dummy client for demo mode
export const supabase = isDemoMode 
  ? createClient('https://demo.supabase.co', 'demo-key') // Dummy client for demo mode
  : createClient(supabaseUrl, supabaseAnonKey);

// Log the current mode
if (isDemoMode) {
  console.log('🎭 Running in DEMO MODE - No Supabase configuration found');
  console.log('📝 Use demo credentials or create new accounts for testing');
} else {
  console.log('🔄 Running in PRODUCTION MODE with Supabase');
}

// Types for database tables
export interface Database {
  public: {
    Tables: {
      user_profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string | null;
          phone: string | null;
          birth_date: string | null;
          created_at: string | null;
          updated_at: string | null;
        };
        Insert: {
          id: string;
          email: string;
          full_name?: string | null;
          phone?: string | null;
          birth_date?: string | null;
          created_at?: string | null;
          updated_at?: string | null;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string | null;
          phone?: string | null;
          birth_date?: string | null;
          created_at?: string | null;
          updated_at?: string | null;
        };
      };
      admin_users: {
        Row: {
          id: string;
          email: string;
          full_name: string;
          permissions: string[] | null;
          is_super_admin: boolean | null;
          created_at: string | null;
          updated_at: string | null;
        };
        Insert: {
          id: string;
          email: string;
          full_name: string;
          permissions?: string[] | null;
          is_super_admin?: boolean | null;
          created_at?: string | null;
          updated_at?: string | null;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string;
          permissions?: string[] | null;
          is_super_admin?: boolean | null;
          created_at?: string | null;
          updated_at?: string | null;
        };
      };
      user_addresses: {
        Row: {
          id: string;
          user_id: string;
          street: string;
          number: string;
          complement: string | null;
          neighborhood: string;
          city: string;
          state: string;
          zip_code: string;
          is_default: boolean | null;
          created_at: string | null;
          updated_at: string | null;
        };
        Insert: {
          id?: string;
          user_id: string;
          street: string;
          number: string;
          complement?: string | null;
          neighborhood: string;
          city: string;
          state: string;
          zip_code: string;
          is_default?: boolean | null;
          created_at?: string | null;
          updated_at?: string | null;
        };
        Update: {
          id?: string;
          user_id?: string;
          street?: string;
          number?: string;
          complement?: string | null;
          neighborhood?: string;
          city?: string;
          state?: string;
          zip_code?: string;
          is_default?: boolean | null;
          created_at?: string | null;
          updated_at?: string | null;
        };
      };
      user_orders: {
        Row: {
          id: string;
          user_id: string;
          order_number: string;
          items: any;
          total_amount: number;
          shipping_cost: number | null;
          status: string | null;
          payment_method: string;
          shipping_address: any;
          customer_name: string;
          customer_email: string;
          created_at: string | null;
          updated_at: string | null;
        };
        Insert: {
          id?: string;
          user_id: string;
          order_number: string;
          items: any;
          total_amount: number;
          shipping_cost?: number | null;
          status?: string | null;
          payment_method: string;
          shipping_address: any;
          customer_name: string;
          customer_email: string;
          created_at?: string | null;
          updated_at?: string | null;
        };
        Update: {
          id?: string;
          user_id?: string;
          order_number?: string;
          items?: any;
          total_amount?: number;
          shipping_cost?: number | null;
          status?: string | null;
          payment_method?: string;
          shipping_address?: any;
          customer_name?: string;
          customer_email?: string;
          created_at?: string | null;
          updated_at?: string | null;
        };
      };
    };
  };
}