interface PaymentItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

interface CustomerData {
  name: string;
  email: string;
  phone?: string;
}

interface PaymentResponse {
  success: boolean;
  payment_id?: string;
  status?: string;
  amount?: number;
  pix?: {
    qr_code: string;
    qr_code_base64: string;
    ticket_url?: string;
  };
  expires_at?: Date;
  external_reference?: string;
  error?: string;
}

interface PaymentStatusResponse {
  success: boolean;
  payment_id?: string;
  status?: string;
  status_detail?: string;
  amount?: number;
  date_approved?: string;
  external_reference?: string;
  error?: string;
}

class MercadoPagoService {
  private apiUrl: string;

  constructor() {
    this.apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
  }

  async createPayment(
    items: PaymentItem[],
    customerData: CustomerData,
    orderNumber?: string
  ): Promise<PaymentResponse> {
    try {
      console.log('Creating payment with API URL:', this.apiUrl);
      
      const response = await fetch(`${this.apiUrl}/api/create-payment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          items,
          customerData,
          orderNumber
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Payment API error response:', errorData);
        throw new Error(errorData.error || `Error creating payment: ${response.status}`);
      }

      const data = await response.json();
      console.log('Payment created successfully:', data);
      return data;
    } catch (error: any) {
      console.error('Error creating payment:', error);
      throw error;
    }
  }

  async checkPaymentStatus(paymentId: string): Promise<PaymentStatusResponse> {
    try {
      const response = await fetch(`${this.apiUrl}/api/payment-status/${paymentId}`);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Error checking status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error checking status:', error);
      throw error;
    }
  }

  async checkServerHealth(): Promise<boolean> {
    try {
      console.log('Checking server health at:', `${this.apiUrl}/api/health`);
      const response = await fetch(`${this.apiUrl}/api/health`);
      
      if (!response.ok) {
        console.error('Server health check failed with status:', response.status);
        return false;
      }
      
      const data = await response.json();
      console.log('Server health response:', data);
      return data.status === 'OK';
    } catch (error) {
      console.error('Error checking server health:', error);
      return false;
    }
  }
}

export const mercadoPagoService = new MercadoPagoService();
export type { PaymentItem, CustomerData, PaymentResponse, PaymentStatusResponse };