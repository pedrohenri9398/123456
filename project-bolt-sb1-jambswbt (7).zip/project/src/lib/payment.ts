import { PaymentProvider, PaymentResponse, PaymentTransaction, CreditCardData } from '../types/payment';
import { supabase, isDemoMode } from './supabase';
import QRCode from 'qrcode';

export class PaymentService {
  private static instance: PaymentService;
  private providers: PaymentProvider[] = [];

  private constructor() {}

  static getInstance(): PaymentService {
    if (!PaymentService.instance) {
      PaymentService.instance = new PaymentService();
    }
    return PaymentService.instance;
  }

  // Initialize payment providers from database or config
  async initialize() {
    try {
      // Load payment configuration from database or environment
      const config = await this.loadPaymentConfig();
      this.providers = config.providers;
    } catch (error) {
      console.error('Error initializing payment service:', error);
    }
  }

  private async loadPaymentConfig() {
    return {
      providers: [
        {
          id: 'itau',
          name: 'Itaú',
          type: 'itau' as const,
          enabled: true,
          config: {
            qrCodeUrl: '/867cde4d-21d3-453c-9722-0bb4bcc05945.jpg',
            environment: 'production' as const
          }
        },
        {
          id: 'mercadopago',
          name: 'Mercado Pago',
          type: 'mercadopago' as const,
          enabled: !!import.meta.env.VITE_MERCADOPAGO_ACCESS_TOKEN,
          config: {
            accessToken: import.meta.env.VITE_MERCADOPAGO_ACCESS_TOKEN || '',
            publicKey: import.meta.env.VITE_MERCADOPAGO_PUBLIC_KEY || '',
            environment: 'sandbox' as const
          }
        },
        {
          id: 'appmax',
          name: 'Appmax',
          type: 'appmax' as const,
          enabled: !!import.meta.env.VITE_APPMAX_ACCESS_TOKEN,
          config: {
            accessToken: import.meta.env.VITE_APPMAX_ACCESS_TOKEN || '',
            environment: 'sandbox' as const
          }
        },
        {
          id: 'pagarme',
          name: 'Pagar.me',
          type: 'pagarme' as const,
          enabled: !!import.meta.env.VITE_PAGARME_ACCESS_TOKEN,
          config: {
            accessToken: import.meta.env.VITE_PAGARME_ACCESS_TOKEN || '',
            environment: 'sandbox' as const
          }
        },
        {
          id: 'pagseguro',
          name: 'PagSeguro',
          type: 'pagseguro' as const,
          enabled: !!import.meta.env.VITE_PAGSEGURO_ACCESS_TOKEN,
          config: {
            accessToken: import.meta.env.VITE_PAGSEGURO_ACCESS_TOKEN || '',
            environment: 'sandbox' as const
          }
        }
      ]
    };
  }

  // Create PIX payment
  async createPixPayment(orderId: string, amount: number, description: string): Promise<PaymentResponse> {
    try {
      console.log('🏦 Creating PIX payment with Itaú QR Code');
      return this.createItauPixPayment(orderId, amount, description);
    } catch (error) {
      console.error('Error creating PIX payment:', error);
      return {
        success: false,
        error: 'Erro ao criar pagamento PIX'
      };
    }
  }

  // Create Credit Card payment
  async createCreditCardPayment(
    orderId: string, 
    amount: number, 
    description: string, 
    cardData: CreditCardData,
    customerData: any
  ): Promise<PaymentResponse> {
    try {
      if (isDemoMode) {
        console.warn('🎭 DEMO MODE: Creating simulated Credit Card payment');
        return this.createDemoCreditCardPayment(orderId, amount, description, cardData);
      }

      const enabledProvider = this.providers.find(p => p.enabled && p.type !== 'itau');
      
      if (enabledProvider) {
        return this.createRealCreditCardPayment(orderId, amount, description, cardData, customerData, enabledProvider);
      } else {
        console.warn('⚠️ No payment provider configured, using demo mode');
        return this.createDemoCreditCardPayment(orderId, amount, description, cardData);
      }
    } catch (error) {
      console.error('Error creating credit card payment:', error);
      return {
        success: false,
        error: 'Erro ao processar cartão de crédito'
      };
    }
  }

  private async createItauPixPayment(orderId: string, amount: number, description: string): Promise<PaymentResponse> {
    const pixQrCode = '/867cde4d-21d3-453c-9722-0bb4bcc05945.jpg';
    const pixCode = this.generateItauPixCode(amount);
    
    const transaction: Omit<PaymentTransaction, 'id' | 'createdAt' | 'updatedAt'> = {
      orderId,
      method: 'pix',
      amount,
      status: 'pending',
      pixCode,
      pixQrCode,
      expiresAt: new Date(Date.now() + 30 * 60 * 1000), // 30 minutes
      providerData: {
        description,
        provider: 'Itaú',
        bank: 'itau',
        realPayment: true,
        instructions: 'Pagamento via PIX Itaú. Escaneie o QR Code ou use o código copia e cola.'
      }
    };

    if (isDemoMode) {
      const mockTransactionId = 'itau-tx-' + Date.now();
      localStorage.setItem(`demo_transaction_${mockTransactionId}`, JSON.stringify({
        ...transaction,
        id: mockTransactionId,
        createdAt: new Date(),
        updatedAt: new Date()
      }));

      return {
        success: true,
        transactionId: mockTransactionId,
        pixCode,
        pixQrCode,
        expiresAt: transaction.expiresAt
      };
    }

    try {
      const { data, error } = await supabase
        .from('payment_transactions')
        .insert(transaction)
        .select()
        .single();

      if (error) {
        throw error;
      }

      return {
        success: true,
        transactionId: data.id,
        pixCode,
        pixQrCode,
        expiresAt: transaction.expiresAt
      };
    } catch (dbError) {
      console.warn('Database error, falling back to demo mode:', dbError);
      
      const mockTransactionId = 'itau-tx-' + Date.now();
      localStorage.setItem(`demo_transaction_${mockTransactionId}`, JSON.stringify({
        ...transaction,
        id: mockTransactionId,
        createdAt: new Date(),
        updatedAt: new Date()
      }));

      return {
        success: true,
        transactionId: mockTransactionId,
        pixCode,
        pixQrCode,
        expiresAt: transaction.expiresAt
      };
    }
  }

  private async createDemoCreditCardPayment(
    orderId: string, 
    amount: number, 
    description: string, 
    cardData: CreditCardData
  ): Promise<PaymentResponse> {
    // Simulate credit card processing
    await new Promise(resolve => setTimeout(resolve, 2000));

    const transaction: Omit<PaymentTransaction, 'id' | 'createdAt' | 'updatedAt'> = {
      orderId,
      method: 'credit_card',
      amount,
      status: 'paid', // Demo cards are always approved
      creditCardData: {
        installments: cardData.installments,
        brand: this.getCardBrand(cardData.number),
        lastFourDigits: cardData.number.slice(-4)
      },
      providerData: {
        description,
        demoPayment: true,
        authorizationCode: 'DEMO' + Date.now(),
        instructions: 'Este é um pagamento de demonstração. Nenhuma transação real foi processada.'
      }
    };

    const mockTransactionId = 'demo-cc-' + Date.now();
    localStorage.setItem(`demo_transaction_${mockTransactionId}`, JSON.stringify({
      ...transaction,
      id: mockTransactionId,
      createdAt: new Date(),
      updatedAt: new Date()
    }));

    return {
      success: true,
      transactionId: mockTransactionId,
      creditCardData: {
        installments: cardData.installments,
        authorizationCode: 'DEMO' + Date.now()
      }
    };
  }

  private async createRealCreditCardPayment(
    orderId: string, 
    amount: number, 
    description: string, 
    cardData: CreditCardData,
    customerData: any,
    provider: PaymentProvider
  ): Promise<PaymentResponse> {
    console.log(`🔄 Creating real Credit Card payment with ${provider.name}`);
    
    // In production, this would call the actual payment provider API
    // For now, simulate the real flow but still use demo data
    const transaction: Omit<PaymentTransaction, 'id' | 'createdAt' | 'updatedAt'> = {
      orderId,
      method: 'credit_card',
      amount,
      status: 'paid',
      creditCardData: {
        installments: cardData.installments,
        brand: this.getCardBrand(cardData.number),
        lastFourDigits: cardData.number.slice(-4)
      },
      providerData: {
        description,
        provider: provider.name,
        realPayment: true,
        authorizationCode: 'AUTH' + Date.now()
      }
    };

    const { data, error } = await supabase
      .from('payment_transactions')
      .insert(transaction)
      .select()
      .single();

    if (error) {
      throw error;
    }

    return {
      success: true,
      transactionId: data.id,
      creditCardData: {
        installments: cardData.installments,
        authorizationCode: 'AUTH' + Date.now()
      }
    };
  }

  // Create Boleto payment
  async createBoletoPayment(orderId: string, amount: number, description: string, customerData: any): Promise<PaymentResponse> {
    try {
      if (isDemoMode) {
        console.warn('🎭 DEMO MODE: Creating simulated Boleto payment');
        return this.createDemoBoletoPayment(orderId, amount, description, customerData);
      }

      const enabledProvider = this.providers.find(p => p.enabled && p.type !== 'itau');
      
      if (enabledProvider) {
        return this.createRealBoletoPayment(orderId, amount, description, customerData, enabledProvider);
      } else {
        console.warn('⚠️ No payment provider configured, using demo mode');
        return this.createDemoBoletoPayment(orderId, amount, description, customerData);
      }
    } catch (error) {
      console.error('Error creating boleto payment:', error);
      return {
        success: false,
        error: 'Erro ao criar boleto'
      };
    }
  }

  private async createDemoBoletoPayment(orderId: string, amount: number, description: string, customerData: any): Promise<PaymentResponse> {
    const boletoBarcode = this.generateMockBoletoBarcode();
    const boletoUrl = this.generateMockBoletoUrl(amount, boletoBarcode, customerData);
    
    const transaction: Omit<PaymentTransaction, 'id' | 'createdAt' | 'updatedAt'> = {
      orderId,
      method: 'boleto',
      amount,
      status: 'pending',
      boletoUrl,
      boletoBarcode,
      expiresAt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days
      providerData: {
        description,
        customerData,
        demoPayment: true,
        instructions: 'Este é um boleto de demonstração. Nenhuma transação real será processada.'
      }
    };

    const mockTransactionId = 'demo-tx-' + Date.now();
    localStorage.setItem(`demo_transaction_${mockTransactionId}`, JSON.stringify({
      ...transaction,
      id: mockTransactionId,
      createdAt: new Date(),
      updatedAt: new Date()
    }));

    return {
      success: true,
      transactionId: mockTransactionId,
      boletoUrl,
      boletoBarcode,
      expiresAt: transaction.expiresAt
    };
  }

  private async createRealBoletoPayment(orderId: string, amount: number, description: string, customerData: any, provider: PaymentProvider): Promise<PaymentResponse> {
    console.log(`🔄 Creating real Boleto payment with ${provider.name}`);
    
    const boletoBarcode = this.generateMockBoletoBarcode();
    const boletoUrl = this.generateMockBoletoUrl(amount, boletoBarcode, customerData);
    
    const transaction: Omit<PaymentTransaction, 'id' | 'createdAt' | 'updatedAt'> = {
      orderId,
      method: 'boleto',
      amount,
      status: 'pending',
      boletoUrl,
      boletoBarcode,
      expiresAt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
      providerData: {
        description,
        customerData,
        provider: provider.name,
        realPayment: true
      }
    };

    const { data, error } = await supabase
      .from('payment_transactions')
      .insert(transaction)
      .select()
      .single();

    if (error) {
      throw error;
    }

    return {
      success: true,
      transactionId: data.id,
      boletoUrl,
      boletoBarcode,
      expiresAt: transaction.expiresAt
    };
  }

  // Check payment status
  async checkPaymentStatus(transactionId: string): Promise<PaymentTransaction | null> {
    try {
      if (isDemoMode || transactionId.startsWith('demo-') || transactionId.startsWith('itau-tx-')) {
        const stored = localStorage.getItem(`demo_transaction_${transactionId}`);
        return stored ? JSON.parse(stored) : null;
      }

      const { data, error } = await supabase
        .from('payment_transactions')
        .select('*')
        .eq('id', transactionId)
        .single();

      if (error) {
        throw error;
      }

      return data;
    } catch (error) {
      console.error('Error checking payment status:', error);
      return null;
    }
  }

  // Update payment status (for admin use)
  async updatePaymentStatus(transactionId: string, status: 'paid' | 'cancelled' | 'expired'): Promise<boolean> {
    try {
      if (isDemoMode || transactionId.startsWith('demo-') || transactionId.startsWith('itau-tx-')) {
        const stored = localStorage.getItem(`demo_transaction_${transactionId}`);
        if (stored) {
          const transaction = JSON.parse(stored);
          transaction.status = status;
          transaction.updatedAt = new Date();
          if (status === 'paid') {
            transaction.paidAt = new Date();
          }
          localStorage.setItem(`demo_transaction_${transactionId}`, JSON.stringify(transaction));
        }
        return true;
      }

      const updateData: any = {
        status,
        updated_at: new Date().toISOString()
      };

      if (status === 'paid') {
        updateData.paid_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from('payment_transactions')
        .update(updateData)
        .eq('id', transactionId);

      if (error) {
        throw error;
      }

      return true;
    } catch (error) {
      console.error('Error updating payment status:', error);
      return false;
    }
  }

  // Helper methods
  private getCardBrand(number: string): string {
    const cleanNumber = number.replace(/\s/g, '');
    
    if (/^4/.test(cleanNumber)) return 'Visa';
    if (/^5[1-5]/.test(cleanNumber)) return 'Mastercard';
    if (/^3[47]/.test(cleanNumber)) return 'American Express';
    if (/^6/.test(cleanNumber)) return 'Discover';
    if (/^35(2[89]|[3-8][0-9])/.test(cleanNumber)) return 'JCB';
    if (/^(4011|4312|4389|4514|4573)/.test(cleanNumber)) return 'Elo';
    
    return 'Desconhecido';
  }

  private generateItauPixCode(amount: number): string {
    const timestamp = Date.now().toString();
    const amountStr = amount.toFixed(2).replace('.', '');
    return `00020126580014br.gov.bcb.pix0136itau${timestamp}520400005303986540${amountStr.length}${amountStr}5802BR5925Comfydance Calcados Danca6009SAO PAULO62070503***6304ITAU`;
  }

  private generateMockBoletoBarcode(): string {
    const timestamp = Date.now().toString().slice(-10);
    return `34191${timestamp}123456789012345678901234567890123456789`;
  }

  private generateMockBoletoUrl(amount: number, barcode: string, customerData: any): string {
    const expiryDate = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR');
    
    const boletoHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Boleto Bancário - Comfydance</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; }
          .header { text-align: center; margin-bottom: 30px; }
          .info { margin: 20px 0; }
          .barcode { font-family: monospace; font-size: 12px; margin: 20px 0; }
          .footer { margin-top: 30px; font-size: 12px; color: #666; }
          .demo-notice { background: #e3f2fd; padding: 15px; border-left: 4px solid #2196f3; margin: 20px 0; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Boleto Bancário</h1>
          <h2>Comfydance - Calçados de Dança</h2>
        </div>
        
        <div class="demo-notice">
          <strong>⚠️ DEMONSTRAÇÃO:</strong> Este é um boleto fictício para fins de demonstração. 
          Nenhuma transação real será processada.
        </div>
        
        <div class="info">
          <p><strong>Beneficiário:</strong> Comfydance Calçados de Dança LTDA</p>
          <p><strong>Pagador:</strong> ${customerData.fullName || customerData.name}</p>
          <p><strong>Valor:</strong> R$ ${amount.toFixed(2)}</p>
          <p><strong>Vencimento:</strong> ${expiryDate}</p>
        </div>
        
        <div class="barcode">
          <p><strong>Código de Barras:</strong></p>
          <p>${barcode}</p>
        </div>
        
        <div class="footer">
          <p>Este boleto pode ser pago em qualquer banco, lotérica ou internet banking até a data de vencimento.</p>
          <p>Após o vencimento, o boleto perde a validade.</p>
        </div>
      </body>
      </html>
    `;
    
    return `data:text/html;charset=utf-8,${encodeURIComponent(boletoHtml)}`;
  }

  // Get available payment methods
  getAvailablePaymentMethods() {
    const hasItauQr = true;
    const hasOtherProvider = this.providers.some(p => p.enabled && p.type !== 'itau');
    
    return [
      {
        id: 'pix',
        type: 'pix' as const,
        name: 'PIX',
        enabled: true,
        discount: 5,
        description: 'Pagamento instantâneo via PIX Itaú',
        provider: 'Itaú'
      },
      {
        id: 'credit_card',
        type: 'credit_card' as const,
        name: 'Cartão de Crédito',
        enabled: true,
        discount: 0,
        installments: 10,
        description: 'Parcelamento em até 10x'
      },
      {
        id: 'boleto',
        type: 'boleto' as const,
        name: 'Boleto Bancário',
        enabled: true,
        discount: 0,
        description: hasOtherProvider ? 'Boleto bancário com vencimento em 3 dias' : 'Boleto (Demonstração)'
      }
    ];
  }
}

export const paymentService = PaymentService.getInstance();