import React, { useState } from 'react';
import { CartProvider } from './contexts/CartContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { SiteCustomizationProvider } from './contexts/SiteCustomizationContext';
import { ProductProvider } from './contexts/ProductContext';
import Header from './components/Layout/Header';
import Footer from './components/Layout/Footer';
import CartSidebar from './components/Cart/CartSidebar';
import ProductModal from './components/Product/ProductModal';
import Home from './pages/Home';
import Shop from './pages/Shop';
import About from './pages/About';
import Contact from './pages/Contact';
import Account from './pages/Account';
import Checkout from './pages/Checkout';
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';
import ProductDetail from './pages/ProductDetail';
import OrderTrackingPage from './pages/OrderTracking';
import OrderView from './pages/OrderView';
import MyOrders from './pages/MyOrders';
import InstitutionalPages from './pages/InstitutionalPages';

function AppContent() {
  const { isAdmin } = useAuth();
  const [currentPage, setCurrentPage] = useState('home');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showAdminDashboard, setShowAdminDashboard] = useState(false);
  const [orderViewId, setOrderViewId] = useState<string | null>(null);

  // Check for admin access in URL
  React.useEffect(() => {
    const path = window.location.pathname;
    if (path === '/admin' || path.includes('/admin')) {
      if (isAdmin) {
        setShowAdminDashboard(true);
      } else {
        setShowAdminLogin(true);
      }
    }
  }, [isAdmin]);

  const handleNavigate = (page: string) => {
    // Handle special pages
    if (page === 'admin') {
      if (isAdmin) {
        setShowAdminDashboard(true);
      } else {
        setShowAdminLogin(true);
      }
      return;
    }

    // Handle order view pages
    if (page.startsWith('order-view-')) {
      const orderNumber = page.replace('order-view-', '');
      setOrderViewId(orderNumber);
      setCurrentPage('order-view');
      setShowAdminLogin(false);
      setShowAdminDashboard(false);
      window.scrollTo(0, 0);
      return;
    }

    // Handle product detail pages
    if (page.startsWith('product-')) {
      const productId = page.replace('product-', '');
      setSelectedProduct(productId);
      setCurrentPage('product-detail');
      setShowAdminLogin(false);
      setShowAdminDashboard(false);
      window.scrollTo(0, 0);
      return;
    }

    // Handle institutional pages
    if (page.startsWith('institutional-')) {
      setCurrentPage(page);
      setShowAdminLogin(false);
      setShowAdminDashboard(false);
      window.scrollTo(0, 0);
      return;
    }
    
    setCurrentPage(page);
    setShowAdminLogin(false);
    setShowAdminDashboard(false);
    setOrderViewId(null);
    window.scrollTo(0, 0);
  };

  const handleProductClick = (productId: string) => {
    setSelectedProduct(productId);
    setCurrentPage('product-detail');
    window.scrollTo(0, 0);
  };

  const handleCartOpen = () => {
    setIsCartOpen(true);
  };

  const handleCartClose = () => {
    setIsCartOpen(false);
  };

  const handleCheckout = () => {
    setIsCartOpen(false);
    setCurrentPage('checkout');
  };

  const handleProductModalClose = () => {
    setIsProductModalOpen(false);
    setSelectedProduct(null);
  };

  const handleAdminLoginSuccess = () => {
    setShowAdminLogin(false);
    setShowAdminDashboard(true);
    window.history.pushState({}, '', '/admin');
  };

  const handleAdminLogout = () => {
    setShowAdminDashboard(false);
    setShowAdminLogin(false);
    setCurrentPage('home');
    window.history.pushState({}, '', '/');
  };

  const handleBackToShop = () => {
    setCurrentPage('shop');
    setSelectedProduct(null);
  };

  const handleBackToHome = () => {
    setCurrentPage('home');
    setSelectedProduct(null);
    setOrderViewId(null);
  };

  // Show admin login if requested
  if (showAdminLogin) {
    return <AdminLogin onLoginSuccess={handleAdminLoginSuccess} />;
  }

  // Show admin dashboard if logged in as admin
  if (showAdminDashboard && isAdmin) {
    return <AdminDashboard onLogout={handleAdminLogout} />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home onNavigate={handleNavigate} onProductClick={handleProductClick} />;
      case 'shop':
        return <Shop onProductClick={handleProductClick} />;
      case 'about':
        return <About onNavigate={handleNavigate} />;
      case 'contact':
        return <Contact />;
      case 'account':
        return <Account onNavigate={handleNavigate} />;
      case 'checkout':
        return <Checkout onBack={() => setCurrentPage('shop')} onNavigate={handleNavigate} />;
      case 'product-detail':
        return selectedProduct ? (
          <ProductDetail 
            productId={selectedProduct} 
            onBack={handleBackToShop}
            onNavigate={handleNavigate}
          />
        ) : (
          <Shop onProductClick={handleProductClick} />
        );
      case 'order-tracking':
        return <OrderTrackingPage onNavigate={handleNavigate} />;
      case 'order-view':
        return <OrderView orderId={orderViewId} onBack={handleBackToHome} onNavigate={handleNavigate} />;
      case 'my-orders':
        return <MyOrders onNavigate={handleNavigate} />;
      case 'institutional-privacy':
        return <InstitutionalPages page="privacy" onBack={handleBackToHome} />;
      case 'institutional-terms':
        return <InstitutionalPages page="terms" onBack={handleBackToHome} />;
      case 'institutional-returns':
        return <InstitutionalPages page="returns" onBack={handleBackToHome} />;
      case 'institutional-about-us':
        return <InstitutionalPages page="about-us" onBack={handleBackToHome} />;
      case 'institutional-contact-info':
        return <InstitutionalPages page="contact-info" onBack={handleBackToHome} />;
      default:
        return <Home onNavigate={handleNavigate} onProductClick={handleProductClick} />;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header 
        currentPage={currentPage} 
        onNavigate={handleNavigate}
        onCartOpen={handleCartOpen}
      />
      
      <main>
        {renderPage()}
      </main>
      
      <Footer onNavigate={handleNavigate} />
      
      <CartSidebar 
        isOpen={isCartOpen}
        onClose={handleCartClose}
        onCheckout={handleCheckout}
      />
      
      <ProductModal
        product={selectedProduct}
        isOpen={isProductModalOpen}
        onClose={handleProductModalClose}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <SiteCustomizationProvider>
        <ProductProvider>
          <CartProvider>
            <AppContent />
          </CartProvider>
        </ProductProvider>
      </SiteCustomizationProvider>
    </AuthProvider>
  );
}