# 🔐 Credenciais de Demonstração - Comfydance

## 🎯 **Sistema de Autenticação**

O sistema funciona em **modo demonstração** quando não há configuração do Supabase, permitindo testes completos sem necessidade de banco de dados.

---

## 👤 **Credenciais de Teste**

### **🔧 Administrador**
```
Email: pedroh3019999@gmail.com
Senha: Ph94581152
```
- ✅ **Acesso completo** ao painel administrativo
- ✅ **Gerenciamento de produtos** e pedidos
- ✅ **Personalização visual** do site
- ✅ **Configurações avançadas**

### **👥 Usuários Demo**
```
Email: usuario@teste.com
Senha: 123456
```
```
Email: cliente@demo.com  
Senha: demo123
```
- ✅ **Navegação completa** do site
- ✅ **Carrinho de compras** funcional
- ✅ **Processo de checkout** simulado
- ✅ **Área do cliente** com perfil

---

## 🚀 **Como Testar**

### **1. Acesso de Cliente**
1. Vá para **"Minha Conta"**
2. Use qualquer credencial de usuário demo
3. Explore: carrinho, checkout, perfil

### **2. Acesso Administrativo**
1. Acesse `/admin` ou clique em **"Editar Página"** (se logado como admin)
2. Use as credenciais de administrador
3. Explore: produtos, pedidos, personalização

### **3. Criar Nova Conta Demo**
1. Clique em **"Cadastre-se"**
2. Preencha qualquer nome/email/senha
3. A conta será criada localmente para demonstração

---

## 🎭 **Modo Demonstração vs Produção**

### **🎪 Modo Atual (Demo)**
- ✅ **Funciona imediatamente** sem configuração
- ✅ **Dados salvos localmente** no navegador
- ✅ **Pagamentos simulados** (PIX/Boleto fictícios)
- ✅ **Interface idêntica** ao modo produção
- ⚠️ **Dados não persistem** entre dispositivos

### **🏭 Modo Produção**
- ✅ **Banco de dados real** (Supabase)
- ✅ **Autenticação segura** com email
- ✅ **Pagamentos reais** via provedores
- ✅ **Dados sincronizados** entre dispositivos
- ✅ **Backup automático** na nuvem

---

## 🔄 **Transição para Produção**

Para ativar o modo produção:

1. **Configure o Supabase:**
```bash
VITE_SUPABASE_URL=sua_url_aqui
VITE_SUPABASE_ANON_KEY=sua_chave_aqui
```

2. **Execute as migrações:**
```bash
supabase migration up
```

3. **Configure pagamentos (opcional):**
```bash
VITE_MERCADOPAGO_ACCESS_TOKEN=seu_token
# ou outros provedores
```

---

## 🛡️ **Segurança**

### **Demo Mode:**
- ✅ **Totalmente seguro** para apresentações
- ✅ **Nenhum dado real** é coletado
- ✅ **Sem riscos** de transações acidentais
- ✅ **Dados locais** não são enviados para servidores

### **Production Mode:**
- ✅ **Criptografia SSL** em todas as comunicações
- ✅ **Autenticação JWT** segura
- ✅ **Políticas RLS** no banco de dados
- ✅ **Validação** em frontend e backend

---

## 📱 **Funcionalidades Testáveis**

### **✅ E-commerce Completo**
- Catálogo de produtos
- Carrinho de compras
- Checkout com pagamentos
- Área do cliente

### **✅ Painel Administrativo**
- Gerenciamento de produtos
- Controle de pedidos
- Personalização visual
- Relatórios e estatísticas

### **✅ Sistema de Pagamentos**
- PIX com QR Code
- Boleto bancário
- Simulação completa

---

## 🎯 **Dicas para Demonstração**

1. **Comece como cliente** para mostrar a experiência de compra
2. **Faça um pedido completo** até o pagamento
3. **Acesse como admin** para mostrar o painel
4. **Personalize as cores** para demonstrar flexibilidade
5. **Mostre o gerenciamento** de produtos e pedidos

O sistema está **100% funcional** em modo demo! 🚀