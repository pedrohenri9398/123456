import express from 'express';
import cors from 'cors';
import { MercadoPagoConfig, Payment } from 'mercadopago';
import dotenv from 'dotenv';

// Carregar variáveis de ambiente
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Configuração do Mercado Pago
const client = new MercadoPagoConfig({
  accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN,
  options: {
    timeout: 5000,
    idempotencyKey: 'abc'
  }
});

const payment = new Payment(client);

// Middlewares
app.use(cors({
  origin: ['http://localhost:5173', 'https://comfydance.netlify.app'],
  credentials: true
}));
app.use(express.json());

// Endpoint para criar pagamento PIX
app.post('/api/create-payment', async (req, res) => {
  try {
    const { items, customerData, orderNumber } = req.body;

    // Validar dados recebidos
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Itens do pedido são obrigatórios'
      });
    }

    if (!customerData || !customerData.email || !customerData.name) {
      return res.status(400).json({
        success: false,
        error: 'Dados do cliente são obrigatórios'
      });
    }

    // Calcular valor total exato dos produtos
    const totalAmount = items.reduce((total, item) => {
      return total + (item.price * item.quantity);
    }, 0);

    // Validar se o valor é válido
    if (totalAmount <= 0) {
      return res.status(400).json({
        success: false,
        error: 'Valor total deve ser maior que zero'
      });
    }

    // Criar descrição do pedido
    const description = `Pedido ${orderNumber || 'N/A'} - ${items.length} item(s) - Comfydance`;

    // Dados do pagamento para o Mercado Pago
    const paymentData = {
      transaction_amount: Number(totalAmount.toFixed(2)),
      description: description,
      payment_method_id: 'pix',
      payer: {
        email: customerData.email,
        first_name: customerData.name.split(' ')[0],
        last_name: customerData.name.split(' ').slice(1).join(' ') || customerData.name.split(' ')[0]
      },
      metadata: {
        order_number: orderNumber,
        customer_email: customerData.email,
        items_count: items.length,
        source: 'comfydance_website'
      },
      notification_url: `${process.env.WEBHOOK_URL || 'https://your-domain.com'}/api/webhook`,
      external_reference: orderNumber || `order_${Date.now()}`
    };

    console.log('Criando pagamento com dados:', {
      amount: paymentData.transaction_amount,
      description: paymentData.description,
      customer: paymentData.payer.email
    });

    // Criar pagamento no Mercado Pago
    const result = await payment.create({
      body: paymentData
    });

    console.log('Pagamento criado com sucesso:', {
      id: result.id,
      status: result.status,
      amount: result.transaction_amount
    });

    // Extrair dados do PIX
    const pixData = result.point_of_interaction?.transaction_data;
    
    if (!pixData) {
      throw new Error('Dados do PIX não foram gerados pelo Mercado Pago');
    }

    // Resposta de sucesso
    res.json({
      success: true,
      payment_id: result.id,
      status: result.status,
      amount: result.transaction_amount,
      pix: {
        qr_code: pixData.qr_code,
        qr_code_base64: pixData.qr_code_base64,
        ticket_url: pixData.ticket_url
      },
      expires_at: new Date(Date.now() + 30 * 60 * 1000), // 30 minutos
      external_reference: result.external_reference
    });

  } catch (error) {
    console.error('Erro ao criar pagamento:', error);
    
    res.status(500).json({
      success: false,
      error: 'Erro interno do servidor ao processar pagamento',
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Endpoint para verificar status do pagamento
app.get('/api/payment-status/:paymentId', async (req, res) => {
  try {
    const { paymentId } = req.params;

    const result = await payment.get({
      id: paymentId
    });

    res.json({
      success: true,
      payment_id: result.id,
      status: result.status,
      status_detail: result.status_detail,
      amount: result.transaction_amount,
      date_approved: result.date_approved,
      external_reference: result.external_reference
    });

  } catch (error) {
    console.error('Erro ao verificar status:', error);
    
    res.status(500).json({
      success: false,
      error: 'Erro ao verificar status do pagamento'
    });
  }
});

// Webhook para receber notificações do Mercado Pago
app.post('/api/webhook', async (req, res) => {
  try {
    const { type, data } = req.body;

    console.log('Webhook recebido:', { type, data });

    if (type === 'payment') {
      const paymentId = data.id;
      
      // Buscar dados atualizados do pagamento
      const paymentInfo = await payment.get({
        id: paymentId
      });

      console.log('Status do pagamento atualizado:', {
        id: paymentInfo.id,
        status: paymentInfo.status,
        external_reference: paymentInfo.external_reference
      });

      // Aqui você pode implementar a lógica para:
      // - Atualizar status do pedido no banco de dados
      // - Enviar email de confirmação
      // - Atualizar estoque
      // - etc.
    }

    res.status(200).send('OK');
  } catch (error) {
    console.error('Erro no webhook:', error);
    res.status(500).send('Error');
  }
});

// Endpoint de saúde
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    mercadopago_configured: !!process.env.MERCADOPAGO_ACCESS_TOKEN
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando na porta ${PORT}`);
  console.log(`🔗 API disponível em: http://localhost:${PORT}/api`);
  console.log(`💳 Mercado Pago configurado: ${!!process.env.MERCADOPAGO_ACCESS_TOKEN ? '✅' : '❌'}`);
});

export default app;