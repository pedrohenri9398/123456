import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { v4 as uuidv4 } from 'uuid';
import axios from 'axios';

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors({
  origin: ['http://localhost:5173', 'https://comfydance.netlify.app'],
  credentials: true
}));
app.use(express.json());

app.post('/api/create-payment', async (req, res) => {
  try {
    const { items, customerData, orderNumber } = req.body;

    const totalAmount = items.reduce((total, item) => total + (item.price * item.quantity), 0);
    const idempotencyKey = uuidv4();

    const response = await axios.post(
      'https://api.mercadopago.com/v1/payments',
      {
        transaction_amount: Number(totalAmount.toFixed(2)),
        description: `Pedido #${orderNumber || 'N/A'}`,
        payment_method_id: 'pix',
        payer: {
          email: customerData.email,
          first_name: customerData.name.split(' ')[0],
        }
      },
      {
        headers: {
          Authorization: 'Bearer APP_USR-3147084600388369-061716-797e9f5b926699b3b1049b63549634fa-275070155',
          'Content-Type': 'application/json',
          'X-Idempotency-Key': idempotencyKey
        }
      }
    );

    res.status(200).json({
      success: true,
      payment_id: response.data.id,
      status: response.data.status,
      amount: response.data.transaction_amount,
      pix: response.data.point_of_interaction?.transaction_data,
      expires_at: response.data.date_of_expiration,
      external_reference: response.data.external_reference
    });
  } catch (error) {
    console.error(error.response?.data || error.message);
    res.status(500).json({
      success: false,
      error: error.response?.data || error.message
    });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
